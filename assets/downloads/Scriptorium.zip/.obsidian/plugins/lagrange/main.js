/*
 * Lagrange: a writing companion for Scriptorium.
 *
 * Copyright (C) 2026 William Liaw
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later
 * version. It is distributed WITHOUT ANY WARRANTY; see the GNU General Public License (LICENSE, next to this file).
 *
 * Plain CommonJS with no build step, like the Scriptorium plugin next to it. Obsidian supplies 'obsidian',
 * '@codemirror/state' and '@codemirror/view' to plugins through require(). Node's child_process, fs, os and path are
 * loaded only by the two subscription providers, only on desktop (nodeModule), so the plugin still runs on mobile.
 *
 * Map of this file:
 *   1. Settings and constants
 *   2. Pure helpers: SSE parsing, edit JSON parsing, locating edits, edits in a chat reply, the pen's script (with
 *      its mathematics) and trail, clipping notes, error messages, demo replies. They touch neither the DOM nor
 *      Obsidian; plugins-tests/lagrange.test.js tests them under Node.
 *   3. Providers: Anthropic Messages API, OpenAI API and OpenAI-compatible chat completions, a Claude subscription
 *      through Claude Code, a ChatGPT subscription through Codex, Demo (offline). The only requests the plugin makes
 *      are to the provider chosen in its settings, when the writer asks for something.
 *   4. The loader, a replaceable section:  mountLoader(containerEl, theme) -> { stop() }
 *   5. Pen helpers shared by any pen (rangeRects, sleep, nextFrame), then the pen, a replaceable section:
 *      createPen(app, settings) -> { edit(view, from, to, replacement): Promise<void>, destroy() }
 *      Each replaceable section runs from its "==== LAGRANGE … (replaceable) ====" line to its "==== END …" line,
 *      here and in styles.css.
 *   6. Edit runs: the editor is locked while the pen writes, and all of a request's edits become one undo step
 *   7. The chat view (with the model and effort picker in its footer), the revise modal, the settings tab and the
 *      plugin. A chat message may edit the note: the reply's edits block goes to the pen (applyChatEdits). Each run
 *      of edits can be undone and redone (recordEdit, undoEdit, redoEdit), and each message is a checkpoint the
 *      conversation and the note can be rewound to (rewind, restoreNote).
 */
'use strict';

const obsidian = require('obsidian');
const { Plugin, ItemView, Modal, Notice, PluginSettingTab, Setting, MarkdownRenderer, MarkdownView, Component, setIcon } = obsidian;
const { StateField, StateEffect, EditorState, Transaction, ChangeSet, Compartment } = require('@codemirror/state');
const { EditorView, Decoration, WidgetType } = require('@codemirror/view');


/* ---------------------------------------------------------------------------------------------------------------
 * 1. Settings and constants
 * ------------------------------------------------------------------------------------------------------------- */

const VIEW_TYPE = 'lagrange-chat';
const ICON = 'pen-tool';

const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';
const ANTHROPIC_VERSION = '2026-10-21';
// Server-side refusal fallback (beta): if a safety classifier declines, the API retries on another model in the same
// call. Only these two models take fallbacks: "default" (Claude Haiku 5.5 has no server-side fallback).
const FALLBACK_BETA = 'server-side-fallback-2026-07-01';
const ANTHROPIC_MODELS = [
  { id: 'claude-sonnet-5-5', name: 'Claude Sonnet 5.5', fallback: true },
  { id: 'claude-opus-5-5', name: 'Claude Opus 5.5', fallback: true },
  { id: 'claude-haiku-5-5', name: 'Claude Haiku 5.5', fallback: false },
];
const MAX_TOKENS = 64000;          // streamed, so a long reply can't time out; known models all allow it
const MAX_TOKENS_CUSTOM = 8192;    // a custom model ID may be an older model with a smaller output limit

// How much of a note goes into one request, in characters. Longer notes are clipped around the cursor, and the chat
// says so. Local models often run with small context windows, hence the smaller figure.
const NOTE_LIMIT = { anthropic: 120000, 'claude-code': 120000, 'openai-api': 120000, codex: 80000, openai: 24000, demo: 120000 };

const LOADER_THEMES = ['random', 'clockwork', 'alchemy', 'orbit'];
// Reasoning effort, where the provider and model take one; '' leaves it to the provider's own default.
const EFFORTS = ['low', 'medium', 'high'];
const CLAUDE_CODE_MODELS = ['sonnet', 'opus', 'haiku'];   // Claude Code's aliases for the latest of each

const DEFAULT_SETTINGS = {
  provider: 'claude-code',            // 'claude-code' | 'anthropic' | 'codex' | 'openai-api' | 'openai' | 'demo'
  anthropicApiKey: '',
  anthropicModel: 'claude-sonnet-5-5', // an ANTHROPIC_MODELS id, or 'custom'
  anthropicCustomModel: '',
  refusalFallback: true,
  openaiBaseUrl: 'http://localhost:11434/v1',
  openaiApiKey: '',
  openaiModel: '',
  openaiPlatformKey: '',               // OpenAI API (platform.openai.com)
  openaiPlatformModel: '',
  openaiImageModel: 'gpt-image-2.5-sunburst',   // the Images API model that draws drop caps (OpenAI API provider)
  claudeCodePath: '',                  // Claude subscription via Claude Code; empty = look in the usual places
  claudeCodeModel: 'sonnet',
  codexPath: '',                       // ChatGPT subscription via Codex; empty = look in the usual places
  codexModel: '',
  effort: '',                         // '' (the provider's default) | 'low' | 'medium' | 'high'; see effortFor
  agenticEdits: true,                 // a chat message may edit the open note with the pen; off: the chat only talks
  loaderTheme: 'random',              // 'random' | 'clockwork' | 'alchemy' | 'orbit'
  showPen: true,
  penSpeed: 1,                        // 0.5 (slow) to 3 (fast)
  penTrail: true,                     // a fading line of ink behind the pen's nib as it moves
  penLines: 3,                        // how many lines of a long edit the pen writes out before the rest is set down (1 to 8)
};

function sanitizeSettings(saved) {
  const s = Object.assign({}, DEFAULT_SETTINGS);
  if (saved && typeof saved === 'object') {
    for (const k of Object.keys(DEFAULT_SETTINGS)) {
      if (typeof saved[k] === typeof DEFAULT_SETTINGS[k]) s[k] = saved[k];
    }
  }
  if (!['anthropic', 'claude-code', 'openai-api', 'codex', 'openai', 'demo'].includes(s.provider)) s.provider = DEFAULT_SETTINGS.provider;
  // A plate that no longer exists (a saved 'trebuchet', from 0.1) falls back to 'random'.
  if (!LOADER_THEMES.includes(s.loaderTheme)) s.loaderTheme = DEFAULT_SETTINGS.loaderTheme;
  if (s.anthropicModel !== 'custom' && !ANTHROPIC_MODELS.some(m => m.id === s.anthropicModel)) {
    s.anthropicModel = DEFAULT_SETTINGS.anthropicModel;
  }
  if (!(s.penSpeed >= 0.5 && s.penSpeed <= 3)) s.penSpeed = DEFAULT_SETTINGS.penSpeed;
  if (!(Number.isInteger(s.penLines) && s.penLines >= 1 && s.penLines <= 8)) s.penLines = DEFAULT_SETTINGS.penLines;
  if (!EFFORTS.includes(s.effort)) s.effort = '';
  return s;
}

function anthropicModelId(s) {
  return s.anthropicModel === 'custom' ? String(s.anthropicCustomModel || '').trim() : s.anthropicModel;
}

/* Which models take a reasoning effort. Anthropic: `output_config.effort`, on Claude Opus 4.5 and every later Opus,
   Sonnet 4.6 and later, Haiku 5.5 and later, Fable and Mythos (older models answer 400). OpenAI: `reasoning_effort`,
   on the reasoning models only (the o-series and GPT-5 and later, but not their "chat" variants). */
const ANTHROPIC_EFFORT_RE = /^claude-(?:(?:fable|mythos)-|opus-(?:4-[5-9]|[5-9])|sonnet-(?:4-[6-9]|[5-9])|haiku-[5-9])/;
const OPENAI_EFFORT_RE = /^(?:o[1-9]|gpt-[5-9])/i;

/* Whether the chosen provider and model take a reasoning effort at all. Claude Code has `--effort`, Codex the
   `model_reasoning_effort` setting. A local OpenAI-compatible server is sent none (most reject or ignore it), and the
   demo has no model. */
function effortSupported(s) {
  if (s.provider === 'claude-code' || s.provider === 'codex') return true;
  if (s.provider === 'anthropic') return ANTHROPIC_EFFORT_RE.test(anthropicModelId(s));
  if (s.provider === 'openai-api') {
    const m = String(s.openaiPlatformModel || '').trim();
    return OPENAI_EFFORT_RE.test(m) && !/chat/i.test(m);
  }
  return false;
}

/* The effort to send with a request: the chosen one where it is supported, otherwise '' (send nothing). */
function effortFor(s) {
  return EFFORTS.includes(s.effort) && effortSupported(s) ? s.effort : '';
}

/* What the footer's model picker offers for the current provider:
   {provider, options: [{value, label}], current, free, placeholder}. `free` says a model can also be typed in. */
function modelChoices(s) {
  const out = (provider, options, current, free, placeholder) => {
    current = String(current || '').trim();
    if (current && !options.some(o => o.value === current)) options.push({ value: current, label: current });
    return { provider, options, current, free, placeholder: placeholder || '' };
  };
  switch (s.provider) {
    case 'anthropic':
      return out('Claude: API key', ANTHROPIC_MODELS.map(m => ({ value: m.id, label: m.name })), anthropicModelId(s), true, 'claude-…');
    case 'claude-code':
      return out('Claude: my subscription', CLAUDE_CODE_MODELS.map(m => ({ value: m, label: m[0].toUpperCase() + m.slice(1) })),
        s.claudeCodeModel, true, 'a full model ID');
    case 'codex':
      return out('ChatGPT: my subscription', [{ value: '', label: 'Codex’s default' }], s.codexModel, true, 'a model Codex knows');
    case 'openai-api':
      return out('OpenAI: API key', [], s.openaiPlatformModel, true, 'model ID');
    case 'openai':
      return out('OpenAI-compatible server', [], s.openaiModel, true, 'llama3.1');
    default:
      return out('Demo (offline)', [], '', false, '');
  }
}

/* Sets the current provider's model (a modelChoices value, or one typed in). */
function setModel(s, value) {
  const v = String(value == null ? '' : value).trim();
  if (s.provider === 'anthropic') {
    if (ANTHROPIC_MODELS.some(m => m.id === v)) s.anthropicModel = v;
    else if (v) { s.anthropicModel = 'custom'; s.anthropicCustomModel = v; }
  } else if (s.provider === 'claude-code') {
    if (v) s.claudeCodeModel = v;
  } else if (s.provider === 'codex') {
    s.codexModel = v;
  } else if (s.provider === 'openai-api') {
    if (v) s.openaiPlatformModel = v;
  } else if (s.provider === 'openai') {
    if (v) s.openaiModel = v;
  }
  return s;
}

/* The footer's label: the model, and the effort when one is set and the model takes it. */
function footLabel(s) {
  const e = effortFor(s);
  return modelLabel(s) + (e ? ` · ${e} effort` : '');
}

function modelLabel(s) {
  if (s.provider === 'demo') return 'Demo (offline)';
  if (s.provider === 'openai') return String(s.openaiModel || '').trim() || 'OpenAI-compatible server';
  if (s.provider === 'openai-api') return String(s.openaiPlatformModel || '').trim() || 'OpenAI';
  if (s.provider === 'claude-code') return `Claude (subscription${String(s.claudeCodeModel || '').trim() ? `, ${String(s.claudeCodeModel).trim()}` : ''})`;
  if (s.provider === 'codex') return `ChatGPT (subscription${String(s.codexModel || '').trim() ? `, ${String(s.codexModel).trim()}` : ''})`;
  const id = anthropicModelId(s);
  const preset = ANTHROPIC_MODELS.find(m => m.id === id);
  return preset ? preset.name : (id || 'Claude');
}


/* ---------------------------------------------------------------------------------------------------------------
 * 2. Pure helpers
 * ------------------------------------------------------------------------------------------------------------- */

class LagrangeError extends Error {
  constructor(message, extra) {
    super(message);
    this.name = 'LagrangeError';
    if (extra) Object.assign(this, extra);
  }
}

function abortError() {
  const e = new Error('Stopped');
  e.name = 'AbortError';
  return e;
}

function isAbort(e) {
  return Boolean(e && e.name === 'AbortError');
}

/* Server-sent events (https://html.spec.whatwg.org/multipage/server-sent-events.html). push() takes text chunks cut
   anywhere (mid-line, mid-CRLF); onEvent gets {event, data} for each complete event. end() flushes a final event that
   had no blank line after it. Comments and id/retry fields are ignored. */
function createSSEParser(onEvent) {
  let buf = '';
  let event = '';
  let data = [];
  const dispatch = () => {
    if (data.length) onEvent({ event: event || 'message', data: data.join('\n') });
    event = '';
    data = [];
  };
  const line = l => {
    if (l === '') { dispatch(); return; }
    if (l[0] === ':') return;
    const i = l.indexOf(':');
    const field = i < 0 ? l : l.slice(0, i);
    let value = i < 0 ? '' : l.slice(i + 1);
    if (value[0] === ' ') value = value.slice(1);
    if (field === 'event') event = value;
    else if (field === 'data') data.push(value);
  };
  return {
    push(chunk) {
      buf += chunk;
      for (;;) {
        const n = buf.search(/\r\n|\n|\r/);
        if (n < 0) break;
        if (buf[n] === '\r' && n === buf.length - 1) break;   // maybe the first half of a CRLF: wait for more
        const len = buf[n] === '\r' && buf[n + 1] === '\n' ? 2 : 1;
        const l = buf.slice(0, n);
        buf = buf.slice(n + len);
        line(l);
      }
    },
    end() {
      if (buf) { const l = buf.replace(/\r$/, ''); buf = ''; line(l); }
      dispatch();
    },
  };
}

/* Models are asked to escape backslashes in the JSON they write, and sometimes do not: "$\frac{a}{b}$" then reads
   as a form feed and "rac", "\times" as a tab, and "\alpha" is not JSON at all. Given the text of a reply, this
   doubles the backslashes that are plainly LaTeX's, but only when the reply shows that it was not escaped (it has a
   backslash that no JSON string can hold, or \frac, \beta and the like, and no properly escaped command): then
   every backslash is LaTeX's except \" and the JSON escapes \n, \t, \r, \b, \f where they do not start a LaTeX
   command inside $…$. Text that was escaped properly comes back as it was. */
const LATEX_BF_RE = /^(?:b(?:egin|eta|ar|ig{1,2}[lrm]?|inom|oldsymbol|mod|ot|ullet|oxed|ackslash)|f(?:rac|orall|lat|rown))(?![A-Za-z])/;
const LATEX_NRT_RE = /^(?:n(?:abla|u|eq?|eg|ot(?:in)?|leq|geq|mid|onumber|ewline|i|parallel|subseteq|exists)|r(?:ho|ight(?:arrow)?|angle|ceil|floor|m|brace|[vV]ert)|t(?:heta|au|imes|ext(?:bf|it|rm|sf|tt)?|frac|o|op|anh?|ilde|riangle|ag|herefore|binom))(?![A-Za-z])/;
function repairJsonLatex(text) {
  const s = String(text == null ? '' : text);
  if (s.indexOf('\\') < 0 || /\\\\[A-Za-z]{2,}/.test(s)) return s;
  let evidence = false;
  for (let i = 0; i < s.length && !evidence; i++) {
    if (s[i] !== '\\') continue;
    const n = s[i + 1] || '';
    if (n === '\\') { i++; continue; }
    if (/[bf]/.test(n)) evidence = LATEX_BF_RE.test(s.slice(i + 1, i + 14));
    else if (n === 'u') evidence = !/^u[0-9a-fA-F]{4}/.test(s.slice(i + 1, i + 6));
    else evidence = /[A-Za-z]/.test(n) && !/[nrt]/.test(n);
  }
  if (!evidence) return s;
  let out = '', math = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i], n = s[i + 1] || '';
    if (c === '$') { math = !math; out += c; if (n === '$') { out += n; i++; } continue; }
    if (c === '"') { math = false; out += c; continue; }
    if (c !== '\\') { out += c; continue; }
    if (n === '"' || n === '/') { out += c + n; i++; continue; }
    if (n === '\\') { out += '\\\\\\\\'; i++; continue; }           // LaTeX's line break
    const word = s.slice(i + 1, i + 14);
    let latex = true;
    if (/[bf]/.test(n)) latex = LATEX_BF_RE.test(word) || /^[bf][A-Za-z]/.test(word) && math;
    else if (/[nrt]/.test(n)) latex = math && LATEX_NRT_RE.test(word);
    else if (n === 'u') latex = !/^u[0-9a-fA-F]{4}/.test(word);
    out += latex ? '\\\\' : '\\';
  }
  return out;
}

/* Each balanced JSON array or object in text, parsed, in order of where it starts. Prose around it, and brackets in
   the prose that don't start valid JSON, are skipped. */
function* jsonValuesIn(text) {
  let tries = 0;
  for (let start = 0; start < text.length && tries < 200; start++) {
    const open = text[start];
    if (open !== '[' && open !== '{') continue;
    tries++;
    let depth = 0, inString = false, escaped = false, end = -1;
    for (let i = start; i < text.length; i++) {
      const c = text[i];
      if (inString) {
        if (escaped) escaped = false;
        else if (c === '\\') escaped = true;
        else if (c === '"') inString = false;
        continue;
      }
      if (c === '"') inString = true;
      else if (c === '[' || c === '{') depth++;
      else if (c === ']' || c === '}') {
        depth--;
        if (depth === 0) { end = i; break; }
      }
    }
    if (end < 0) continue;
    try {
      yield JSON.parse(text.slice(start, end + 1));
      start = end;
    } catch (e) { /* not JSON from here: try the next bracket */ }
  }
}

function normalizeEdit(item) {
  if (!item || typeof item !== 'object') return null;
  const pick = keys => { for (const k of keys) if (typeof item[k] === 'string') return item[k]; return null; };
  const find = pick(['find', 'original', 'old', 'search']);
  const replace = pick(['replace', 'replacement', 'new', 'corrected']);
  if (!find || replace === null) return null;
  const reason = pick(['reason', 'why', 'explanation']);
  return { find, replace, reason: reason ? reason.trim() : '' };
}

/* The model's reply to a proofreading request, as edits: [{find, replace, reason}]. Accepts a bare JSON array, one in
   a ``` fence, one surrounded by prose, or {"edits": [...]}. Items without a non-empty "find" and a "replace" string
   are dropped (and counted). */
function parseEdits(text) {
  const raw = repairJsonLatex(text).trim();
  if (!raw) return { edits: [], dropped: 0, error: 'The reply was empty.' };
  const sources = [];
  const fence = /```[^\n`]*\n?([\s\S]*?)```/g;
  let m;
  while ((m = fence.exec(raw))) sources.push(m[1]);
  sources.push(raw);
  for (const src of sources) {
    for (const value of jsonValuesIn(src)) {
      const list = Array.isArray(value) ? value : (value && Array.isArray(value.edits) ? value.edits : null);
      if (!list) continue;
      if (list.length && !list.some(x => x && typeof x === 'object')) continue;
      const edits = list.map(normalizeEdit).filter(Boolean);
      return { edits, dropped: list.length - edits.length, error: null };
    }
  }
  return { edits: [], dropped: 0, error: 'The reply was not a JSON list of edits.' };
}

/* Every index where needle occurs in text, overlapping occurrences included (so "aa" is twice in "aaa"). */
function findAll(text, needle) {
  const out = [];
  if (!needle) return out;
  for (let i = text.indexOf(needle); i >= 0; i = text.indexOf(needle, i + 1)) out.push([i, i + needle.length]);
  return out;
}

/* A second, looser search for text a model copied not quite exactly: any kind of quotation mark or apostrophe matches
   any other, hyphens and dashes match each other, "..." matches "…", and runs of white space match any white space. */
function looseFindAll(text, needle) {
  if (!needle || needle.length > 4000) return [];
  let src = '';
  for (let i = 0; i < needle.length; i++) {
    const c = needle[i];
    if (/\s/.test(c)) { while (i + 1 < needle.length && /\s/.test(needle[i + 1])) i++; src += '\\s+'; }
    else if ('"“”„«»'.includes(c)) src += '["“”„«»]';
    else if ("'‘’‚".includes(c)) src += "['‘’‚]";
    else if ('-‐‑–—'.includes(c)) src += '[-‐‑–—]';
    else if (c === '…') src += '(?:…|\\.\\.\\.)';
    else if (c === '.' && needle.slice(i, i + 3) === '...') { src += '(?:…|\\.\\.\\.)'; i += 2; }
    else src += c.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
  }
  const out = [];
  const re = new RegExp(src, 'g');
  let m;
  while ((m = re.exec(text))) {
    out.push([m.index, m.index + m[0].length]);
    re.lastIndex = m.index + 1;
  }
  return out;
}

/* Finds each edit's text in the document. An edit is skipped when its text isn't there, is there more than once, or
   overlaps an edit kept before it. Kept edits come back in document order with from/to offsets and the exact text
   matched ("matched", which can differ from "find" in quotes or spacing after the loose search). */
function locateEdits(doc, edits) {
  const located = [];
  const skipped = [];
  for (const e of edits) {
    if (e.find === e.replace) { skipped.push(Object.assign({}, e, { why: 'no change' })); continue; }
    let hits = findAll(doc, e.find);
    if (!hits.length) hits = looseFindAll(doc, e.find);
    if (!hits.length) { skipped.push(Object.assign({}, e, { why: 'not found in the note' })); continue; }
    if (hits.length > 1) { skipped.push(Object.assign({}, e, { why: `appears ${hits.length} times` })); continue; }
    const [from, to] = hits[0];
    if (located.some(o => from < o.to && o.from < to)) {
      skipped.push(Object.assign({}, e, { why: 'overlaps another edit' }));
      continue;
    }
    located.push(Object.assign({}, e, { from, to, matched: doc.slice(from, to) }));
  }
  located.sort((a, b) => a.from - b.from);
  return { located, skipped };
}

/* At most limit characters of text, cut at line ends where possible, centred on focus (an offset, e.g. the cursor;
   the beginning if not given). Marks what was left out so the model knows. */
function clipText(text, limit, focus) {
  text = String(text || '');
  if (text.length <= limit) return { text, clipped: false, start: 0, end: text.length, total: text.length };
  const f = Number.isFinite(focus) ? focus : 0;
  let start = Math.max(0, Math.min(text.length - limit, Math.round(f - limit / 2)));
  let end = Math.min(text.length, start + limit);
  if (start > 0) {
    const nl = text.indexOf('\n', start);
    if (nl >= 0 && nl < start + 2000 && nl < end) start = nl + 1;
  }
  if (end < text.length) {
    const nl = text.lastIndexOf('\n', end);
    if (nl > start && nl > end - 2000) end = nl;
  }
  let out = text.slice(start, end);
  if (start > 0) out = `[… the first ${start} characters are not shown …]\n` + out;
  if (end < text.length) out += `\n[… the last ${text.length - end} characters are not shown …]`;
  return { text: out, clipped: true, start, end, total: text.length };
}

/* The model's reply to a revise request, ready to replace the passage: a fence, <passage> tags or quotation marks
   wrapped around the whole reply are removed, and the passage's own leading and trailing white space is kept. Null if
   nothing is left. */
function cleanRevision(reply, original) {
  let t = String(reply == null ? '' : reply).trim();
  const fenced = t.match(/^```[^\n]*\n([\s\S]*?)\n?```$/);
  if (fenced) t = fenced[1].trim();
  const tagged = t.match(/^<passage>\s*([\s\S]*?)\s*<\/passage>$/i);
  if (tagged) t = tagged[1].trim();
  const orig = String(original || '');
  const quoted = t.match(/^(["“])([\s\S]*)(["”])$/);
  if (quoted && !/^\s*["“]/.test(orig) && !quoted[2].includes(quoted[1] === '“' ? '”' : '"')) t = quoted[2].trim();
  if (!t) return null;
  const lead = orig.match(/^\s*/)[0];
  const trail = orig.slice(lead.length).match(/\s*$/)[0];
  return lead + t + trail;
}

/* ---- Edits in a chat reply ----
   With "Edit with the pen" on, a chat reply may carry edits to the open note: after its prose, one block
       ```lagrange-edits
       [{"find": "…", "replace": "…", "reason": "…"}, {"insert_after": "…", "text": "…"}, {"append": "…"}]
       ```
   (or the same JSON between <lagrange-edits> and </lagrange-edits>). It is plain text, so every provider can write
   it. The chat shows the prose; the block goes to the pen. A reply without a block is an answer and changes nothing. */

const EDITS_OPEN_RE = /(?:^|\n)[ \t]*(?:(`{3,}|~{3,})[ \t]*lagrange-edits\b[^\n]*(?:\n|$)|<lagrange-edits>)/i;

/* Splits a chat reply into the prose to show and the edit blocks: {text, blocks: [string], open}. `open` is true when
   the last block has no closing line, as while the reply is still streaming, or when it was cut off; everything from
   its opening line on is then left out of the text. */
function splitAgentReply(reply) {
  let rest = String(reply == null ? '' : reply);
  let text = '';
  const blocks = [];
  let open = false;
  for (;;) {
    const m = EDITS_OPEN_RE.exec(rest);
    if (!m) { text += rest; break; }
    text += rest.slice(0, m.index) + '\n';
    const body = rest.slice(m.index + m[0].length);
    const close = m[1]
      ? new RegExp(`(?:^|\\n)[ \\t]*${m[1][0]}{${m[1].length},}[ \\t]*(?=\\n|$)`).exec(body)
      : /<\/lagrange-edits>/i.exec(body);
    if (!close) { blocks.push(body); open = true; break; }
    blocks.push(body.slice(0, close.index));
    rest = body.slice(close.index + close[0].length);
  }
  return { text: text.replace(/\n{3,}/g, '\n\n').trim(), blocks, open };
}

/* One item of an edits block, as an operation: {op: 'replace', find, replace, reason}, {op: 'insert', after | before,
   text, reason} or {op: 'append', text, reason}. Null if it is none of these. */
function normalizeOp(item) {
  if (!item || typeof item !== 'object') return null;
  const str = keys => { for (const k of keys) if (typeof item[k] === 'string') return item[k]; return null; };
  const reason = (str(['reason', 'why', 'explanation']) || '').trim();
  const text = str(['text', 'insert', 'content']);
  const append = str(['append']);
  if (append !== null) return append ? { op: 'append', text: append, reason } : null;
  const after = str(['insert_after', 'after']), before = str(['insert_before', 'before']);
  if (after !== null || before !== null) {
    if (!text || !(after || before)) return null;
    return after ? { op: 'insert', after, text, reason } : { op: 'insert', before, text, reason };
  }
  const e = normalizeEdit(item);
  return e ? { op: 'replace', find: e.find, replace: e.replace, reason: e.reason } : null;
}

/* The operations in a chat reply: {text, ops, dropped, error, open}. text is the prose to show. error is null when
   every block held a JSON list (an empty list is fine: no edits); items that are not edits are dropped and counted. */
function parseAgentReply(reply) {
  const { text, blocks, open } = splitAgentReply(reply);
  const ops = [];
  let dropped = 0, error = null;
  for (const written of blocks) {
    const block = repairJsonLatex(written);
    let list = null;
    for (const value of jsonValuesIn(block)) {
      list = Array.isArray(value) ? value : (value && Array.isArray(value.edits) ? value.edits : (value && typeof value === 'object' ? [value] : null));
      if (list) break;
    }
    if (!list) { error = open ? 'The edits were cut off before they were complete.' : 'The edits were not a JSON list.'; continue; }
    for (const item of list) {
      const op = normalizeOp(item);
      if (op) ops.push(op); else dropped++;
    }
  }
  return { text, ops, dropped, error, open };
}

/* Finds each operation's place in the document, as locateEdits does for proofreading (and by the same rules: the text
   named must be there exactly once, by the exact search or the loose one, and edits may not overlap). An insertion is
   an edit of an empty range, next to its anchor; an append goes at the end of the note, after a blank line. */
function locateOps(doc, ops) {
  const { located, skipped } = locateEdits(doc, ops.filter(o => o.op === 'replace').map(o => ({ find: o.find, replace: o.replace, reason: o.reason })));
  const skip = (o, find, why) => skipped.push({ find, matched: '', replace: o.text, reason: o.reason, why, insert: true });
  for (const o of ops) {
    if (o.op === 'replace') continue;
    let at, anchor = '';
    if (o.op === 'append') {
      at = doc.length;
    } else {
      anchor = o.after || o.before;
      let hits = findAll(doc, anchor);
      if (!hits.length) hits = looseFindAll(doc, anchor);
      if (!hits.length) { skip(o, anchor, 'the place was not found in the note'); continue; }
      if (hits.length > 1) { skip(o, anchor, `the place appears ${hits.length} times`); continue; }
      at = o.after ? hits[0][1] : hits[0][0];
    }
    if (located.some(e => (e.from < at && at < e.to) || (e.from === e.to && e.from === at))) { skip(o, anchor, 'overlaps another edit'); continue; }
    let insert = o.text;
    if (o.op === 'append' && doc.length) insert = (doc.endsWith('\n\n') ? '' : doc.endsWith('\n') ? '\n' : '\n\n') + insert;
    located.push({ find: '', matched: '', replace: insert, reason: o.reason, from: at, to: at, insert: true });
  }
  located.sort((a, b) => a.from - b.from || a.to - b.to);
  return { located, skipped };
}

/* ---- Rewinding a conversation ----
   Each message the writer sends is a checkpoint: {text, historyLength, path, before, after, expired}. historyLength
   is how long the model's history was before the message; path is the note it was about; before is that note's text
   when the message was sent and after its text once the turn was over (null: there was no change to remember, or
   the checkpoint has expired). Rewinding to a checkpoint drops it and everything after it from the conversation,
   puts the message back to be edited, and can put the note back to `before`. */

const CHECKPOINTS_KEPT = 20;          // how many checkpoints keep their copy of the note
const CHECKPOINT_CHARS = 4000000;     // and how many characters those copies may hold in all

/* The conversation as it was before checkpoint k: {history, checkpoints}. */
function rewindTo(history, checkpoints, k) {
  const cp = checkpoints[k];
  if (!cp) return { history: history.slice(), checkpoints: checkpoints.slice() };
  return { history: history.slice(0, Math.max(0, cp.historyLength)), checkpoints: checkpoints.slice(0, k) };
}

/* Whether the note of checkpoint k holds changes that are not Lagrange's own since that checkpoint: typing between
   turns, or after the last one. `current` is the note's text now. Each turn is known to have taken the note from
   its `before` to its `after`; anything else is the writer's. Where a copy has expired it cannot be told, and the
   answer is yes, so that the writer is asked. */
function userChangedSince(checkpoints, k, current) {
  const cp = checkpoints[k];
  if (!cp || cp.before == null) return true;
  let expected = cp.before;
  for (let j = k; j < checkpoints.length; j++) {
    const c = checkpoints[j];
    if (c.path !== cp.path) continue;
    if (c.before == null) return true;
    if (c.before !== expected) return true;
    expected = c.after == null ? c.before : c.after;
  }
  return current !== expected;
}

/* Forgets the copies of the note held by the oldest checkpoints, so that at most `keep` checkpoints hold one and
   they hold at most `maxChars` characters; the newest always keeps its own. Returns the checkpoints that expired. */
function pruneCheckpoints(checkpoints, keep, maxChars) {
  const expired = [];
  let held = 0, chars = 0;
  for (let j = checkpoints.length - 1; j >= 0; j--) {
    const c = checkpoints[j];
    if (c.before == null) continue;
    const size = c.before.length + (c.after == null ? 0 : c.after.length);
    if (held > 0 && (held >= keep || chars + size > maxChars)) {
      c.before = null;
      c.after = null;
      c.expired = true;
      expired.push(c);
      continue;
    }
    held++;
    chars += size;
  }
  return expired;
}

/* The one change that turns text a into text b: {from, to, insert} (what is common at both ends stays as it is, so
   the cursor and the scroll position are kept where they can be); null if they are the same. */
function spliceChange(a, b) {
  if (a === b) return null;
  const max = Math.min(a.length, b.length);
  let start = 0;
  while (start < max && a.charCodeAt(start) === b.charCodeAt(start)) start++;
  let end = 0;
  while (end < max - start && a.charCodeAt(a.length - 1 - end) === b.charCodeAt(b.length - 1 - end)) end++;
  // never cut a surrogate pair in two
  if (start > 0 && /[\uD800-\uDBFF]/.test(a[start - 1])) start--;
  if (end > 0 && /[\uDC00-\uDFFF]/.test(a[a.length - end])) end--;
  return { from: start, to: a.length - end, insert: b.slice(start, b.length - end) };
}

/* Which of Lagrange's runs of edits the Undo and Redo buttons act on. records are oldest first: {undone, redo,
   undoneAt}. Undo takes back the latest run still in the note; Redo makes again the run most lately taken back,
   if it still can be (redo is null once the note has moved on). */
function undoTarget(records) {
  for (let i = records.length - 1; i >= 0; i--) if (!records[i].undone) return records[i];
  return null;
}

function redoTarget(records) {
  let best = null;
  for (const r of records) if (r.undone && r.redo && (!best || r.undoneAt > best.undoneAt)) best = r;
  return best;
}

/* ---- What the pen writes ----
   The pen writes a short form of each replacement above the line. Mathematics in it ($…$ or $$…$$, as Obsidian reads
   them) is kept whole, so it can be typeset and drawn symbol by symbol. Code in it (a fenced block, or a code span of
   a few characters or more) is kept apart too: it is not written by the pen but typed, on a typewriter. */

/* Splits text into [{type: 'text', text} | {type: 'math', source, display}]. Inline math opens with a $ that is not
   escaped and not followed by white space, and closes with one not preceded by white space and not followed by a
   digit, on the same line (so "$5 and $10" is text); $$…$$ is display math and may span lines. Models also write
   mathematics in LaTeX's own delimiters, which Obsidian does not typeset but the pen can: \(…\) on one line and
   \[…\] (when what is inside reads as mathematics, see looksLikeMath: in Markdown they are also escaped brackets),
   and a bare \begin{align}…\end{align} (or another display environment). Those segments also carry {open, close},
   the delimiters as written, so the source can be put back exactly (mathSource). Code spans and fenced
   code are text, unless opts.code is set: then a fenced block, and a code span of at least CODE_SPAN_MIN characters,
   come out as {type: 'code', text, block, lang} (text is the code itself, without its fence or backticks). */
const CODE_SPAN_MIN = 4;
const MATH_ENV_RE = /^\\begin\{((?:equation|align|alignat|flalign|gather|multline|eqnarray|split|aligned|gathered|cases|array|[pbBvV]?matrix)\*?)\}/;

/* Whether the inside of \(…\) or \[…\] reads as mathematics and not as prose in escaped brackets ("\[sic\]"): a
   command, a script, an equals sign, a sum or comparison, or a single letter. */
function looksLikeMath(body) {
  const b = String(body).trim();
  return /\\[A-Za-z]+|[\^_=]|[0-9A-Za-z)}]\s*[+<>]\s*[0-9A-Za-z({\\]/.test(b) || /^[A-Za-z]$/.test(b);
}

/* A math segment as it was written, delimiters and all. */
function mathSource(g) {
  if (typeof g.open === 'string') return g.open + g.source + g.close;
  return g.display ? `$$${g.source}$$` : `$${g.source}$`;
}
function mathSegments(text, opts) {
  const wantCode = Boolean(opts && opts.code);
  const src = String(text == null ? '' : text);
  const out = [];
  let buf = '';
  const flush = () => { if (buf) { out.push({ type: 'text', text: buf }); buf = ''; } };
  for (let i = 0; i < src.length;) {
    const c = src[i];
    if (c === '\\' && (src[i + 1] === '(' || src[i + 1] === '[')) {
      const display = src[i + 1] === '[', close = display ? '\\]' : '\\)';
      const end = src.indexOf(close, i + 2);
      const body = end < 0 ? '' : src.slice(i + 2, end);
      if (body.trim() && (display || !body.includes('\n')) && looksLikeMath(body)) {
        flush();
        out.push({ type: 'math', source: body.trim(), display, open: src.slice(i, i + 2) + body.slice(0, body.length - body.trimStart().length), close: body.slice(body.trimEnd().length) + close });
        i = end + 2;
        continue;
      }
    }
    if (c === '\\' && src.startsWith('\\begin{', i)) {
      const m = MATH_ENV_RE.exec(src.slice(i, i + 24));
      const close = m ? `\\end{${m[1]}}` : '';
      const end = m ? src.indexOf(close, i) : -1;
      if (end > 0) {
        flush();
        out.push({ type: 'math', source: src.slice(i, end + close.length), display: true, open: '', close: '' });
        i = end + close.length;
        continue;
      }
    }
    if (c === '\\' && i + 1 < src.length) { buf += src.slice(i, i + 2); i += 2; continue; }
    if (c === '`') {
      const ticks = src.slice(i).match(/^`+/)[0];
      const end = src.indexOf(ticks, i + ticks.length);
      const stop = end < 0 ? (ticks.length >= 3 ? src.length : i + ticks.length) : end + ticks.length;
      if (wantCode && (end >= 0 || ticks.length >= 3)) {
        const inner = src.slice(i + ticks.length, end < 0 ? src.length : end);
        const fenced = ticks.length >= 3 && (i === 0 || src[i - 1] === '\n') && inner.includes('\n');
        if (fenced) {
          const nl = inner.indexOf('\n');
          flush();
          out.push({ type: 'code', text: inner.slice(nl + 1).replace(/\n[ \t]*$/, ''), block: true, lang: inner.slice(0, nl).trim() });
          i = stop;
          continue;
        }
        if (inner.trim().length >= CODE_SPAN_MIN) {
          flush();
          out.push({ type: 'code', text: inner.replace(/\s+/g, ' ').trim(), block: false, lang: '' });
          i = stop;
          continue;
        }
      }
      buf += src.slice(i, stop);
      i = stop;
      continue;
    }
    if (c === '$') {
      if (src[i + 1] === '$') {
        const end = src.indexOf('$$', i + 2);
        const body = end < 0 ? '' : src.slice(i + 2, end).trim();
        if (body) { flush(); out.push({ type: 'math', source: body, display: true }); i = end + 2; continue; }
        const skip = end < 0 ? i + 2 : end + 2;      // "$$" with nothing in it, or never closed: text
        buf += src.slice(i, skip);
        i = skip;
        continue;
      } else if (i + 1 < src.length && !/\s/.test(src[i + 1])) {
        let end = -1;
        for (let j = i + 1; j < src.length && src[j] !== '\n'; j++) {
          if (src[j] === '\\') { j++; continue; }
          if (src[j] === '`') break;                 // a code span is not mathematics
          if (src[j] === '$') { if (!/\s/.test(src[j - 1]) && !/\d/.test(src[j + 1] || '')) end = j; break; }
        }
        if (end > i + 1) { flush(); out.push({ type: 'math', source: src.slice(i + 1, end), display: false }); i = end + 1; continue; }
      }
    }
    buf += c;
    i++;
  }
  flush();
  return out;
}

function hasMath(text) {
  return mathSegments(text).some(g => g.type === 'math');
}

/* Whether the typewriter has something to type: a fenced block, or a code span of a few characters or more. */
function hasCode(text) {
  return mathSegments(text, { code: true }).some(g => g.type === 'code');
}

/* The pauses of a typewriter typing `text`, in milliseconds, one per character: uneven, as a typist's are (a little
   quicker inside a word, a breath after a space or punctuation), a carriage return at each line end, and never more
   than `budget` ms in all. `seed` makes the unevenness repeatable. */
function typeCadence(text, budget, seed) {
  let x = (seed >>> 0) || 0x9e3779b9;
  const rand = () => { x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; };
  const out = [];
  for (const c of String(text)) {
    if (c === '\n') out.push(190);
    else if (c === ' ') out.push(38 + rand() * 40);
    else if (/[.,;:(){}\[\]=]/.test(c)) out.push(62 + rand() * 60);
    else out.push(30 + rand() * 46);
  }
  const total = out.reduce((a, b) => a + b, 0);
  const scale = budget > 0 && total > budget ? budget / total : 1;
  return out.map(ms => ms * scale);
}

/* The pen's script for a replacement: its segments, white space collapsed in the prose, cut to about `limit`
   characters of prose. An equation is never cut in two and never left out for want of room, however long it is or
   however far into a long paragraph it comes (it counts for at most 24 characters, and the pen writes smaller if it
   must): where the prose has run out, the few words that lead up to an equation are still written, after an
   ellipsis. Only after SCRIPT_EQUATIONS equations does the script end, with an ellipsis. Code is never left out
   either, and keeps its line breaks and its spacing:
   a block is cut to CODE_LINES lines of CODE_COLS characters, a span to CODE_COLS characters, each with an ellipsis. */
const CODE_LINES = 6, CODE_COLS = 56;
const SCRIPT_EQUATIONS = 8, SCRIPT_LEAD = 18;
function penScript(replacement, limit) {
  const max = limit || 48;
  const segs = mathSegments(String(replacement == null ? '' : replacement).trim(), { code: true })
    .map(g => (g.type === 'text' ? { type: 'text', text: g.text.replace(/\s+/g, ' ') } : g))
    .filter(g => g.type !== 'text' || g.text);
  if (segs.length && segs[0].type === 'text') segs[0].text = segs[0].text.trimStart();
  if (segs.length && segs[segs.length - 1].type === 'text') segs[segs.length - 1].text = segs[segs.length - 1].text.trimEnd();
  const out = [];
  let used = 0, full = false, equations = 0, over = false;   // full: no more prose; over: no more equations either
  const dotted = () => { const last = out[out.length - 1]; return Boolean(last && last.type === 'text' && /…\s*$/.test(last.text)); };
  const stop = () => { if (!full) { full = true; out.push({ type: 'text', text: ' …' }); } };
  // The last few words of prose, from the start of a word.
  const lead = text => {
    if (text.length <= SCRIPT_LEAD) return text;
    const tail = text.slice(text.length - SCRIPT_LEAD);
    return tail.slice(tail.indexOf(' ') + 1);
  };
  segs.forEach((g, i) => {
    const room = max - used;
    if (g.type === 'math') {
      if (over || equations >= SCRIPT_EQUATIONS) { over = true; if (!dotted()) out.push({ type: 'text', text: ' …' }); full = true; return; }
      equations++;
      out.push(g);
      used += Math.min(g.source.length, 24);
    } else if (g.type === 'code') {                     // never left out for want of room
      const clip = l => (l.length > CODE_COLS ? l.slice(0, CODE_COLS - 1) + '…' : l);
      let lines = g.block ? g.text.replace(/\t/g, '  ').split('\n') : [g.text];
      if (lines.length > CODE_LINES) lines = lines.slice(0, CODE_LINES - 1).concat('…');
      out.push({ type: 'code', text: lines.map(clip).join('\n'), block: g.block, lang: g.lang });
      used += Math.min(g.text.length, 24);
    } else if (!full) {
      if (g.text.length > room) {
        const head = g.text.slice(0, Math.max(0, room - 2)).trimEnd();
        const next = segs[i + 1], toMath = Boolean(next && next.type === 'math' && equations < SCRIPT_EQUATIONS);
        full = true;
        // prose that runs up to an equation: its last words are written too, or all of it when little would be left out
        if (toMath && g.text.length - head.length <= SCRIPT_LEAD) out.push(g);
        else {
          out.push({ type: 'text', text: head + ' …' });
          if (toMath) out.push({ type: 'text', text: ' ' + lead(g.text) });
        }
      } else {
        out.push(g);
        used += g.text.length;
        if (used >= max && i < segs.length - 1 && !segs.slice(i + 1).some(n => n.type === 'math')) stop();
        else if (used >= max) full = true;
      }
    } else if (!over) {
      // out of room: only the words that lead up to the next equation are written, or an ellipsis after the last one
      const next = segs[i + 1];
      if (next && next.type === 'math' && equations < SCRIPT_EQUATIONS) out.push({ type: 'text', text: (g.text.length <= SCRIPT_LEAD ? '' : dotted() ? ' ' : ' … ') + lead(g.text) });
      else if (!dotted()) out.push({ type: 'text', text: ' …' });
    }
  });
  return out;
}

/* How far into a piece of Markdown its first written character is: past white space and past what opens a block
   (a heading's #, a list's bullet or number, a quotation's >), which Live Preview does not show as text. The pen
   starts writing there. Equal to the text's length when it has nothing to write. */
function inkOffset(text) {
  const m = /^\s*(?:(?:#{1,6}|[-*+]|\d{1,9}[.)])[ \t]+|>[ \t]?)*/.exec(String(text == null ? '' : text));
  return m ? m[0].length : 0;
}

/* How many lines of handwriting an edit gets, and how fast they are written.
   penLines(wanted, textLines, spent, speed): the pen writes at most `wanted` lines of the text column (the setting,
   3 by default) and never more lines than the text itself takes (`textLines`); what does not fit ends in an ellipsis
   and is set down with the rest. In a run of many edits, once the handwriting of the run has taken PEN_RUN_MS (at
   pen speed 1; `spent` is in real ms), later edits get one line each, so a long run does not take minutes.
   penPace(width): ms per px of handwriting at speed 1: the released 9 ms for short pieces, faster for long ones so
   that PEN_LINE_PX-long lines take about PEN_LINES_MS / 3 each (three lines in 2.5 to 4 s). Pure. */
const PEN_RUN_MS = 10000, PEN_LINES_MS = 3300;
function penLines(wanted, textLines, spent, speed) {
  const want = Math.max(1, Math.min(8, Math.round(Number(wanted) || 3)));
  const sp = Number(speed) > 0 ? Number(speed) : 1;
  const allowed = Number(spent) * sp >= PEN_RUN_MS ? 1 : want;
  return Math.max(1, Math.min(allowed, Math.max(1, Math.round(Number(textLines) || 1))));
}
function penPace(width) {
  const w = Math.max(1, Number(width) || 0);
  return Math.min(9, Math.max(1.2, PEN_LINES_MS / w));
}

/* A typeset equation as an element, from `render(source, display)` (Obsidian's renderMath), or null when there is no
   renderer, it throws, or it returns something that isn't an element: the pen then writes the source as text. */
function renderPenMath(source, display, render) {
  if (typeof render !== 'function') return null;
  try {
    const el = render(source, Boolean(display));
    return el && el.nodeType === 1 ? el : null;
  } catch (e) {
    return null;
  }
}

/* How the pen sets an equation down, and why: {how: 'draw' | 'text', why}. 'draw' is the typeset equation, drawn
   symbol by symbol; 'text' is the fallback, the source written like other words, and `why` then says what was
   missing (it goes to the console).
   env: {renderer (obsidian.renderMath exists), loaded (MathJax is there after loadMathJax),
   error (what loading threw, if anything), typeset (renderMath gave an element), failed (MathJax marked a TeX
   error in it), symbols (how many it has)}. Pure. */
function equationPlan(env) {
  const e = env || {};
  const text = why => ({ how: 'text', why });
  if (!e.renderer) return text('this Obsidian has no renderMath');
  if (e.error) return text(`MathJax did not load (${e.error})`);
  if (!e.loaded) return text('MathJax did not load in time');
  if (!e.typeset) return text('MathJax could not typeset it');
  if (e.failed) return text('MathJax reported a TeX error');
  if (!(e.symbols > 0)) return text('the typeset equation has no symbols to draw');
  return { how: 'draw', why: '' };
}

/* The pen's trail: points [{x, y, t}] (oldest first) no older than `life` ms at `now`, as `bands` strokes from the
   newest (the darkest and widest) to the oldest: [{d, opacity, width}], d an SVG path. Neighbouring strokes share a
   point, so the line has no gaps. Pure, so it can be tested without a window. */
function trailBands(points, now, life, bands) {
  const out = [];
  const live = points.filter(p => now - p.t <= life && now - p.t >= 0);
  if (live.length < 2) return out;
  const groups = Array.from({ length: bands }, () => []);
  for (const p of live) groups[Math.min(bands - 1, Math.floor(((now - p.t) / life) * bands))].push(p);
  let newer = null;                                   // the oldest point of the band before (nearer the nib)
  for (let i = 0; i < bands; i++) {
    const g = groups[i];
    if (!g.length) continue;
    const pts = newer ? g.concat([newer]) : g;
    newer = g[0];
    if (pts.length < 2) continue;
    const k = 1 - i / bands;
    out.push({
      d: 'M' + pts.map(p => `${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join('L'),
      opacity: Number((0.5 * k * k).toFixed(3)),
      width: Number((0.6 + 1.8 * k).toFixed(2)),
    });
  }
  return out;
}

/* {type, message} from an error response body (Anthropic: {"type":"error","error":{"type","message"}}; OpenAI-style
   servers: {"error":{"message"}} or {"error":"..."}). Falls back to a short plain-text body. */
function parseErrorBody(text) {
  const raw = String(text || '').trim();
  try {
    const d = JSON.parse(raw);
    const e = d && d.error;
    if (e && typeof e === 'object') return { type: e.type || e.code || null, message: e.message || null };
    if (typeof e === 'string') return { type: null, message: e };
    if (d && typeof d.message === 'string') return { type: d.type || null, message: d.message };
  } catch (err) { /* not JSON */ }
  if (raw && raw.length <= 300 && !/^\s*</.test(raw)) return { type: null, message: raw };
  return { type: null, message: null };
}

/* A sentence for the writer, from an HTTP status and/or an API error type. */
function describeError({ provider, status, type, message, model, retryAfter }) {
  const anthropic = provider === 'anthropic';
  const who = anthropic ? 'Anthropic' : 'The server';
  const detail = message ? `: ${String(message).replace(/\s+/g, ' ').trim().replace(/\.$/, '')}` : '';
  if (status === 401 || type === 'authentication_error') {
    return `${who} did not accept the API key (401). Check it in Settings → Lagrange.`;
  }
  if (status === 402 || type === 'billing_error') return `${who} reports a billing problem with this account (402)${detail}.`;
  if (status === 403 || type === 'permission_error') return `This API key is not allowed to do that (403)${detail}.`;
  if (status === 404 || type === 'not_found_error') {
    return anthropic
      ? `The model “${model}” was not found, or this key cannot use it (404). Choose another in Settings → Lagrange.`
      : `Not found (404)${detail}. Check the base URL and the model name in Settings → Lagrange.`;
  }
  if (status === 413 || type === 'request_too_large') return 'The request was too large (413): the note is too long to send at once.';
  if (status === 429 || type === 'rate_limit_error') {
    return `Rate limited (429)${retryAfter ? `: try again in ${retryAfter} seconds` : ': wait a little and try again'}.`;
  }
  if (status === 529 || type === 'overloaded_error') return `${who} is overloaded at the moment (529). Try again shortly.`;
  if ((status && status >= 500) || type === 'api_error') return `${who} had an internal error (${status || 500}). Try again shortly.`;
  if (status === 400 || type === 'invalid_request_error') return `${who} could not accept the request (400)${detail}.`;
  return `${who} returned an error${status ? ` (${status})` : ''}${detail}.`;
}

function networkMessage(provider, url) {
  if (provider === 'anthropic') return 'Could not reach api.anthropic.com. Check your internet connection and try again.';
  let host = url;
  try { host = new URL(url).host; } catch (e) { /* keep the URL */ }
  return `Could not reach ${host}. Is the server running, and does it accept requests from Obsidian (CORS)? ` +
    'Ollama does by default; LM Studio needs CORS turned on.';
}

/* Words, paragraphs and headings of a Markdown note, and its first sentence of prose (for the demo). */
function noteStats(text) {
  const lines = String(text || '').split('\n');
  let headings = 0, paragraphs = 0, inPara = false, first = null, fenced = false;
  for (const line of lines) {
    if (/^\s*(```|~~~)/.test(line)) { fenced = !fenced; inPara = false; continue; }
    if (fenced) continue;
    if (/^#{1,6}\s/.test(line)) { headings++; inPara = false; continue; }
    if (!line.trim() || /^\s*(---|\*\*\*|___)\s*$/.test(line)) { inPara = false; continue; }
    if (/^\s*>/.test(line)) { inPara = false; continue; }
    if (!inPara) { paragraphs++; inPara = true; }
    if (first === null) {
      const plain = line.replace(/[*_`~]/g, '').trim();
      const m = plain.match(/^.*?[.!?](?=\s|$)/);
      first = m ? m[0] : plain;
    }
  }
  const words = (String(text || '').replace(/[#>*_`~[\]|-]/g, ' ').match(/[\p{L}\p{N}’'-]+/gu) || []).length;
  return { words, paragraphs, headings, firstSentence: first };
}

function excerpt(text, n) {
  const t = String(text || '');
  if (t.length <= n) return t;
  const head = Math.round(n * 0.7), tail = Math.max(10, n - head - 3);
  return t.slice(0, head).trimEnd() + ' … ' + t.slice(-tail).trimStart();
}

/* ---- Demo (offline) replies ---- */

// Edits for the Lorem Ipsum sample note, so the demo has something to proofread there (each occurs once in it).
const DEMO_SAMPLE_EDITS = [
  { find: 'erat a ante venenatis', replace: 'erat ante venenatis', reason: 'demo: a stray word' },
  { find: 'mollis interdum, sed posuere', replace: 'mollis interdum; sed posuere', reason: 'demo: a semicolon between two clauses' },
  { find: 'bibendum nulla sed consectetur', replace: 'bibendum nulla, sed consectetur', reason: 'demo: a comma before “sed”' },
];

// Typographic slips the demo can find in any note. Each pattern matches exactly the text to change.
const DEMO_RULES = [
  { re: /(?<=\S) {2,}(?=\S)/g, fix: () => ' ', reason: 'a doubled space' },
  { re: /(?<=\S) - (?=\S)/g, fix: () => '—', reason: 'a spaced hyphen used as a dash' },
  { re: /(?<=\w)--(?=\w)/g, fix: () => '—', reason: 'two hyphens for a dash' },
  { re: /\.\.\./g, fix: () => '…', reason: 'three full stops for an ellipsis' },
  { re: /"([^"\n]{1,120})"/g, fix: m => '“' + m[1] + '”', reason: 'straight quotation marks' },
  { re: /(?<=\w)'(?=\w)/g, fix: () => '’', reason: 'a straight apostrophe' },
  { re: /\b([A-Za-z]+) \1\b/g, fix: m => m[1], reason: 'a doubled word' },
];

/* [a, b): [from, to) widened to whole words, then word by word on both sides, until it occurs once in doc. */
function uniqueContext(doc, from, to) {
  let a = from, b = to;
  while (a > 0 && !/\s/.test(doc[a - 1])) a--;
  while (b < doc.length && !/\s/.test(doc[b])) b++;
  for (let step = 0; step < 12; step++) {
    if (findAll(doc, doc.slice(a, b)).length === 1) return [a, b];
    let a2 = a, b2 = b;
    while (a2 > 0 && /\s/.test(doc[a2 - 1])) a2--;
    while (a2 > 0 && !/\s/.test(doc[a2 - 1])) a2--;
    while (b2 < doc.length && /\s/.test(doc[b2])) b2++;
    while (b2 < doc.length && !/\s/.test(doc[b2])) b2++;
    if (a2 === a && b2 === b) break;
    a = a2; b = b2;
  }
  return null;
}

/* Ranges of a note the demo must not change: front matter, code, math, comments, HTML tags, tables, link and image
   destinations (where a curled quote would break a title), wikilinks and embeds, and bare URLs. */
function demoSkipRanges(text) {
  const skip = [];
  const fm = text.match(/^---\n[\s\S]*?\n---\n/);
  if (fm) skip.push([0, fm[0].length]);
  const patterns = [
    /```[\s\S]*?```|~~~[\s\S]*?~~~|`[^`\n]*`/g,     // code
    /\$\$[\s\S]*?\$\$|\$[^$\n]+\$/g,                // math
    /%%[\s\S]*?%%|<!--[\s\S]*?-->/g,               // comments
    /<\/?[A-Za-z][^>\n]*>/g,                         // HTML tags
    /^[ \t]*\|.*$/gm,                                 // table rows
    /\]\((?:[^()\n]|\([^()\n]*\))*\)/g,                 // link and image destinations, with their titles
    /^[ \t]*\[[^\]\n]+\]:.*$/gm,                        // reference link definitions
    /!?\[\[[^\]\n]*\]\]/g,                              // wikilinks and embeds
    /\b[a-z][a-z0-9+.-]*:\/\/[^\s<>()]+/gi,              // bare URLs
  ];
  for (const re of patterns) for (const m of text.matchAll(re)) skip.push([m.index, m.index + m[0].length]);
  return skip;
}

/* The demo's proofreading: typographic slips anywhere (fixes close together become one edit), then, in the Lorem
   Ipsum sample, a few made-up corrections so there is always something to show. */
function demoProofreadEdits(doc) {
  const text = String(doc || '');
  const skip = demoSkipRanges(text);   // front matter, code and Markdown syntax are never touched
  const overlaps = (list, a, b) => list.some(([s, e]) => a < e && s < b);
  const fixes = [];
  for (const rule of DEMO_RULES) {
    for (const m of text.matchAll(rule.re)) {
      const from = m.index, to = m.index + m[0].length;
      if (overlaps(skip, from, to) || overlaps(fixes.map(f => [f.from, f.to]), from, to)) continue;
      fixes.push({ from, to, insert: rule.fix(m), reason: rule.reason });
    }
  }
  fixes.sort((x, y) => x.from - y.from);
  const groups = [];
  for (const f of fixes) {
    const ctx = uniqueContext(text, f.from, f.to);
    if (!ctx) continue;
    const g = groups[groups.length - 1];
    if (g && ctx[0] <= g.b) { g.b = Math.max(g.b, ctx[1]); g.fixes.push(f); }
    else groups.push({ a: ctx[0], b: ctx[1], fixes: [f] });
  }
  const edits = [];
  const taken = [];
  for (const g of groups) {
    const ctx = uniqueContext(text, g.a, g.b);
    if (!ctx || overlaps(taken, ctx[0], ctx[1])) continue;
    let replace = text.slice(ctx[0], ctx[1]);
    for (const f of g.fixes.slice().reverse()) {
      replace = replace.slice(0, f.from - ctx[0]) + f.insert + replace.slice(f.to - ctx[0]);
    }
    edits.push({ find: text.slice(ctx[0], ctx[1]), replace, reason: [...new Set(g.fixes.map(f => f.reason))].join('; ') });
    taken.push(ctx);
    if (edits.length >= 6) return edits;
  }
  for (const e of DEMO_SAMPLE_EDITS) {
    const hits = findAll(text, e.find);
    if (hits.length === 1 && !overlaps(taken, hits[0][0], hits[0][1])) edits.push(Object.assign({}, e));
  }
  return edits.slice(0, 6);
}

function titleCase(t) {
  const small = /^(a|an|and|as|at|but|by|for|in|of|on|or|the|to|via)$/i;
  let first = true;
  return t.replace(/[\p{L}\p{N}’']+/gu, w => {
    const out = !first && small.test(w) ? w.toLowerCase() : w[0].toUpperCase() + w.slice(1);
    first = false;
    return out;
  });
}

function splitSentences(t) {
  return t.match(/[^.!?…]+[.!?…]+["”’)*_]*\s*|[^.!?…]+$/g) || [t];
}

function demoRevise(passage, instruction) {
  const t = String(passage || '');
  const i = String(instruction || '').toLowerCase();
  if (/upper|capital/.test(i)) return t.toUpperCase();
  if (/lower/.test(i)) return t.toLowerCase();
  if (/title/.test(i)) return titleCase(t);
  if (/short|concise|trim|tight|brief|cut/.test(i)) {
    const s = splitSentences(t.trim());
    if (s.length > 1) return s.slice(0, Math.ceil(s.length / 2)).join('').trim();
    const words = t.trim().split(/\s+/);
    return words.slice(0, Math.max(1, Math.ceil(words.length * 0.6))).join(' ').replace(/[,;:]$/, '') + '…';
  }
  let out = t;
  for (const rule of DEMO_RULES) out = out.replace(rule.re, (...args) => rule.fix(args));   // args: match, groups…
  if (out !== t) return out;
  const s = splitSentences(t.trim());
  if (s.length > 1) return s.map(x => x.trim()).reverse().join(' ');
  return titleCase(t);
}

/* The demo's edits block for a chat message that asks for a change, or '' when it asks for none: "fix", "proofread"
   or "correct" proofreads; "equation" or "formula" adds one; "code" or "function" adds a code block; "add" or
   "append" adds a line. */
function demoChatEdits(question, note) {
  const q = String(question || '').toLowerCase();
  let ops = null;
  if (/\b(equation|formula|math)/.test(q)) {
    ops = [{ append: 'The Euler–Lagrange equation: $$\\frac{d}{dt}\\frac{\\partial L}{\\partial \\dot{q}} - \\frac{\\partial L}{\\partial q} = 0$$' }];
  } else if (/\b(code|function|script|snippet|program)/.test(q)) {
    ops = [{ append: 'The distance to the first Lagrange point, with `hill_radius(m1, m2, r)`:\n\n```python\ndef hill_radius(m1, m2, r):\n    # where a small body between two masses can rest\n    return r * (m2 / (3 * m1)) ** (1 / 3)\n```' }];
  } else if (/\b(fix|proofread|correct|tidy|clean)/.test(q)) {
    ops = demoProofreadEdits(note.text);
  } else if (/\b(add|append|write)\b/.test(q)) {
    ops = [{ append: 'A line added by Lagrange in demo mode.' }];
  }
  return ops && ops.length ? '```lagrange-edits\n' + JSON.stringify(ops, null, 2) + '\n```' : '';
}

function demoChatReply(question, note, agentic) {
  const parts = ['*Demo mode: a canned reply, written without a model. Choose a Claude or ChatGPT subscription, an ' +
    'API key or an OpenAI-compatible server in Settings → Lagrange for real answers.*'];
  if (agentic && note) {
    const block = demoChatEdits(question, note);
    if (block) return parts.concat(`Here is what the pen will set down in **${note.title}**.`, block).join('\n\n');
  }
  if (note) {
    const st = noteStats(note.text);
    const pl = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
    parts.push(`I have read **${note.title}**: ${pl(st.words, 'word')} in ${pl(st.paragraphs, 'paragraph')}` +
      (st.headings ? `, under ${pl(st.headings, 'heading')}.` : '.') +
      (st.firstSentence ? ` It opens: “${excerpt(st.firstSentence, 160)}”` : ''));
  } else {
    parts.push('No note is open, so there is nothing for me to read yet.');
  }
  parts.push(`You asked: “${excerpt(String(question || '').replace(/\s+/g, ' '), 160)}” A model would answer here, ` +
    'with the note in mind.');
  parts.push('The edits work offline in demo mode:\n\n' +
    (agentic ? '- Ask here to *fix the typography*, to *add a line*, to *add an equation* or to *add some code*, and the pen does it.\n' : '') +
    '- **Proofread note** finds typographic slips (straight quotes, spaced hyphens, doubled spaces) and sets the ' +
    'corrections down with the pen.\n' +
    '- **Revise selection** rewrites the selected passage: ask for it *shorter*, *in title case* or *in capitals*.\n\n' +
    'One undo (Ctrl+Z or Cmd+Z) takes back all the edits of a request.');
  return parts.join('\n\n');
}


/* ---------------------------------------------------------------------------------------------------------------
 * 3. Providers
 *
 * complete(settings, req, hooks, session) -> Promise<{text, stopReason, stopDetails, model, fallbackTo}>
 *   req:     {purpose: 'chat'|'proofread'|'revise', system, messages: [{role, content}], cache, demo: () => string}
 *   hooks:   {signal, onText(delta, fullText), onRetry(status, ms), fetch, retryDelays}
 *   session: {noFallback, noEffort: {}}, what this run of Obsidian has learnt a provider won't take
 * The reasoning effort (settings.effort) goes out only where the provider and model take one (effortFor); if a
 * provider still rejects it, the request is sent again without it and the session remembers.
 * Throws LagrangeError with a sentence for the writer, or an AbortError when stopped.
 * ------------------------------------------------------------------------------------------------------------- */

/* ---- Drawing a drop cap ----
   "Lagrange: Draw a drop cap" has the provider draw an ornamental initial, which the Scriptorium plugin keeps as a
   set of drop caps in the vault and inks into the note. How it is drawn depends on the provider (dropcapRoute):
     - 'image-api': OpenAI's Images API (the OpenAI API provider), a PNG.
     - 'codex-image': Codex's own image tool (the ChatGPT subscription provider), a PNG.
     - 'svg': every other provider has no image model to call, so the language model writes the initial as an SVG
       drawing; the Demo has one of its own.
   An existing initial can be changed: an image goes back to the image model with the instruction (the Images API's
   edits, or attached to Codex); an SVG goes back to the language model as text. */

function dropcapRoute(s) {
  if (s.provider === 'openai-api') return 'image-api';
  if (s.provider === 'codex') return 'codex-image';
  return 'svg';
}

/* How the chosen provider would draw, in a sentence for the dialogue. */
function dropcapRouteNote(s) {
  const route = dropcapRoute(s);
  if (route === 'image-api') {
    return `OpenAI’s image model (${String(s.openaiImageModel || '').trim() || DEFAULT_SETTINGS.openaiImageModel}) will paint it, through your API key; OpenAI charges for each image. Experimental: this route has not been tried against the live API.`;
  }
  if (route === 'codex-image') return 'ChatGPT will paint it with Codex’s image tool, on your subscription. It takes a minute or so.';
  if (s.provider === 'demo') return 'The Demo has one drawing of its own, the same for every description. Choose a provider in Settings → Lagrange for a real one.';
  return `${modelLabel(s)} has no image model that Lagrange can call, so it will write the initial as a line drawing (SVG). For a painted one, choose “ChatGPT: my subscription” or “OpenAI API” in Settings → Lagrange. (Image connectors such as Canva’s are not used: through Claude Code, Canva’s hands back only a thumbnail.)`;
}

function dropcapLetter(text) {
  const m = String(text || '').match(/\p{L}/u);
  const c = m ? m[0].normalize('NFD')[0].toUpperCase() : '';
  return /^[A-Z]$/.test(c) ? c : '';
}

/* The request to an image model. req: {letter, style, mono, change}; change is the instruction when an existing
   image is being changed. */
function dropcapImagePrompt(req) {
  const style = String(req.style || '').trim() || 'a woodcut initial with vine leaves';
  const ink = req.mono
    ? 'Pure black ink only, on a plain white ground: no grey wash, no colour, no paper texture.'
    : 'On a plain, even ground with nothing else on it.';
  const rules = `One letter only, large, upright and plainly legible as a capital ${req.letter}; square; the design fills the square to its edges; no other letters, words, signature or border of text.`;
  if (req.change) {
    return `This image is an ornamental drop cap: the capital letter ${req.letter}, the initial that opens a chapter in a printed book. ` +
      `Change it as follows, keeping the letter and the manner of the drawing otherwise: ${String(req.change).trim()}. ${ink} ${rules}`;
  }
  return `An ornamental drop cap: the capital letter ${req.letter}, the initial that opens a chapter in a finely printed book. Style: ${style}. ${ink} ${rules}`;
}

const DROPCAP_SVG_SYSTEM =
  'You draw ornamental initials (drop caps) for a book page as SVG. Answer with one complete SVG document and nothing ' +
  'else: no prose, no code fence. Rules: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">; the letter ' +
  'drawn with paths (no <text>, no fonts), large, bold and plainly legible; ornament around and behind it; a clear ' +
  'ground (no background rectangle); no scripts, links, images, external references or animation; under 16 kB.';

function dropcapSvgMessage(req) {
  const style = String(req.style || '').trim() || 'a woodcut initial with vine leaves and a ruled square frame';
  const ink = req.mono ? 'Use pure black only (fill="#000" or stroke="#000"): it will be printed in the page’s own ink colour.' : 'Use a few flat colours that suit a book page.';
  if (req.change && req.base) {
    return `Here is a drop cap, the capital letter ${req.letter}, as SVG:\n\n${req.base}\n\nChange it as follows, keeping the letter and the manner of the drawing otherwise: ${String(req.change).trim()}. ${ink} Answer with the whole changed SVG.`;
  }
  return `Draw the capital letter ${req.letter} as a drop cap. Style: ${style}. ${ink}`;
}

/* The SVG document in a reply ('' if it has none). */
function extractSvg(text) {
  const t = String(text || '');
  const a = t.search(/<svg[\s>]/i), b = t.toLowerCase().lastIndexOf('</svg>');
  return a >= 0 && b > a ? t.slice(a, b + 6) : '';
}

/* The Demo's drop cap: a ruled frame with corner leaves, and the letter in the reader's serif. */
function demoDropcapSvg(letter) {
  const leaf = (x, y, r) => `<path transform="translate(${x} ${y}) rotate(${r})" d="M0 0C14-22 44-26 62-8C44 6 16 10 0 0ZM6-2C24-10 40-10 54-7" fill="none" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>`;
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">' +
    '<rect x="14" y="14" width="372" height="372" fill="none" stroke="#000" stroke-width="8"/>' +
    '<rect x="30" y="30" width="340" height="340" fill="none" stroke="#000" stroke-width="2.5"/>' +
    leaf(52, 78, -20) + leaf(348, 78, 200) + leaf(52, 322, 20) + leaf(348, 322, 160) +
    '<path d="M70 200C110 150 150 250 200 200S290 150 330 200" fill="none" stroke="#000" stroke-width="3" stroke-dasharray="2 9" stroke-linecap="round"/>' +
    `<text x="200" y="296" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-size="300" font-weight="700" fill="#000">${dropcapLetter(letter) || 'A'}</text>` +
    '</svg>';
}

function bytesFromBase64(b64) {
  const bin = atob(String(b64 || '').replace(/\s+/g, ''));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function base64FromBytes(bytes) {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

function isPng(bytes) {
  return Boolean(bytes && bytes.length > 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47);
}

const RETRY_STATUSES = new Set([429, 500, 502, 503, 504, 529]);

/* The effort for this request, unless this session has already seen `key` (a provider and model) refuse one. */
function sessionEffort(s, session, key) {
  const e = effortFor(s);
  return e && !(session && session.noEffort && session.noEffort[key]) ? e : '';
}

function forgetEffort(session, key) {
  if (!session) return;
  if (!session.noEffort) session.noEffort = {};
  session.noEffort[key] = true;
}

function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal && signal.aborted) { reject(abortError()); return; }
    const t = setTimeout(() => { if (signal) signal.removeEventListener('abort', onAbort); resolve(); }, Math.max(0, ms));
    const onAbort = () => { clearTimeout(t); reject(abortError()); };
    if (signal) signal.addEventListener('abort', onAbort, { once: true });
  });
}

/* fetch, retried (twice, after a pause) on rate limits, overloads and server errors before any of the reply has been
   read; a network failure becomes a LagrangeError that says what to check. */
async function fetchWithRetry(provider, url, init, hooks) {
  const doFetch = hooks.fetch || fetch;
  const delays = hooks.retryDelays || [1500, 4000];
  for (let attempt = 0; ; attempt++) {
    let res;
    try {
      res = await doFetch(url, init);
    } catch (e) {
      if (isAbort(e) || (init.signal && init.signal.aborted)) throw abortError();
      throw new LagrangeError(networkMessage(provider, url), { kind: 'network', cause: e });
    }
    if (!RETRY_STATUSES.has(res.status) || attempt >= delays.length) return res;
    const ra = Number(res.headers && res.headers.get('retry-after'));
    if (res.status === 429 && ra > 20) return res;
    const wait = ra > 0 ? ra * 1000 : delays[attempt];
    try { if (res.body && res.body.cancel) await res.body.cancel(); } catch (e) { /* ignore */ }
    if (hooks.onRetry) hooks.onRetry(res.status, wait);
    await sleep(wait, init.signal);
  }
}

async function safeText(res) {
  try { return await res.text(); } catch (e) { return ''; }
}

function httpError(provider, res, bodyText, model) {
  const info = parseErrorBody(bodyText);
  const ra = Number(res.headers && res.headers.get('retry-after'));
  return new LagrangeError(describeError({
    provider, status: res.status, type: info.type, message: info.message, model, retryAfter: ra > 0 ? ra : null,
  }), { kind: 'http', status: res.status });
}

/* Reads a streamed response as server-sent events. */
async function readSSE(res, onEvent) {
  const parser = createSSEParser(onEvent);
  if (!res.body || typeof res.body.getReader !== 'function') {
    parser.push(await res.text());
    parser.end();
    return;
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      parser.push(decoder.decode(value, { stream: true }));
    }
    parser.push(decoder.decode());
    parser.end();
  } catch (e) {
    try { await reader.cancel(); } catch (err) { /* already closed */ }
    if (isAbort(e)) throw abortError();
    throw e;
  }
}

/* Applies one Messages API stream event to st ({text, stopReason, stopDetails, model, fallbackTo}); returns the text
   it added. Thinking blocks are skipped (only text is shown); a "fallback" block marks a server-side retry on another
   model after a refusal, and the text before and after it continues one reply. An "error" event throws. */
function applyAnthropicEvent(st, ev) {
  if (!ev || !ev.data) return '';
  let d;
  try { d = JSON.parse(ev.data); } catch (e) { return ''; }
  switch (d.type) {
    case 'message_start':
      if (d.message && d.message.model) st.model = d.message.model;
      return '';
    case 'content_block_start': {
      const b = d.content_block || {};
      if (b.type === 'text' && typeof b.text === 'string' && b.text) { st.text += b.text; return b.text; }
      if (b.type === 'fallback') st.fallbackTo = (b.to && b.to.model) || 'another model';
      return '';
    }
    case 'content_block_delta':
      if (d.delta && d.delta.type === 'text_delta' && typeof d.delta.text === 'string') {
        st.text += d.delta.text;
        return d.delta.text;
      }
      return '';
    case 'message_delta':
      if (d.delta && d.delta.stop_reason) st.stopReason = d.delta.stop_reason;
      if (d.delta && d.delta.stop_details) st.stopDetails = d.delta.stop_details;
      return '';
    case 'error': {
      const err = d.error || {};
      throw new LagrangeError(describeError({ provider: 'anthropic', type: err.type, message: err.message }),
        { kind: 'stream', type: err.type });
    }
    default:
      return '';
  }
}

async function streamAnthropic(s, req, hooks, session) {
  const key = String(s.anthropicApiKey || '').trim();
  if (!key) {
    throw new LagrangeError('Lagrange needs an Anthropic API key: add one in Settings → Lagrange, or choose the ' +
      'Demo provider there to try Lagrange offline.', { kind: 'setup' });
  }
  const model = anthropicModelId(s);
  if (!model) throw new LagrangeError('Choose a Claude model in Settings → Lagrange.', { kind: 'setup' });
  const preset = ANTHROPIC_MODELS.find(m => m.id === model);
  const body = {
    model,
    max_tokens: preset ? MAX_TOKENS : MAX_TOKENS_CUSTOM,
    stream: true,
    system: req.system,
    messages: req.messages,
  };
  if (req.cache) body.cache_control = { type: 'ephemeral' };   // reuses the note across turns of one conversation
  const headers = {
    'content-type': 'application/json',
    'x-api-key': key,
    'anthropic-version': ANTHROPIC_VERSION,
    'anthropic-dangerous-direct-browser-access': 'true',        // lets the API answer a browser (Obsidian) directly
  };
  const send = (withFallback, effort) => {
    const h = Object.assign({}, headers);
    const b = Object.assign({}, body);
    if (withFallback) { h['anthropic-beta'] = FALLBACK_BETA; b.fallbacks = 'default'; }
    if (effort) b.output_config = { effort };                   // thinking stays adaptive (the default); effort sets its depth
    return fetchWithRetry('anthropic', ANTHROPIC_URL,
      { method: 'POST', headers: h, body: JSON.stringify(b), signal: hooks.signal }, hooks);
  };
  let fallback = Boolean(s.refusalFallback && preset && preset.fallback && !(session && session.noFallback));
  let effort = sessionEffort(s, session, `anthropic:${model}`);
  let res;
  for (;;) {
    res = await send(fallback, effort);
    if (res.ok) break;
    const text = await safeText(res);
    const info = parseErrorBody(text);
    const said = info.message || text;
    // An account without the fallback beta gets a 400 naming it: carry on without fallbacks for this session.
    if (fallback && res.status === 400 && /anthropic-beta|fallback/i.test(said)) {
      if (session) session.noFallback = true;
      fallback = false;
    // A model that takes no effort (a custom ID for an older model) says so: carry on without it.
    } else if (effort && res.status === 400 && /effort|output_config/i.test(said)) {
      forgetEffort(session, `anthropic:${model}`);
      effort = '';
    } else {
      throw httpError('anthropic', res, text, model);
    }
  }
  const st = { text: '', stopReason: null, stopDetails: null, model: null, fallbackTo: null };
  await readSSE(res, ev => {
    const delta = applyAnthropicEvent(st, ev);
    if (delta && hooks.onText) hooks.onText(delta, st.text);
  });
  return { text: st.text, stopReason: st.stopReason, stopDetails: st.stopDetails, model: st.model || model, fallbackTo: st.fallbackTo };
}

/* Applies one chat-completions stream chunk (or a whole non-streamed response) to st; returns the text it added. */
function applyOpenAIEvent(st, ev) {
  const data = String((ev && ev.data) || '').trim();
  if (!data) return '';
  if (data === '[DONE]') { st.done = true; return ''; }
  let d;
  try { d = JSON.parse(data); } catch (e) { return ''; }
  if (d.error) {
    const e = typeof d.error === 'string' ? { message: d.error } : d.error;
    throw new LagrangeError(describeError({ provider: 'openai', type: e.type || e.code, message: e.message }), { kind: 'stream' });
  }
  const c = d.choices && d.choices[0];
  if (!c) return '';
  let piece = '';
  if (c.delta && typeof c.delta.content === 'string') piece = c.delta.content;
  else if (c.message && typeof c.message.content === 'string') piece = c.message.content;
  if (c.finish_reason) st.stopReason = c.finish_reason === 'length' ? 'max_tokens' : c.finish_reason;
  st.text += piece;
  return piece;
}

async function streamOpenAI(s, req, hooks, session) {
  const base = String(s.openaiBaseUrl || '').trim().replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(base)) {
    throw new LagrangeError('Enter the server’s base URL in Settings → Lagrange, for example http://localhost:11434/v1.', { kind: 'setup' });
  }
  const model = String(s.openaiModel || '').trim();
  if (!model) {
    throw new LagrangeError('Enter the name of the model your server runs (for example llama3.1) in Settings → Lagrange.', { kind: 'setup' });
  }
  const headers = { 'content-type': 'application/json' };
  const key = String(s.openaiApiKey || '').trim();
  if (key) headers.authorization = `Bearer ${key}`;
  const url = `${base}/chat/completions`;
  const body = { model, stream: true, messages: [{ role: 'system', content: req.system }].concat(req.messages) };
  // Only OpenAI's own reasoning models are sent an effort (effortSupported); a local server never is.
  let effort = sessionEffort(s, session, `openai:${model}`);
  let res;
  for (;;) {
    const b = effort ? Object.assign({ reasoning_effort: effort }, body) : body;
    res = await fetchWithRetry('openai', url, { method: 'POST', headers, body: JSON.stringify(b), signal: hooks.signal }, hooks);
    if (res.ok) break;
    const text = await safeText(res);
    if (effort && res.status === 400 && /reasoning|effort/i.test(parseErrorBody(text).message || text)) {
      forgetEffort(session, `openai:${model}`);
      effort = '';
      continue;
    }
    throw httpError('openai', res, text, model);
  }
  const st = { text: '', stopReason: null, done: false };
  const onEvent = ev => {
    const delta = applyOpenAIEvent(st, ev);
    if (delta && hooks.onText) hooks.onText(delta, st.text);
  };
  const type = (res.headers && res.headers.get('content-type')) || '';
  if (/application\/json/i.test(type)) onEvent({ data: await res.text() });   // a server that ignored "stream"
  else await readSSE(res, onEvent);
  return { text: st.text, stopReason: st.stopReason, stopDetails: null, model, fallbackTo: null };
}

/* ---- Subscriptions: Claude through Claude Code, ChatGPT through Codex (desktop only) ----
   A Claude Pro/Max or ChatGPT Plus/Pro subscription can't be used by calling an API directly; the sanctioned way is
   each company's own command-line tool, signed in to the writer's account: Claude Code (`claude`) and Codex (`codex`).
   Lagrange runs the tool once per request, with every tool, setting file and session file turned off, gives it the
   prompt on stdin, and reads its JSON event stream. Node's child_process is loaded only here, only on desktop. */

// Node modules, loaded lazily so the plugin still loads on mobile, where the subscription providers are unavailable.
function nodeModule(name) {
  if (obsidian.Platform && obsidian.Platform.isDesktopApp === false) {
    throw new LagrangeError('Signing in with a subscription works only in Obsidian on a computer: it runs the ' +
      'provider’s command-line tool. On a phone or tablet, choose an API key provider (or the Demo) in Settings → Lagrange.', { kind: 'setup' });
  }
  return require(name);   // eslint-disable-line global-require
}

const CLI = {
  claude: {
    label: 'Claude Code',
    install: 'Install Claude Code (claude.com/code), then run “claude” once in a terminal and sign in with your Claude account.',
    login: 'Claude Code isn’t signed in. Open a terminal, run “claude”, and sign in with your Claude Pro or Max account.',
  },
  codex: {
    label: 'Codex',
    install: 'Install Codex (npm install -g @openai/codex, or see developers.openai.com/codex), then run “codex login” and choose “Sign in with ChatGPT”.',
    login: 'Codex isn’t signed in. Open a terminal, run “codex login”, and choose “Sign in with ChatGPT”.',
  },
};

/* Where the tools usually live. Obsidian started from the dock doesn't see the shell's PATH, so look in the usual
   install folders as well as PATH. Returns the first path that exists, or null. */
function findCli(name, custom) {
  const fs = nodeModule('fs'), path = nodeModule('path'), os = nodeModule('os');
  const want = String(custom || '').trim();
  if (want) return fs.existsSync(want) ? want : null;
  const home = os.homedir(), win = process.platform === 'win32';
  const exts = win ? ['.exe', '.cmd', ''] : [''];
  const dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean).concat(win
    ? [path.join(home, '.local', 'bin'), path.join(process.env.APPDATA || path.join(home, 'AppData', 'Roaming'), 'npm'),
       path.join(home, 'AppData', 'Local', 'Programs', name)]
    : [path.join(home, '.local', 'bin'), path.join(home, '.claude', 'local'), '/opt/homebrew/bin', '/usr/local/bin',
       path.join(home, '.npm-global', 'bin'), path.join(home, '.bun', 'bin'), path.join(home, '.volta', 'bin'), '/usr/bin']);
  for (const d of dirs) for (const e of exts) {
    const p = path.join(d, name + e);
    try { if (fs.statSync(p).isFile()) return p; } catch (err) { /* not here */ }
  }
  return null;
}

/* One prompt from the conversation: the tools take a single message, so earlier turns become a short transcript. */
function transcriptPrompt(messages) {
  const msgs = (messages || []).filter(m => m && typeof m.content === 'string');
  if (msgs.length <= 1) return msgs.length ? msgs[0].content : '';
  const last = msgs[msgs.length - 1];
  const earlier = msgs.slice(0, -1).map(m => `${m.role === 'assistant' ? 'Lagrange' : 'Writer'}: ${m.content}`).join('\n\n');
  return `<conversation_so_far>\n${earlier}\n</conversation_so_far>\n\nThe writer now says:\n\n${last.content}`;
}

/* Applies one line of `claude -p --output-format stream-json --include-partial-messages` to st; returns new text. */
function applyClaudeCodeLine(st, line) {
  line = String(line || '').trim();
  if (!line) return '';
  let e;
  try { e = JSON.parse(line); } catch (err) { return ''; }
  if (e.type === 'stream_event' && e.event && e.event.type === 'content_block_delta' && e.event.delta
      && e.event.delta.type === 'text_delta' && typeof e.event.delta.text === 'string') {
    st.text += e.event.delta.text;
    st.streamed = true;
    return e.event.delta.text;
  }
  if (e.type === 'stream_event' && e.event && e.event.type === 'message_delta' && e.event.delta && e.event.delta.stop_reason) {
    st.stopReason = e.event.delta.stop_reason;
  }
  if (e.type === 'system' && e.subtype === 'init' && e.model) st.model = e.model;
  if (e.type === 'assistant' && !st.streamed && e.message && Array.isArray(e.message.content)) {
    const t = e.message.content.filter(b => b && b.type === 'text').map(b => b.text).join('');
    if (t) { st.text += t; return t; }
  }
  if (e.type === 'result') {
    st.done = true;
    if (e.is_error) st.error = String(e.result || (e.errors && e.errors.join(' ')) || e.subtype || 'Claude Code reported an error.');
    else if (!st.text && typeof e.result === 'string') { st.text = e.result; return e.result; }
  }
  return '';
}

/* Applies one line of `codex exec --json` to st; returns new text. */
function applyCodexLine(st, line) {
  line = String(line || '').trim();
  if (!line) return '';
  let e;
  try { e = JSON.parse(line); } catch (err) { return ''; }
  const item = e.item || (e.msg && { type: e.msg.type, text: e.msg.message });
  if ((e.type === 'item.completed' || (e.msg && e.msg.type === 'agent_message')) && item && item.type === 'agent_message' && typeof item.text === 'string') {
    const add = (st.text ? '\n\n' : '') + item.text;
    st.text += add;
    return add;
  }
  if (e.type === 'turn.completed') st.done = true;
  if (e.type === 'error' || e.type === 'turn.failed' || (e.msg && e.msg.type === 'error')) {
    st.error = String((e.error && e.error.message) || e.message || (e.msg && e.msg.message) || 'Codex reported an error.');
  }
  return '';
}

function cliErrorMessage(which, text) {
  const t = String(text || '');
  if (/log ?in|logged in|sign ?in|authenticat|unauthori[sz]ed|invalid api key|401|credential/i.test(t)) return CLI[which].login;
  if (/rate.?limit|usage limit|quota|429|limit reached/i.test(t)) {
    return `${CLI[which].label} says your subscription’s usage limit has been reached. Try again later. (${t.slice(0, 160)})`;
  }
  return `${CLI[which].label} stopped with an error: ${t.slice(0, 300) || 'no details'}`;
}

/* Runs a command-line tool, feeding `input` on stdin and passing each stdout line to onLine. Resolves with the exit
   code and stderr; rejects on a missing executable. hooks.signal stops it; hooks.cwd is the folder it runs in (the
   temporary folder if none) and hooks.env adds environment variables. Scriptorium's Google Drive backup runs Claude
   Code through this too (runCliTakesEnv says that cwd and env are honoured). */
function runCli(which, exe, args, input, onLine, hooks) {
  const cp = nodeModule('child_process'), os = nodeModule('os'), path = nodeModule('path');
  const win = process.platform === 'win32';
  const env = Object.assign({}, process.env, hooks.env);
  env.PATH = [path.dirname(exe), env.PATH || ''].filter(Boolean).join(path.delimiter);
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = cp.spawn(exe, args, { cwd: hooks.cwd || os.tmpdir(), env, windowsHide: true, shell: win && /\.cmd$/i.test(exe), stdio: ['pipe', 'pipe', 'pipe'] });
    } catch (e) {
      reject(new LagrangeError(`${CLI[which].label} couldn’t be started (${e.message}). ${CLI[which].install}`, { kind: 'setup', cause: e }));
      return;
    }
    let buf = '', err = '', settled = false;
    const done = f => { if (!settled) { settled = true; f(); } };
    const onAbort = () => { try { child.kill(); } catch (e) { /* gone */ } done(() => reject(abortError())); };
    if (hooks.signal) {
      if (hooks.signal.aborted) { onAbort(); return; }
      hooks.signal.addEventListener('abort', onAbort, { once: true });
    }
    child.on('error', e => done(() => reject(new LagrangeError(e.code === 'ENOENT'
      ? `${CLI[which].label} wasn’t found at ${exe}. ${CLI[which].install}`
      : `${CLI[which].label} couldn’t be started (${e.message}).`, { kind: 'setup', cause: e }))));
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      buf += chunk;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i);
        buf = buf.slice(i + 1);
        try { onLine(line); } catch (e) { try { child.kill(); } catch (k) { /* gone */ } done(() => reject(e)); return; }
      }
    });
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', c => { err = (err + c).slice(-4000); });
    child.on('close', code => {
      if (hooks.signal) hooks.signal.removeEventListener('abort', onAbort);
      if (buf.trim()) { try { onLine(buf); } catch (e) { done(() => reject(e)); return; } }
      done(() => resolve({ code, stderr: err }));
    });
    child.stdin.on('error', () => { /* the tool may exit before reading everything */ });
    child.stdin.end(input, 'utf8');
  });
}

function abortError() {
  const e = new Error('Stopped.');
  e.name = 'AbortError';
  return e;
}

async function streamClaudeCode(s, req, hooks, session) {
  const exe = findCli('claude', s.claudeCodePath);
  if (!exe) throw new LagrangeError(`Claude Code wasn’t found${s.claudeCodePath ? ` at ${s.claudeCodePath}` : ''}. ${CLI.claude.install}`, { kind: 'setup' });
  const fs = nodeModule('fs'), os = nodeModule('os'), path = nodeModule('path');
  const sysFile = path.join(os.tmpdir(), `lagrange-system-${process.pid}-${Date.now()}.txt`);
  fs.writeFileSync(sysFile, req.system || '', 'utf8');
  const quote = a => (process.platform === 'win32' && /\.cmd$/i.test(exe) ? `"${String(a).replace(/"/g, '""')}"` : a);
  const args = ['-p', '--output-format', 'stream-json', '--verbose', '--include-partial-messages',
    '--tools', quote(''), '--no-session-persistence', '--setting-sources', quote(''), '--strict-mcp-config',
    '--system-prompt-file', quote(sysFile)];
  const model = String(s.claudeCodeModel || '').trim();
  if (model) args.push('--model', quote(model));
  let effort = sessionEffort(s, session, 'claude-code');
  let st;
  try {
    for (;;) {
      st = { text: '', streamed: false, stopReason: null, model: null, error: null, done: false };
      const { code, stderr } = await runCli('claude', exe, effort ? args.concat('--effort', quote(effort)) : args,
        transcriptPrompt(req.messages), line => {
          const delta = applyClaudeCodeLine(st, line);
          if (delta && hooks.onText) hooks.onText(delta, st.text);
        }, hooks);
      // A Claude Code from before `--effort` stops at once, naming the option: run it again without.
      if (effort && !st.text && /effort/i.test(`${st.error || ''} ${stderr}`) && /unknown|unrecogni[sz]ed|invalid|unexpected|not supported/i.test(`${st.error || ''} ${stderr}`)) {
        forgetEffort(session, 'claude-code');
        effort = '';
        continue;
      }
      if (st.error) throw new LagrangeError(cliErrorMessage('claude', st.error), { kind: 'stream' });
      if (!st.text) throw new LagrangeError(cliErrorMessage('claude', stderr || `exit code ${code}`), { kind: 'stream' });
      break;
    }
  } finally {
    try { fs.unlinkSync(sysFile); } catch (e) { /* already gone */ }
  }
  return { text: st.text, stopReason: st.stopReason || 'end_turn', stopDetails: null, model: st.model || model || 'Claude Code', fallbackTo: null };
}

async function streamCodex(s, req, hooks, session) {
  const exe = findCli('codex', s.codexPath);
  if (!exe) throw new LagrangeError(`Codex wasn’t found${s.codexPath ? ` at ${s.codexPath}` : ''}. ${CLI.codex.install}`, { kind: 'setup' });
  const os = nodeModule('os');
  const args = ['exec', '--json', '--skip-git-repo-check', '--ephemeral', '-s', 'read-only', '-C', os.tmpdir()];
  const model = String(s.codexModel || '').trim();
  if (model) args.push('-m', model);
  const input = '<instructions>\n' + (req.system || '') + '\n\nAnswer in text only: do not run commands, and do not ' +
    'read or write files. Everything you need is in this message.\n</instructions>\n\n' + transcriptPrompt(req.messages);
  let effort = sessionEffort(s, session, `codex:${model}`);
  let st;
  for (;;) {
    st = { text: '', error: null, done: false };
    // `-c key=value` overrides Codex's config for this run; a bare word is taken as a string.
    const { code, stderr } = await runCli('codex', exe, args.concat(effort ? ['-c', `model_reasoning_effort=${effort}`] : [], '-'), input, line => {
      const delta = applyCodexLine(st, line);
      if (delta && hooks.onText) hooks.onText(delta, st.text);
    }, hooks);
    // A model or a Codex that won't take this effort says so: run it again without.
    if (effort && !st.text && /reasoning|effort/i.test(`${st.error || ''} ${stderr}`)) {
      forgetEffort(session, `codex:${model}`);
      effort = '';
      continue;
    }
    if (st.error) throw new LagrangeError(cliErrorMessage('codex', st.error), { kind: 'stream' });
    if (!st.text) throw new LagrangeError(cliErrorMessage('codex', stderr || `exit code ${code}`), { kind: 'stream' });
    break;
  }
  return { text: st.text, stopReason: 'end_turn', stopDetails: null, model: model || 'Codex', fallbackTo: null };
}

/* Settings → "Check": runs `<tool> --version`. Resolves with a sentence for the settings page. */
async function checkCli(which, custom) {
  let exe;
  try { exe = findCli(which === 'claude' ? 'claude' : 'codex', custom); } catch (e) { return e.message; }
  if (!exe) return `Not found. ${CLI[which].install}`;
  try {
    let out = '';
    await runCli(which, exe, ['--version'], '', line => { out += line + ' '; }, {});
    return `Found ${exe}${out.trim() ? ` (${out.trim()})` : ''}. If requests fail, sign in: ${which === 'claude' ? 'run “claude” in a terminal' : 'run “codex login”'}.`;
  } catch (e) { return e.message; }
}

async function streamDemo(req, hooks) {
  const text = typeof req.demo === 'function' ? String(req.demo()) : 'Demo mode has no reply for this.';
  await sleep(req.purpose === 'chat' ? 900 : 1200, hooks.signal);
  const pieces = text.match(/\s*\S+|\s+$/g) || [];
  const pause = req.purpose === 'chat' ? 22 : 0;
  let out = '';
  for (const p of pieces) {
    out += p;
    if (hooks.onText) hooks.onText(p, out);
    if (pause) await sleep(pause, hooks.signal);
  }
  return { text: out, stopReason: 'end_turn', stopDetails: null, model: 'demo', fallbackTo: null };
}

function complete(settings, req, hooks, session) {
  hooks = hooks || {};
  if (settings.provider === 'demo') return streamDemo(req, hooks);
  if (settings.provider === 'openai') return streamOpenAI(settings, req, hooks, session);
  if (settings.provider === 'openai-api') {
    if (!String(settings.openaiPlatformKey || '').trim()) {
      return Promise.reject(new LagrangeError('Add your OpenAI API key in Settings → Lagrange, or choose “ChatGPT: my subscription” to use a ChatGPT plan.', { kind: 'setup' }));
    }
    if (!String(settings.openaiPlatformModel || '').trim()) {
      return Promise.reject(new LagrangeError('Enter an OpenAI model ID in Settings → Lagrange.', { kind: 'setup' }));
    }
    return streamOpenAI(Object.assign({}, settings, { openaiBaseUrl: 'https://api.openai.com/v1', openaiApiKey: settings.openaiPlatformKey, openaiModel: settings.openaiPlatformModel }), req, hooks, session);
  }
  if (settings.provider === 'claude-code') return streamClaudeCode(settings, req, hooks, session);
  if (settings.provider === 'codex') return streamCodex(settings, req, hooks, session);
  return streamAnthropic(settings, req, hooks, session);
}

/* ---- Drawing a drop cap (see "Drawing a drop cap" among the pure helpers) ----
   Each returns {bytes: Uint8Array, kind: 'png' | 'svg', model}. req: {letter, style, mono, change, base: {bytes,
   kind} | null}. */

const OPENAI_IMAGES_URL = 'https://api.openai.com/v1/images';

/* OpenAI's Images API: POST /v1/images/generations, or /v1/images/edits with the present image as a data URL. GPT
   Image models answer with the image in base64. */
async function drawOpenAIImage(s, req, hooks) {
  const key = String(s.openaiPlatformKey || '').trim();
  if (!key) throw new LagrangeError('Add your OpenAI API key in Settings → Lagrange, or choose “ChatGPT: my subscription” to draw with a ChatGPT plan.', { kind: 'setup' });
  const model = String(s.openaiImageModel || '').trim() || DEFAULT_SETTINGS.openaiImageModel;
  const body = { model, prompt: dropcapImagePrompt(req), n: 1, size: '1024x1024', output_format: 'png', background: req.mono ? 'opaque' : 'transparent' };
  const change = Boolean(req.change && req.base && req.base.kind === 'png');
  if (req.change && !change) throw new LagrangeError('The present drop cap is a line drawing (SVG), which an image model cannot be handed. Draw a new one instead.', { kind: 'setup' });
  if (change) body.images = [{ image_url: `data:image/png;base64,${base64FromBytes(req.base.bytes)}` }];
  const url = `${OPENAI_IMAGES_URL}/${change ? 'edits' : 'generations'}`;
  const res = await fetchWithRetry('openai-api', url, {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` }, body: JSON.stringify(body), signal: hooks.signal,
  }, hooks);
  const text = await safeText(res);
  if (!res.ok) throw httpError('openai-api', res, text, model);
  let b64 = '';
  try { const data = JSON.parse(text).data; b64 = (data && data[0] && data[0].b64_json) || ''; } catch (e) { /* not JSON */ }
  if (!b64) throw new LagrangeError('OpenAI answered without an image. Try again, or try another image model in Settings → Lagrange.', { kind: 'stream' });
  let bytes;
  try { bytes = bytesFromBase64(b64); } catch (e) { bytes = null; }
  if (!isPng(bytes)) throw new LagrangeError('OpenAI answered with something that is not a PNG image.', { kind: 'stream' });
  return { bytes, kind: 'png', model };
}

/* Codex's image tool, on a ChatGPT subscription: Codex runs once in an empty temporary folder that it may write to
   (and nowhere else), paints the image, and leaves it there as dropcap.png. */
async function drawCodexImage(s, req, hooks) {
  const exe = findCli('codex', s.codexPath);
  if (!exe) throw new LagrangeError(`Codex wasn’t found${s.codexPath ? ` at ${s.codexPath}` : ''}. ${CLI.codex.install}`, { kind: 'setup' });
  const fs = nodeModule('fs'), os = nodeModule('os'), path = nodeModule('path');
  const change = Boolean(req.change && req.base && req.base.kind === 'png');
  if (req.change && !change) throw new LagrangeError('The present drop cap is a line drawing (SVG), which an image model cannot be handed. Draw a new one instead.', { kind: 'setup' });
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lagrange-dropcap-'));
  try {
    const args = ['exec', '--json', '--skip-git-repo-check', '--ephemeral', '-s', 'workspace-write', '-C', dir];
    const model = String(s.codexModel || '').trim();
    if (model) args.push('-m', model);
    if (change) { fs.writeFileSync(path.join(dir, 'present.png'), Buffer.from(req.base.bytes)); args.push('-i', path.join(dir, 'present.png')); }
    const input = 'Use your built-in image generation tool (do not write code, a script or an SVG) to make one image' +
      (change ? ', a changed version of the attached image' : '') + ':\n\n' + dropcapImagePrompt(req) +
      '\n\nSave it in the current directory as dropcap.png and do nothing else. If you have no image generation tool, reply exactly NO-IMAGE-TOOL.';
    const st = { text: '', error: null, done: false };
    const { code, stderr } = await runCli('codex', exe, args.concat('-c', 'model_reasoning_effort=low', '-'), input, line => { applyCodexLine(st, line); }, hooks);
    const out = path.join(dir, 'dropcap.png');
    if (!fs.existsSync(out)) {
      if (/NO-IMAGE-TOOL/.test(st.text)) throw new LagrangeError('This Codex has no image tool. Update Codex (npm install -g @openai/codex), or choose “OpenAI API” in Settings → Lagrange.', { kind: 'setup' });
      throw new LagrangeError(st.error || (!st.text && (stderr || code)) ? cliErrorMessage('codex', st.error || stderr || `exit code ${code}`)
        : `Codex finished without leaving an image. It said: ${excerpt(st.text, 300)}`, { kind: 'stream' });
    }
    const bytes = new Uint8Array(fs.readFileSync(out));
    if (!isPng(bytes)) throw new LagrangeError('Codex left a file that is not a PNG image.', { kind: 'stream' });
    return { bytes, kind: 'png', model: model || 'Codex' };
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* left in the temporary folder */ }
  }
}

/* The language model writes the initial as an SVG drawing. */
async function drawSvg(settings, req, hooks, session) {
  let base = '';
  if (req.change) {
    if (!req.base || req.base.kind !== 'svg') throw new LagrangeError('The present drop cap is a picture, and this provider can only change a line drawing (SVG). Draw a new one, or choose “ChatGPT: my subscription” in Settings → Lagrange.', { kind: 'setup' });
    base = new TextDecoder().decode(req.base.bytes);
  }
  const res = await complete(settings, {
    purpose: 'dropcap',
    system: DROPCAP_SVG_SYSTEM,
    messages: [{ role: 'user', content: dropcapSvgMessage(Object.assign({}, req, { base })) }],
    demo: () => demoDropcapSvg(req.letter),
  }, hooks, session);
  if (res.stopReason === 'refusal') throw new LagrangeError('The model declined to draw this.');
  const svg = extractSvg(res.text);
  if (!svg) {
    throw new LagrangeError(`The reply had no SVG drawing in it${res.stopReason === 'max_tokens' ? ' (it reached its length limit)' : ''}. Try again, or choose another model.`, { reply: res.text });
  }
  return { bytes: new TextEncoder().encode(svg), kind: 'svg', model: res.model };
}

function drawDropcap(settings, req, hooks, session) {
  hooks = hooks || {};
  if (!dropcapLetter(req.letter)) return Promise.reject(new LagrangeError('A drop cap is one letter, A to Z.', { kind: 'setup' }));
  const route = dropcapRoute(settings);
  if (route === 'image-api') return drawOpenAIImage(settings, req, hooks);
  if (route === 'codex-image') return drawCodexImage(settings, req, hooks);
  return drawSvg(settings, req, hooks, session);
}


/* ---- Prompts ---- */

function noteBlock(note, clip) {
  if (!note) return 'No note is open.';
  const where = clip.clipped
    ? ` The note is long (${clip.total} characters), so only the part around the writer’s cursor is included.`
    : '';
  return `The note is titled “${note.title}”.${where}\n\n<note>\n${clip.text}\n</note>`;
}

// Obsidian typesets $…$ and $$…$$ only; \\( \\) and \\[ \\] stay as they are typed.
const MATH_STYLE =
  'Write mathematics the way Obsidian reads it: $…$ inside a sentence, and $$…$$ on lines of its own for a displayed ' +
  'equation (an align or other environment goes inside $$…$$); never \\( \\) or \\[ \\].';

const CHAT_INTRO =
  'You are Lagrange, a writing companion inside Obsidian. The writer uses Scriptorium, a configuration that ' +
  'sets notes like the pages of a printed book. You talk with the writer about the note they have open: answer ' +
  'questions about it, suggest improvements, and explain your thinking briefly. Write plain, warm, precise prose, ' +
  'and use Markdown lightly (a short list or some emphasis when it helps). Quote the note exactly when you quote ' +
  'it. ' + MATH_STYLE + ' ';

const CHAT_TALK_ONLY =
  'You cannot change the note yourself; if the writer wants changes made, they can select a passage and run ' +
  '“Lagrange: Revise selection”, or run “Lagrange: Proofread note”.';

// The contract for edits in a chat reply (see splitAgentReply). The model chooses: prose alone answers; a block edits.
const CHAT_AGENTIC =
  'You can also change the note yourself: you have a pen. When the writer asks you to change the note (to fix, ' +
  'rewrite, shorten, expand, add, delete or move something in it), make the change rather than describing it. Say ' +
  'in a sentence or two what you are changing, without repeating the new text, and then end your reply with one ' +
  'block in exactly this form:\n\n' +
  '```lagrange-edits\n' +
  '[{"find": "exact text from the note", "replace": "the new text", "reason": "a few words"},\n' +
  ' {"insert_after": "exact text from the note", "text": "text to add straight after it"},\n' +
  ' {"append": "text to add at the end of the note"}]\n' +
  '```\n\n' +
  'The block holds a JSON array of one or more edits, of these three kinds in any mix ("insert_before" also works). ' +
  'Rules:\n' +
  '- "find" and "insert_after" are copied from the note exactly, character for character (the same quotation marks, ' +
  'dashes, spaces and Markdown marks), and must occur exactly once in the note: include a few neighbouring words when ' +
  'the text is short or repeated.\n' +
  '- "replace" is the new version of exactly the text in "find"; "replace": "" deletes it.\n' +
  '- Keep edits small and separate (a sentence or a paragraph each), and never let two edits overlap.\n' +
  '- Inserted text goes in exactly as written, so begin or end it with the space or the blank line (\\n\\n) it needs; ' +
  'appended text starts a new paragraph by itself.\n' +
  '- The block must be valid JSON: escape quotation marks and backslashes inside strings (so LaTeX is written ' +
  '"\\\\frac{a}{b}"), and write line breaks as \\n.\n' +
  'Your pen writes the edits into the note as soon as your reply ends, and the writer can take them all back with ' +
  'one undo, so do not ask for permission when the request is clear, and do not tell the writer to run a command.\n\n' +
  'When the writer asks a question, wants your opinion or feedback, or it is not clear that they want the note ' +
  'itself changed, answer in prose with no block; you may offer to make the change. Never write a lagrange-edits ' +
  'block for any other purpose, and never more than one in a reply. If no note is open there is nothing to edit.';

function chatSystemPrompt(note, clip, agentic) {
  return CHAT_INTRO + (agentic ? CHAT_AGENTIC : CHAT_TALK_ONLY) + '\n\n' +
    (note ? noteBlock(note, clip) : 'No note is open at the moment; talk with the writer about their writing in general.');
}

const PROOFREAD_SYSTEM =
  'You are Lagrange, a careful proofreader working inside Obsidian. You will receive one note written in Markdown. ' +
  'Find mistakes of spelling, grammar, punctuation and typography, and nothing else: do not rewrite for style, do not ' +
  'change the meaning, and leave Markdown syntax, links, code, YAML front matter and deliberately foreign text (such ' +
  'as Latin placeholder text) as they are.\n\n' +
  'Reply with only a JSON array, with nothing before or after it, in this form:\n' +
  '[{"find": "exact text from the note", "replace": "the corrected text", "reason": "a few words"}]\n\n' +
  'Rules for each edit:\n' +
  '- "find" is copied from the note exactly, character for character (the same quotation marks, dashes, spaces and ' +
  'Markdown marks), and occurs exactly once in the note: include a few neighbouring words when the mistake itself is ' +
  'short or repeated.\n' +
  '- "replace" is the corrected version of exactly that text.\n' +
  '- Keep edits small and separate, and never let two edits overlap.\n' +
  '- "reason" says briefly what was wrong, for example "spelling", "subject–verb agreement" or "missing comma".\n' +
  'If there is nothing to correct, reply with [].';

function proofreadUserMessage(note, clip) {
  return `Proofread this note.\n\n${noteBlock(note, clip)}`;
}

const REVISE_SYSTEM =
  'You are Lagrange, a writing assistant inside Obsidian. You revise one passage of the writer’s note as they ask. ' +
  'Reply with only the revised passage, ready to replace the original: no preamble, no explanation, and no quotation ' +
  'marks or code fences around it. Keep the passage’s Markdown (emphasis, links, headings, line breaks) unless the ' +
  'instruction asks otherwise, and keep the writer’s voice. The rest of the note is there for context only; change ' +
  'nothing outside the passage. ' + MATH_STYLE;

function reviseUserMessage(note, clip, passage, instruction) {
  return `Instruction: ${instruction}\n\nFor context, the whole note. ${noteBlock(note, clip)}\n\n` +
    `The passage to revise:\n<passage>\n${passage}\n</passage>`;
}


/* ---------------------------------------------------------------------------------------------------------------
 * 4. The loader
 * ------------------------------------------------------------------------------------------------------------- */

// ==== LAGRANGE LOADER (replaceable) ====
// The "Lagrange is thinking" plate. The chat shows it from the moment a request is sent until the first words of the
// reply arrive (or the request fails). Three engravings, drawn in the page's ink: clockwork (gears and a belted
// flywheel), alchemy (a flask distilling into a receiver), and the Earth-Moon system with its five Lagrange
// points. Settings → Lagrange → Loading animation picks one, or "random" (the default) draws a new one each time.
//
// Contract
//   mountLoader(containerEl, theme) -> { stop() }
//     theme  'random' | 'clockwork' | 'alchemy' | 'orbit' (anything else counts as 'random')
//     stop() removes the plate and stops its animation. Called once; calling it again does nothing.
/* Lagrange's loading plates: three ink engravings drawn into an <svg viewBox="0 0 320 240">.
   drawPlate(svg, name, opts) -> stop(); name is 'clockwork' | 'alchemy' | 'orbit'.
   Colours come from CSS variables (--lg-ink, --lg-ink-soft, --lg-rubric, --lg-wash, --lg-plate) so light and dark
   themes both work. opts.still draws one frame and does not animate (prefers-reduced-motion). */
const LagrangePlates = (() => {
  const NS = 'http://www.w3.org/2000/svg';
  let uid = 0;
  const INK = 'var(--lg-ink)', SOFT = 'var(--lg-ink-soft)', RUB = 'var(--lg-rubric)', WASH = 'var(--lg-wash)', PLATE = 'var(--lg-plate)';
  const mk = (tag, attrs, parent) => {
    const e = (parent ? parent.ownerDocument : document).createElementNS(NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  };

  function defs(svg, id, seed) {
    const d = mk('defs', {}, svg);
    const f = mk('filter', { id: `ink${id}`, x: '-5%', y: '-5%', width: '110%', height: '110%' }, d);
    mk('feTurbulence', { type: 'fractalNoise', baseFrequency: '0.035', numOctaves: '2', seed: String(seed), result: 'n' }, f);
    mk('feDisplacementMap', { in: 'SourceGraphic', in2: 'n', scale: '2.4', xChannelSelector: 'R', yChannelSelector: 'G' }, f);
    const p = mk('pattern', { id: `hatch${id}`, width: '4', height: '4', patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(40)' }, d);
    mk('line', { x1: 0, y1: 0, x2: 0, y2: 4, stroke: INK, 'stroke-width': '0.7', opacity: '0.55' }, p);
    const p2 = mk('pattern', { id: `hatchx${id}`, width: '5', height: '5', patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(-35)' }, d);
    mk('line', { x1: 0, y1: 0, x2: 0, y2: 5, stroke: INK, 'stroke-width': '0.6', opacity: '0.35' }, p2);
    return d;
  }
  const inkAttrs = (id, w = 1.5) => ({ filter: `url(#ink${id})`, stroke: INK, fill: 'none', 'stroke-width': String(w), 'stroke-linecap': 'round', 'stroke-linejoin': 'round' });

  function animate(win, step, still) {
    if (still) { step(1500); return () => {}; }
    let on = true, t0 = null;
    const loop = t => { if (!on) return; if (t0 === null) t0 = t; step(t - t0 + 16); win.requestAnimationFrame(loop); };
    win.requestAnimationFrame(loop);
    return () => { on = false; };
  }

  /* ------------------------------------------------------------------ I. Clockwork */
  function gearPath(n, r, add = 5, ded = 6) {
    const pts = [], p = (2 * Math.PI) / n;
    for (let i = 0; i < n; i++) {
      const a = i * p;
      for (const [t, rr] of [[a - p * 0.5, r - ded], [a - p * 0.3, r - ded], [a - p * 0.17, r + add], [a + p * 0.17, r + add], [a + p * 0.3, r - ded]])
        pts.push([Math.cos(t) * rr, Math.sin(t) * rr]);
    }
    return 'M' + pts.map(q => q.map(v => v.toFixed(2)).join(' ')).join('L') + 'Z';
  }
  function gear(svg, id, n, m, cx, cy, spokes) {
    const r = (n * m) / 2;
    const g = mk('g', { transform: `translate(${cx} ${cy})` }, svg);
    const rot = mk('g', {}, g);
    const ink = mk('g', { filter: `url(#ink${id})`, stroke: INK, 'stroke-width': '1.5', 'stroke-linejoin': 'round', fill: 'none' }, rot);
    mk('path', { d: gearPath(n, r), fill: PLATE }, ink);
    mk('circle', { r: r - 11, fill: `url(#hatch${id})`, 'stroke-width': '1' }, ink);
    mk('circle', { r: r - 13 }, ink);
    for (let i = 0; i < spokes; i++) {
      const t = (i * 2 * Math.PI) / spokes, w = 0.12;
      const a1 = [Math.cos(t - w) * 8, Math.sin(t - w) * 8], a2 = [Math.cos(t + w) * 8, Math.sin(t + w) * 8];
      const b1 = [Math.cos(t - w / 2.5) * (r - 13), Math.sin(t - w / 2.5) * (r - 13)], b2 = [Math.cos(t + w / 2.5) * (r - 13), Math.sin(t + w / 2.5) * (r - 13)];
      mk('path', { d: `M${a1}L${b1}L${b2}L${a2}Z`, fill: PLATE }, ink);
    }
    mk('circle', { r: 9, fill: PLATE }, ink);
    mk('circle', { r: 3.2, fill: INK }, ink);
    return { rot, n, cx, cy };
  }
  function clockwork(svg, id, win, still) {
    defs(svg, id, 4);
    const frame = mk('g', inkAttrs(id, 1), svg);
    mk('rect', { x: 8, y: 8, width: 304, height: 224, rx: 3, opacity: .6 }, frame);
    for (const [x, y] of [[18, 18], [302, 18], [18, 222], [302, 222]]) {
      mk('circle', { cx: x, cy: y, r: 4 }, frame); mk('line', { x1: x - 3, y1: y - 1.5, x2: x + 3, y2: y + 1.5 }, frame);
    }
    const m = 5.2;
    const A = gear(svg, id, 22, m, 128, 132, 5);
    const phi1 = -0.62, phi2 = 2.62, dB = (22 + 13) * m / 2, dC = (22 + 11) * m / 2;
    const B = gear(svg, id, 13, m, A.cx + Math.cos(phi1) * dB, A.cy + Math.sin(phi1) * dB, 4);
    const C = gear(svg, id, 11, m, A.cx + Math.cos(phi2) * dC, A.cy + Math.sin(phi2) * dC, 3);
    // a flywheel, belted to a pulley on the great wheel's arbor
    const F = [254, 178], rP = 11, rF = 21;
    const dx = F[0] - A.cx, dy = F[1] - A.cy, dist = Math.hypot(dx, dy), th = Math.atan2(dy, dx), be = Math.acos((rP - rF) / dist);
    const tan = s2 => { const p = th + s2 * be; return [[A.cx + Math.cos(p) * rP, A.cy + Math.sin(p) * rP], [F[0] + Math.cos(p) * rF, F[1] + Math.sin(p) * rF]]; };
    const fw = mk('g', { transform: `translate(${F[0]} ${F[1]})` }, svg);
    const fwr = mk('g', {}, fw);
    const fink = mk('g', inkAttrs(id, 1.4), fwr);
    mk('circle', { r: 29, fill: PLATE }, fink); mk('circle', { r: 25 }, fink);
    for (let i = 0; i < 6; i++) { const t = i * Math.PI / 3; mk('line', { x1: Math.cos(t) * 7, y1: Math.sin(t) * 7, x2: Math.cos(t) * 25, y2: Math.sin(t) * 25 }, fink); }
    mk('circle', { r: rF, 'stroke-width': '2.4', opacity: .9 }, fink);
    mk('circle', { r: 7, fill: `url(#hatch${id})` }, fink);
    mk('circle', { r: 2.5, fill: INK }, fink);
    const pul = mk('g', inkAttrs(id, 1.3), A.rot);
    mk('circle', { r: rP + 2, fill: PLATE }, pul); mk('circle', { r: rP, 'stroke-width': '2.4' }, pul);
    mk('circle', { r: 5, fill: `url(#hatch${id})` }, pul); mk('line', { x1: 0, y1: -rP + 3, x2: 0, y2: -5 }, pul);
    mk('circle', { r: 2.6, fill: INK, stroke: 'none' }, pul);
    const belt = [1, -1].map(s2 => { const [p, q] = tan(s2); return mk('path', { d: `M${p[0].toFixed(2)} ${p[1].toFixed(2)}L${q[0].toFixed(2)} ${q[1].toFixed(2)}`, stroke: INK, 'stroke-width': '1.8', 'stroke-dasharray': '7 3', fill: 'none', filter: `url(#ink${id})` }, svg); });
    // bracket holding the flywheel's axle to the frame
    mk('path', { d: `M${F[0]} ${F[1]} L${F[0] + 34} 226 M${F[0]} ${F[1]} L${F[0] - 24} 226`, ...inkAttrs(id, 1.2) }, svg);
    svg.appendChild(fw);
    const pA = 2 * Math.PI / A.n, pB = 2 * Math.PI / B.n, pC = 2 * Math.PI / C.n;
    const mod = (a, b) => ((a % b) + b) % b;
    const cB = phi1 + Math.PI - pB / 2 + (A.n / B.n) * mod(phi1, pA);
    const cC = phi2 + Math.PI - pC / 2 + (A.n / C.n) * mod(phi2, pA);
    const deg = r => (r * 180 / Math.PI).toFixed(3);
    return animate(win, t => {
      const a = t * 0.00035;
      A.rot.setAttribute('transform', `rotate(${deg(a)})`);
      B.rot.setAttribute('transform', `rotate(${deg(-(A.n / B.n) * a + cB)})`);
      C.rot.setAttribute('transform', `rotate(${deg(-(A.n / C.n) * a + cC)})`);
      fwr.setAttribute('transform', `rotate(${deg(a * rP / rF)})`);
      belt[0].setAttribute('stroke-dashoffset', (-a * rP).toFixed(2));
      belt[1].setAttribute('stroke-dashoffset', (a * rP).toFixed(2));
    }, still);
  }

  /* ------------------------------------------------------------------ II. Alchemy */
  function alchemy(svg, id, win, still) {
    const d = defs(svg, id, 9);
    const cx = 112, cy = 160, R = 50, nh = 11, neckY = cy - Math.sqrt(R * R - nh * nh);
    const cp = mk('clipPath', { id: `bulb${id}` }, d);
    mk('circle', { cx, cy, r: R - 1.5 }, cp);
    const stand = mk('g', inkAttrs(id), svg);
    mk('path', { d: `M${cx - 46} ${cy + 38} L${cx - 58} 228 M${cx + 46} ${cy + 38} L${cx + 58} 228 M${cx - 52} ${cy + 38} H${cx + 52}` }, stand);
    mk('path', { d: `M${cx - 16} 228 L${cx - 12} 214 H${cx + 12} L${cx + 16} 228 Z`, fill: `url(#hatch${id})` }, stand);
    mk('line', { x1: 20, y1: 229, x2: 300, y2: 229, opacity: .7 }, stand);
    const flame = mk('g', { transform: `translate(${cx} 214)` }, svg);
    const fl = mk('path', { d: 'M0 0 C-7 -6 -6 -14 0 -24 C6 -14 7 -6 0 0 Z', fill: WASH, stroke: RUB, 'stroke-width': '1.2', filter: `url(#ink${id})` }, flame);
    const fl2 = mk('path', { d: 'M0 -2 C-3 -6 -3 -10 0 -15 C3 -10 3 -6 0 -2 Z', fill: RUB, opacity: .55 }, flame);
    const liq = mk('g', { 'clip-path': `url(#bulb${id})` }, svg);
    const surf = mk('path', { fill: WASH }, liq);
    const surfH = mk('path', { fill: `url(#hatchx${id})` }, liq);
    const bubbles = mk('g', {}, liq);
    const glass = mk('g', inkAttrs(id), svg);
    mk('path', { d: `M${cx - nh} 52 L${cx - nh} ${neckY} A${R} ${R} 0 1 0 ${cx + nh} ${neckY} L${cx + nh} 52` }, glass);
    mk('path', { d: `M${cx - nh - 3} 50 H${cx + nh + 3}` }, glass);
    mk('path', { d: `M${cx - 30} ${cy - 26} q 8 -10 20 -13`, 'stroke-width': '1', opacity: .5 }, glass);
    mk('rect', { x: cx - nh + 1, y: 40, width: 2 * nh - 2, height: 12, fill: `url(#hatch${id})` }, glass);
    const tube = `M${cx + 2} 40 C ${cx + 4} 14, ${cx + 70} 10, 238 96`;
    mk('path', { d: tube, 'stroke-width': '5' }, glass);
    mk('path', { d: tube, 'stroke-width': '2.4', stroke: PLATE, fill: 'none', 'stroke-linecap': 'round' }, svg);
    const rx = 250, ry = 222;
    const flask = `M${rx - 8} 112 V140 L${rx - 34} ${ry - 4} Q${rx - 36} ${ry + 3} ${rx - 28} ${ry + 3} H${rx + 28} Q${rx + 36} ${ry + 3} ${rx + 34} ${ry - 4} L${rx + 8} 140 V112`;
    const recv = mk('g', inkAttrs(id), svg);
    mk('path', { d: flask }, recv);
    mk('path', { d: `M${rx - 11} 111 H${rx + 11}` }, recv);
    const rclip = mk('clipPath', { id: `recv${id}` }, d);
    mk('path', { d: flask + ' Z' }, rclip);
    const rliq = mk('g', { 'clip-path': `url(#recv${id})` }, svg);
    const rsurf = mk('rect', { x: rx - 40, width: 80, y: 200, height: 40, fill: WASH }, rliq);
    const rsurfH = mk('rect', { x: rx - 40, width: 80, y: 200, height: 40, fill: `url(#hatchx${id})` }, rliq);
    const drops = mk('g', {}, svg);
    const wisps = mk('g', { stroke: SOFT, fill: 'none', 'stroke-width': '1', 'stroke-linecap': 'round', filter: `url(#ink${id})` }, svg);
    const wisp = [0, 1, 2].map(() => mk('path', { opacity: 0 }, wisps));
    const B = [], D = [];
    let lastSpawn = -1e9, lastDrop = -1e9, level = 200, rnd = 7;
    const rand = () => { rnd = (rnd * 16807) % 2147483647; return rnd / 2147483647; };
    const surfaceY = cy - 6;
    return animate(win, t => {
      let dd = `M${cx - R} ${cy + R + 4} L${cx - R} ${surfaceY}`;
      for (let x = cx - R; x <= cx + R; x += 4) dd += ` L${x} ${(surfaceY + Math.sin(x * 0.18 + t * 0.004) * 1.6 + Math.sin(x * 0.07 - t * 0.0027) * 1.2).toFixed(2)}`;
      dd += ` L${cx + R} ${cy + R + 4} Z`;
      surf.setAttribute('d', dd); surfH.setAttribute('d', dd);
      fl.setAttribute('transform', `scale(${(1 + Math.sin(t * 0.021) * 0.06).toFixed(3)} ${(1 + Math.sin(t * 0.017 + 1) * 0.12).toFixed(3)})`);
      fl2.setAttribute('transform', `scale(1 ${(1 + Math.sin(t * 0.025) * 0.15).toFixed(3)})`);
      if (t - lastSpawn > 140) {
        lastSpawn = t;
        B.push({ c: mk('circle', { fill: 'none', stroke: INK, 'stroke-width': '1' }, bubbles), x: cx + (rand() - 0.5) * 60, r: 1 + rand() * 1.5, v: 0.025 + rand() * 0.03, ph: rand() * 6, born: t });
      }
      for (let i = B.length - 1; i >= 0; i--) {
        const b = B[i], age = t - b.born, y = cy + R - 4 - age * b.v;
        if (y < surfaceY - 3) { b.c.remove(); B.splice(i, 1); continue; }
        b.c.setAttribute('opacity', y < surfaceY + 1 ? Math.max(0, 1 - (surfaceY + 1 - y) / 4).toFixed(2) : '1');
        b.c.setAttribute('cx', (b.x + Math.sin(age * 0.006 + b.ph) * 2.5).toFixed(2));
        b.c.setAttribute('cy', y.toFixed(2));
        b.c.setAttribute('r', (b.r + age * 0.003).toFixed(2));
      }
      if (t - lastDrop > 1400) {
        lastDrop = t;
        D.push({ p: mk('path', { d: 'M0 -4 C 2 -1, 2 2, 0 2.5 C -2 2, -2 -1, 0 -4 Z', fill: RUB, opacity: .8 }, drops), born: t, ring: null });
      }
      for (let i = D.length - 1; i >= 0; i--) {
        const q = D[i], a = t - q.born;
        if (!q.ring) {
          const y = 100 + a * a * 0.00012 + a * 0.02;
          if (y >= level) {
            q.p.remove(); q.ring = mk('ellipse', { cx: rx, cy: level, rx: 1, ry: .4, fill: 'none', stroke: INK, 'stroke-width': '.8' }, drops); q.landed = t;
            level = level > 176 ? level - 0.6 : 200;
            rsurf.setAttribute('y', level.toFixed(2)); rsurfH.setAttribute('y', level.toFixed(2));
          } else q.p.setAttribute('transform', `translate(${rx} ${y.toFixed(2)})`);
        } else {
          const k = (t - q.landed) / 500;
          if (k > 1) { q.ring.remove(); D.splice(i, 1); continue; }
          q.ring.setAttribute('rx', (1 + k * 12).toFixed(2)); q.ring.setAttribute('ry', (0.4 + k * 2).toFixed(2)); q.ring.setAttribute('opacity', (1 - k).toFixed(2));
        }
      }
      wisp.forEach((w, i) => {
        const ph = ((t * 0.00025 + i / 3) % 1), y0 = 36 - ph * 26, x0 = cx - 18 + i * 6;
        w.setAttribute('d', `M${x0} ${y0 + 10} c -6 -4, 6 -8, 0 -12 s 6 -8, 0 -12`);
        w.setAttribute('opacity', (Math.sin(ph * Math.PI) * 0.55).toFixed(2));
      });
    }, still);
  }

  /* ------------------------------------------------------------------ III. The five points */
  function orbit(svg, id, win, still) {
    defs(svg, id, 21);
    const mu = 0.01215, Dpx = 92, C = [160, 121];
    // Effective potential in the rotating frame (barycentre at the origin, Earth at -mu, Moon at 1-mu, distance 1).
    const omega = (x, y) => 0.5 * (x * x + y * y) + (1 - mu) / Math.hypot(x + mu, y) + mu / Math.hypot(x - 1 + mu, y);
    const L = { 1: [0.83692, 0], 2: [1.15568, 0], 3: [-1.00506, 0], 4: [0.5 - mu, Math.sqrt(3) / 2], 5: [0.5 - mu, -Math.sqrt(3) / 2] };
    const levels = [omega(...L[1]), omega(...L[2]), omega(...L[3]), omega(...L[4]) - 0.004];
    // marching squares over the frame
    const x0 = -1.62, x1 = 1.62, y0 = -1.28, y1 = 1.28, h = 0.022;
    const nx = Math.round((x1 - x0) / h), ny = Math.round((y1 - y0) / h);
    const grid = [];
    for (let j = 0; j <= ny; j++) { const row = []; for (let i = 0; i <= nx; i++) row.push(Math.min(9, omega(x0 + i * h, y0 + j * h))); grid.push(row); }
    const px = (x, y) => [(x + mu) * Dpx, y * Dpx];           // frame units -> px, Earth at the origin of the group
    const contours = levels.map(lv => {
      let d = '';
      for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
        const v = [grid[j][i], grid[j][i + 1], grid[j + 1][i + 1], grid[j + 1][i]];
        const c = [[0, 0], [1, 0], [1, 1], [0, 1]];
        const pts = [];
        for (let e = 0; e < 4; e++) {
          const a = v[e], b = v[(e + 1) % 4];
          if ((a - lv) * (b - lv) < 0) {
            const k = (lv - a) / (b - a), ca = c[e], cb = c[(e + 1) % 4];
            pts.push(px(x0 + (i + ca[0] + (cb[0] - ca[0]) * k) * h, y0 + (j + ca[1] + (cb[1] - ca[1]) * k) * h));
          }
        }
        if (pts.length >= 2) d += `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}L${pts[1][0].toFixed(1)} ${pts[1][1].toFixed(1)}`;
        if (pts.length === 4) d += `M${pts[2][0].toFixed(1)} ${pts[2][1].toFixed(1)}L${pts[3][0].toFixed(1)} ${pts[3][1].toFixed(1)}`;
      }
      return d;
    });
    const back = mk('g', inkAttrs(id, 1), svg);
    mk('rect', { x: 8, y: 8, width: 304, height: 224, rx: 3, opacity: .55 }, back);
    mk('circle', { cx: C[0], cy: C[1], r: Dpx, 'stroke-dasharray': '2 4', opacity: .6, 'stroke-width': '.9' }, back);
    // stars, fixed
    let rnd = 11; const rand = () => { rnd = (rnd * 16807) % 2147483647; return rnd / 2147483647; };
    for (let i = 0; i < 26; i++) {
      const x = 14 + rand() * 292, y = 14 + rand() * 212;
      if (Math.hypot(x - C[0], y - C[1]) < 118) continue;
      mk('path', { d: `M${x - 1.6} ${y}H${x + 1.6}M${x} ${y - 1.6}V${y + 1.6}`, stroke: SOFT, 'stroke-width': '.7' }, svg);
    }
    const frame = mk('g', {}, svg);                  // rotates with the Moon
    const fr = mk('g', {}, frame);
    contours.forEach((d, i) => mk('path', { d, fill: 'none', stroke: i === 3 ? RUB : SOFT, 'stroke-width': i === 3 ? '.8' : '.7', opacity: i === 3 ? '.7' : '.65', 'stroke-linecap': 'round' }, fr));
    // the Moon
    const moon = mk('g', { transform: `translate(${Dpx} 0)` }, fr);
    const mi = mk('g', inkAttrs(id, 1.1), moon);
    mk('circle', { r: 7, fill: PLATE }, mi);
    mk('path', { d: 'M0 -7 A7 7 0 0 1 0 7 A3.5 7 0 0 0 0 -7 Z', fill: `url(#hatch${id})`, stroke: 'none' }, mi);
    for (const [x, y, r] of [[-2.5, -2, 1.3], [1.5, 2.5, 1], [-1, 3.6, .7]]) mk('circle', { cx: x, cy: y, r }, mi);
    // L points: small crosses in rubric
    const crosses = {};
    for (const k of [1, 2, 3, 4, 5]) {
      const [x, y] = px(...L[k]);
      crosses[k] = mk('path', { d: `M${x - 3} ${y - 3}L${x + 3} ${y + 3}M${x + 3} ${y - 3}L${x - 3} ${y + 3}`, stroke: RUB, 'stroke-width': '1.4', 'stroke-linecap': 'round' }, fr);
    }
    // Earth, fixed at the centre (a little globe that turns on its axis)
    const earth = mk('g', { transform: `translate(${C[0]} ${C[1]})` }, svg);
    const ei = mk('g', inkAttrs(id, 1.2), earth);
    mk('circle', { r: 17, fill: PLATE }, ei);
    const shade = mk('path', { fill: `url(#hatch${id})`, stroke: 'none' }, ei);
    mk('ellipse', { rx: 17, ry: 5.5, 'stroke-width': '.8' }, ei);
    mk('line', { x1: -17, y1: 0, x2: 17, y2: 0, 'stroke-width': '.6' }, ei);
    const mer = [0, 1, 2].map(() => mk('ellipse', { rx: 6, ry: 17, 'stroke-width': '.8' }, ei));
    mk('circle', { r: 17 }, ei);
    // labels stay upright: placed each frame at the rotated positions
    const labels = {};
    const off = { 1: [-2, -9], 2: [8, -6], 3: [-16, -6], 4: [7, -5], 5: [7, 11] };
    for (const k of [1, 2, 3, 4, 5]) {
      const t = mk('text', { fill: INK, 'font-size': '13', 'font-style': 'italic', 'font-family': 'var(--lg-display, Georgia, serif)' }, svg);
      t.textContent = 'L';
      const sub = mk('tspan', { 'font-size': '9', dy: '3' }, t); sub.textContent = String(k);
      labels[k] = t;
    }
    const mlab = mk('text', { fill: SOFT, 'font-size': '10', 'font-style': 'italic', 'font-family': 'var(--lg-display, Georgia, serif)' }, svg);
    mlab.textContent = 'Moon';
    const elab = mk('text', { x: C[0] - 13, y: C[1] + 31, fill: SOFT, 'font-size': '10', 'font-style': 'italic', 'font-family': 'var(--lg-display, Georgia, serif)' }, svg);
    elab.textContent = 'Earth';
    return animate(win, t => {
      const th = -t * 2 * Math.PI / 16000 + 0.5;        // one orbit in 16 s, counter-clockwise
      const c = Math.cos(th), s = Math.sin(th);
      frame.setAttribute('transform', `translate(${C[0]} ${C[1]}) rotate(${(th * 180 / Math.PI).toFixed(3)})`);
      for (const k of [1, 2, 3, 4, 5]) {
        const [x, y] = px(...L[k]);
        const X = C[0] + x * c - y * s, Y = C[1] + x * s + y * c;
        labels[k].setAttribute('x', (X + off[k][0]).toFixed(1)); labels[k].setAttribute('y', (Y + off[k][1]).toFixed(1));
      }
      const mx = C[0] + Dpx * c, my = C[1] + Dpx * s;
      mlab.setAttribute('x', (mx - 11).toFixed(1)); mlab.setAttribute('y', (my + 20).toFixed(1));
      const spin = (t * 0.0006) % (2 * Math.PI);
      mer.forEach((m, i) => { const p = spin + i * Math.PI / 3; m.setAttribute('rx', Math.abs(Math.cos(p) * 17).toFixed(2)); });
      shade.setAttribute('d', 'M0 -17 A17 17 0 0 1 0 17 A8 17 0 0 0 0 -17 Z');
    }, still);
  }

  const PLATES = { clockwork, alchemy, orbit };
  const NAMES = Object.keys(PLATES);
  function drawPlate(svg, name, opts = {}) {
    const id = `lgp${++uid}`;
    const win = (svg.ownerDocument && svg.ownerDocument.defaultView) || window;
    return PLATES[name](svg, id, win, !!opts.still);
  }
  return { drawPlate, NAMES };
})();

const LOADER_CAPTIONS = {
  clockwork: 'Lagrange is reckoning',
  alchemy: 'Lagrange is distilling',
  orbit: 'Lagrange is finding the balance',
};
function mountLoader(containerEl, theme) {
  const doc = containerEl.ownerDocument || document;
  const win = doc.defaultView || window;
  const names = LagrangePlates.NAMES;
  const name = names.includes(theme) ? theme : names[Math.floor(Math.random() * names.length)];
  const el = doc.createElement('div');
  el.className = `lagrange-loader lagrange-loader--${name}`;
  el.setAttribute('role', 'status');
  el.setAttribute('aria-label', `${LOADER_CAPTIONS[name]}…`);
  const svg = doc.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 320 240');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('class', 'lagrange-plate');
  el.appendChild(svg);
  const cap = doc.createElement('div');
  cap.className = 'lagrange-loader-caption';
  cap.textContent = LOADER_CAPTIONS[name];
  const dots = doc.createElement('span');
  dots.className = 'lagrange-loader-dots';
  for (let i = 0; i < 3; i++) { const d = doc.createElement('span'); d.textContent = '.'; dots.appendChild(d); }
  cap.appendChild(dots);
  el.appendChild(cap);
  containerEl.appendChild(el);
  let stopAnim = () => {};
  try { stopAnim = LagrangePlates.drawPlate(svg, name, { still: prefersReducedMotion(win) }); } catch (e) { console.error('Lagrange: loader', e); }
  let stopped = false;
  return {
    stop() {
      if (stopped) return;
      stopped = true;
      try { stopAnim(); } catch (e) { /* ignore */ }
      el.remove();
    },
  };
}
// ==== END LAGRANGE LOADER ====


/* ---------------------------------------------------------------------------------------------------------------
 * 5. The pen
 * ------------------------------------------------------------------------------------------------------------- */

/* ---- Pen helpers: shared, kept when the pen is replaced ---- */

function nextFrame(win) {
  return new Promise(resolve => (win || window).requestAnimationFrame(() => resolve()));
}

function prefersReducedMotion(win) {
  try { return (win || window).matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; }
}

/* Screen rectangles, in viewport coordinates (as getBoundingClientRect gives), covering the document range [from, to]
   of a CodeMirror 6 EditorView: one per visual line, in reading order, each {left, top, right, bottom, width, height}.
   Measured from the DOM CodeMirror has drawn, with view.coordsAtPos as the fallback, so a pen can fly to the text.
   Only the part of the range CodeMirror has drawn is covered; scroll it into view first. An empty range gives one
   zero-width rectangle at the caret position. Read layout only: call it outside view.dispatch. */
function rangeRects(view, from, to) {
  if (to < from) { const t = from; from = to; to = t; }
  const len = view.state.doc.length;
  from = Math.max(0, Math.min(from, len));
  to = Math.max(0, Math.min(to, len));
  const box = (l, t, r, b) => ({ left: l, top: t, right: r, bottom: b, width: r - l, height: b - t });
  if (from === to) {
    const c = view.coordsAtPos(from);
    return c ? [box(c.left, c.top, c.left, c.bottom)] : [];
  }
  const out = [];
  const add = r => {
    if (!r || r.width <= 0.5 || r.height <= 0) return;
    const last = out[out.length - 1];
    if (last && Math.abs(r.top - last.top) < 3 && Math.abs(r.bottom - last.bottom) < 6) {
      out[out.length - 1] = box(Math.min(last.left, r.left), Math.min(last.top, r.top), Math.max(last.right, r.right), Math.max(last.bottom, r.bottom));
    } else {
      out.push(box(r.left, r.top, r.right, r.bottom));
    }
  };
  try {
    const a = view.domAtPos(from), b = view.domAtPos(to);
    const range = view.dom.ownerDocument.createRange();
    range.setStart(a.node, a.offset);
    range.setEnd(b.node, b.offset);
    for (const r of range.getClientRects()) add(r);
  } catch (e) { out.length = 0; }
  if (out.length) return out;
  // Fallback: character by character with coordsAtPos (bounded, for long ranges).
  const step = Math.max(1, Math.ceil((to - from) / 400));
  for (let p = from; p < to; p += step) {
    const s = view.coordsAtPos(p, 1), e = view.coordsAtPos(Math.min(to, p + step), -1);
    if (s && e && Math.abs(s.top - e.top) < 3) add(box(Math.min(s.left, e.left), s.top, Math.max(s.right, e.right), s.bottom));
    else if (s) add(box(s.left, s.top, s.left + 1, s.bottom));
  }
  return out;
}

// ==== LAGRANGE PEN (replaceable) ====
// The pen that sets Lagrange's edits down in the note: a fountain pen flies to each edit and strikes the old words
// through in rubric ink; the new text then takes its place in the note, unseen at first, and the pen writes it in its
// own handwriting exactly where it will stand: the first stroke is where the first letter of the new text is (same
// left edge, same baseline), each further line starts at the left edge of the note's own line and wraps where the
// text column does, and the lines are the note's lines. The handwriting may be larger than the note's type. A long
// edit is written for a few lines (settings.penLines, 3 by default; see penLines) and ends in an ellipsis; then the
// handwriting gives way to the text itself, which is already in its place, so nothing moves. Between edits the pen
// hovers; a moment after the last one it flies off.
// Mathematics in a replacement ($…$, $$…$$, and LaTeX's \(…\), \[…\] and bare environments) is drawn symbol by
// symbol, the nib following each one, where the note typesets it: in Live Preview the pen draws on the note's own
// typeset equation (an inline one in its line, a displayed one in its centred block), after the words around it are
// set down. Where the note shows the source instead (Source mode, or an equation the cursor is in) the equation is
// typeset with Obsidian's MathJax (loaded first, and waited for) in the pen's script; if it can't be typeset (no
// MathJax, or a TeX error) the pen writes its source like other text, and says why on the console (equationPlan).
// A short line of ink trails behind the nib as it moves (settings.penTrail) and fades in half a second.
// Code in a replacement (a fenced block, or a code span of a few characters) is not written but typed: the pen gives
// way to a small typewriter, and the code appears in the monospace font one character at a time, at a typist's uneven
// pace, with a carriage return at each line end and no trail of ink; for the prose around it the pen comes back.
//
// Contract
//   createPen(app, settings) -> { edit(view, from, to, replacement, run): Promise<void>, destroy() }
//     settings.penSpeed (0.5 slow .. 3 fast), settings.penTrail and settings.penLines are read on every edit. Lagrange
//     calls edit() one edit at a time, in document order, with the editor locked and all changes folded into one undo
//     step; see runEdits. run (optional) is an object shared by the edits of one run: the pen keeps in run.spent how
//     long its handwriting has taken, and writes less of each later edit once that is long (penLines).
//   pen.edit(view, from, to, replacement): strike [from, to], view.dispatch the change, write `replacement` over it,
//     and remove every mark it added. The change is dispatched exactly once, whatever happens. With
//     prefers-reduced-motion the pen does not fly, leaves no trail and draws no equation: the old words dim briefly
//     and the change is made.
//   pen.destroy(): removes the pen, its ink and its decorations from every window, and stops its timers.
function createPen(app, settings) {
  const setGone = StateEffect.define();   // a DecorationSet, or null to clear
  const goneField = StateField.define({
    create: () => Decoration.none,
    update(deco, tr) {
      deco = deco.map(tr.changes);
      for (const e of tr.effects) if (e.is(setGone)) deco = e.value || Decoration.none;
      return deco;
    },
    provide: f => EditorView.decorations.from(f),
  });
  const goneMark = Decoration.mark({ class: 'lagrange-pen-gone' });
  const unwrittenMark = Decoration.mark({ class: 'lagrange-pen-unwritten' });   // new text the pen has yet to write
  const SVGNS = 'http://www.w3.org/2000/svg';
  const views = new Set();
  const layers = new Map();               // document -> { svg, marks, pen, pos, lift, idle, win, trail }
  const TRAIL_MS = 520, TRAIL_BANDS = 5;  // how long the ink trail lasts, and how many strokes it is drawn in
  let destroyed = false;

  const install = view => {
    if (view.state.field(goneField, false) === undefined) view.dispatch({ effects: StateEffect.appendConfig.of(goneField) });
    views.add(view);
  };
  const mk = (doc, tag, attrs, parent) => {
    const e = doc.createElementNS(SVGNS, tag);
    for (const k in attrs) e.setAttribute(k, String(attrs[k]));
    if (parent) parent.appendChild(e);
    return e;
  };

  function layerFor(doc) {
    let L = layers.get(doc);
    if (L && L.svg.isConnected) return L;
    const svg = mk(doc, 'svg', { class: 'lagrange-pen-layer', 'aria-hidden': 'true' });
    doc.body.appendChild(svg);
    const defs = mk(doc, 'defs', {}, svg);
    const pat = mk(doc, 'pattern', { id: 'lagrange-pen-hatch', width: 3, height: 3, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(80)' }, defs);
    mk(doc, 'rect', { width: 3, height: 3, fill: 'var(--lg-plate)' }, pat);
    mk(doc, 'line', { x1: 0, y1: 0, x2: 0, y2: 3, stroke: 'var(--lg-ink)', 'stroke-width': 0.7, opacity: 0.45 }, pat);
    const trailG = mk(doc, 'g', { class: 'lagrange-pen-trail' }, svg);
    const marks = mk(doc, 'g', {}, svg);
    const pen = mk(doc, 'g', { class: 'lagrange-pen' }, svg);
    // drawn horizontally with the nib's tip at (0, 0), then turned so the barrel rises to the upper right
    const body = mk(doc, 'g', { transform: 'rotate(-38)' }, pen);
    const st = { stroke: 'var(--lg-ink)', 'stroke-width': 1.2, 'stroke-linejoin': 'round' };
    mk(doc, 'path', { d: 'M0 0 L16 -5.2 Q22 -6.5 26 -6 L26 6 Q22 6.5 16 5.2 Z', fill: 'var(--lg-plate)', ...st }, body);   // nib
    mk(doc, 'line', { x1: 2, y1: 0, x2: 17, y2: 0, stroke: 'var(--lg-ink)', 'stroke-width': 0.8 }, body);                     // slit
    mk(doc, 'circle', { cx: 18, cy: 0, r: 1.3, fill: 'var(--lg-ink)' }, body);                                                 // breather hole
    mk(doc, 'path', { d: 'M26 -6.5 H48 Q51 -7.5 54 -8 V8 Q51 7.5 48 6.5 H26 Z', fill: 'var(--lg-ink)', opacity: 0.85 }, body);  // section
    mk(doc, 'path', { d: 'M54 -8.5 H150 Q158 -8.5 160 0 Q158 8.5 150 8.5 H54 Z', fill: 'url(#lagrange-pen-hatch)', ...st }, body); // barrel
    mk(doc, 'rect', { x: 92, y: -9, width: 7, height: 18, fill: 'var(--lg-rubric)', opacity: 0.9 }, body);                    // band
    mk(doc, 'path', { d: 'M100 -9 H140 Q144 -9 144 -6', fill: 'none', stroke: 'var(--lg-ink)', 'stroke-width': 1.6 }, body);  // clip
    pen.style.display = 'none';
    // The typewriter that types code, drawn with the point where a letter lands at (0, 0): the platen across the top,
    // the body below it, three rows of keys, and the carriage lever on the left.
    const type = mk(doc, 'g', { class: 'lagrange-typewriter' }, svg);
    mk(doc, 'path', { d: 'M-3.2 -1 L0 2.6 L3.2 -1', fill: 'none', stroke: 'var(--lg-rubric)', 'stroke-width': 1.3, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, type);
    mk(doc, 'rect', { x: -19, y: 3, width: 38, height: 6, rx: 3, fill: 'var(--lg-ink)', opacity: 0.85 }, type);
    mk(doc, 'path', { d: 'M-24 6 H-19 M19 6 H23 M-24 6 V1', fill: 'none', stroke: 'var(--lg-ink)', 'stroke-width': 1.4, 'stroke-linecap': 'round' }, type);
    mk(doc, 'path', { d: 'M-15 9 H15 L21 27 Q22 31 18 31 H-18 Q-22 31 -21 27 Z', fill: 'var(--lg-plate)', ...st }, type);
    mk(doc, 'path', { d: 'M-15 9 H15 L16.5 13.5 H-16.5 Z', fill: 'url(#lagrange-pen-hatch)', stroke: 'var(--lg-ink)', 'stroke-width': 0.8, 'stroke-linejoin': 'round' }, type);
    for (let row = 0; row < 3; row++) {
      for (let i = 0; i < 6 + row; i++) {
        mk(doc, 'circle', { cx: (i - (5 + row) / 2) * 5, cy: 17.5 + row * 4.3, r: 1.35, fill: row === 2 && i === 3 ? 'var(--lg-rubric)' : 'var(--lg-ink)' }, type);
      }
    }
    type.style.display = 'none';
    L = { svg, marks, pen, type, pos: null, lift: 0, idle: 0, win: doc.defaultView || window, trail: { g: trailG, pts: [], paths: [], on: false } };
    layers.set(doc, L);
    return L;
  }

  /* The trail: the nib's recent positions, redrawn each frame as a few strokes that thin and fade with age (see
     trailBands). The loop runs only while there is ink left to fade. */
  const drawTrail = L => {
    const T = L.trail;
    if (destroyed || !L.svg.isConnected) { T.on = false; return; }
    const now = L.win.performance.now();
    while (T.pts.length && now - T.pts[0].t > TRAIL_MS) T.pts.shift();
    const bands = trailBands(T.pts, now, TRAIL_MS, TRAIL_BANDS);
    while (T.paths.length < bands.length) {
      T.paths.push(mk(L.svg.ownerDocument, 'path', { fill: 'none', stroke: 'var(--lg-rubric)', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, T.g));
    }
    T.paths.forEach((path, i) => {
      const b = bands[i];
      if (!b) { path.setAttribute('d', ''); return; }
      path.setAttribute('d', b.d);
      path.setAttribute('opacity', b.opacity);
      path.setAttribute('stroke-width', b.width);
    });
    if (T.pts.length) L.win.requestAnimationFrame(() => drawTrail(L)); else T.on = false;
  };
  const inkTrail = (L, x, y) => {
    const T = L.trail, last = T.pts[T.pts.length - 1];
    if (last && Math.hypot(x - last.x, y - last.y) < 1.2) return;
    T.pts.push({ x, y, t: L.win.performance.now() });
    if (T.pts.length > 240) T.pts.shift();
    if (!T.on) { T.on = true; L.win.requestAnimationFrame(() => drawTrail(L)); }
  };

  const place = (L, x, y) => {
    L.pos = { x, y };
    L.pen.setAttribute('transform', `translate(${x.toFixed(1)} ${(y - L.lift).toFixed(1)}) scale(${(1 + L.lift * 0.012).toFixed(3)})`);
    if (settings && settings.penTrail !== false && L.pen.style.display !== 'none') inkTrail(L, x, y - L.lift);
  };
  const tween = (win, ms, fn) => new Promise(resolve => {
    const t0 = win.performance.now(), dur = Math.max(1, ms);
    const frame = now => {
      if (destroyed) { resolve(); return; }
      const k = Math.min(1, (now - t0) / dur);
      fn(k);
      if (k < 1) win.requestAnimationFrame(frame); else resolve();
    };
    win.requestAnimationFrame(frame);
  });
  const ease = k => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);
  const fly = async (L, x, y, ms, lift = 14) => {
    const a = L.pos ? { ...L.pos } : { x, y };
    const mx = (a.x + x) / 2, my = Math.min(a.y, y) - Math.min(60, 20 + Math.hypot(x - a.x, y - a.y) * 0.15);
    await tween(L.win, ms, k => {
      const e = ease(k), u = 1 - e;
      L.lift = Math.sin(k * Math.PI) * lift;
      place(L, u * u * a.x + 2 * u * e * mx + e * e * x, u * u * a.y + 2 * u * e * my + e * e * y);
    });
    L.lift = 0;
    place(L, x, y);
  };
  /* Obsidian's MathJax, loaded on first use and waited for: the first equation of a session has to wait for it (a
     second or two, more on a slow disk), and one drawn before it is there would come out as its source.
     -> {renderer, loaded, error}, for equationPlan. */
  const MATHJAX_WAIT = 9000;
  const mathReady = async () => {
    if (typeof obsidian.renderMath !== 'function') return { renderer: false };
    let error = '';
    try {
      if (typeof obsidian.loadMathJax === 'function') await Promise.race([obsidian.loadMathJax(), sleep(MATHJAX_WAIT)]);
    } catch (e) { error = String((e && e.message) || e || 'an error'); }
    return { renderer: true, loaded: typeof window.MathJax !== 'undefined' && window.MathJax !== null, error };
  };
  /* The symbols of a typeset equation, in the order TeX reads them: MathJax's CHTML output (Obsidian's) has one
     <mjx-c> per character; its SVG output has paths. */
  const mathGlyphs = el => {
    const svg = el.querySelector('svg');
    if (svg) return Array.from(svg.querySelectorAll('use, path, rect')).filter(n => !n.closest('defs'));
    return Array.from(el.querySelectorAll('mjx-c'));
  };
  /* Draws one symbol over ms: an SVG outline is traced by the nib and then filled; a CHTML character is uncovered
     from left to right under it. onX(x) reports how far right (viewport x) the ink has reached. */
  const drawGlyph = async (L, g, ms, onX) => {
    const win = L.win, r = g.getBoundingClientRect();
    if (r.width < 0.5 && r.height < 0.5) { g.style.opacity = ''; g.style.clipPath = ''; return; }
    let outline = null, len = 0, ctm = null;
    if (g.ownerSVGElement) {
      try {
        const href = g.tagName.toLowerCase() === 'use' ? (g.getAttribute('href') || g.getAttribute('xlink:href') || '') : '';
        outline = href ? g.ownerDocument.getElementById(href.replace(/^#/, '')) : g;
        len = outline && outline.getTotalLength ? outline.getTotalLength() : 0;
        ctm = len ? g.getScreenCTM() : null;
      } catch (e) { len = 0; }
    }
    if (Math.hypot(r.left - L.pos.x, r.bottom - L.pos.y) > 6) await fly(L, r.left, r.top + r.height * 0.6, Math.min(110, ms), 3);
    if (len && ctm) {
      g.style.opacity = '';
      g.style.fillOpacity = '0';
      g.style.stroke = 'currentColor';
      g.style.strokeWidth = '34';                     // MathJax draws in thousandths of an em
      g.style.strokeDasharray = String(len);
      await tween(win, ms, t => {
        g.style.strokeDashoffset = (len * (1 - t)).toFixed(1);
        let q = outline.getPointAtLength(len * t);
        q = new win.DOMPoint(q.x, q.y).matrixTransform(ctm);
        place(L, q.x, q.y);
        onX(r.left + r.width * t);
      });
      for (const k of ['fillOpacity', 'stroke', 'strokeWidth', 'strokeDasharray', 'strokeDashoffset']) g.style[k] = '';
    } else {
      g.style.opacity = '';
      await tween(win, ms, t => {
        g.style.clipPath = `inset(-60% ${((1 - t) * 100).toFixed(1)}% -60% -20%)`;
        // down the symbol's left side, then up and across to its right shoulder
        const y = t < 0.45 ? r.top + r.height * (0.25 + t * 1.6) : r.bottom - r.height * (t - 0.45) * 1.3;
        place(L, r.left + r.width * t, y);
        onX(r.left + r.width * t);
      });
      g.style.clipPath = '';
    }
  };

  /* Types one piece of code (see penScript): the typewriter takes the pen's place, sits under the letter it is
     typing and dips at each stroke; a line end is a carriage return. Then the pen comes back, where the typing ended. */
  const typeCode = async (L, piece, k) => {
    const win = L.win, [typed, mark, rest] = piece.el.childNodes;
    const text = piece.text;
    const pauses = typeCadence(text, 5200, text.length * 2654435761);
    const at = () => { const r = mark.getBoundingClientRect(); return { x: r.left, y: r.bottom }; };
    const put = (q, dip) => L.type.setAttribute('transform', `translate(${q.x.toFixed(1)} ${(q.y + 2 + (dip ? 1.4 : 0)).toFixed(1)})`);
    L.pen.style.display = 'none';
    L.trail.pts.length = 0;                          // no ink while typing
    L.type.style.display = '';
    put(at());
    let i = 0, n = 0;
    for (const ch of text) {
      if (destroyed) break;
      const before = at();
      i += ch.length;
      typed.textContent = text.slice(0, i);
      rest.textContent = text.slice(i);
      const ms = pauses[n++] * k;
      if (ch === '\n') {
        const after = at();                          // the carriage runs back to the start of the next line
        await tween(win, ms, t => { const e = ease(t); put({ x: before.x + (after.x - before.x) * e, y: before.y + (after.y - before.y) * e }); });
      } else {
        put(at(), true);
        await sleep(ms * 0.4);
        put(at(), false);
        await sleep(ms * 0.6);
      }
    }
    const end = at();
    L.type.style.display = 'none';
    L.pen.style.display = '';
    L.trail.pts.length = 0;
    L.lift = 0;
    place(L, end.x, end.y - 4);
  };

  /* A moment after the last edit the pen flies off. If another edit begins while it is leaving (L.busy counts the
     edits begun), it stops where it is and is not put away: otherwise the next edit would be written by no pen. */
  /* Where the character at pos stands: {x, top, bottom, baseline} in the viewport, or null if it is not drawn (off
     screen). The baseline is found from the font's own ascent and descent, which is what the character's box is. */
  const charBox = (view, pos) => {
    const c = view.coordsAtPos(pos, 1) || view.coordsAtPos(pos, -1);
    if (!c) return null;
    let ratio = 0.8;
    try {
      const at = view.domAtPos(pos);
      const el = at.node.nodeType === 1 ? at.node : at.node.parentElement;
      const win = el.ownerDocument.defaultView, cs = win.getComputedStyle(el);
      const ctx = (charBox.canvas || (charBox.canvas = el.ownerDocument.createElement('canvas'))).getContext('2d');
      ctx.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
      const m = ctx.measureText('x');
      if (m.fontBoundingBoxAscent > 0) ratio = m.fontBoundingBoxAscent / (m.fontBoundingBoxAscent + m.fontBoundingBoxDescent);
    } catch (e) { /* the usual proportion */ }
    return { x: c.left, top: c.top, bottom: c.bottom, baseline: c.top + (c.bottom - c.top) * ratio };
  };
  /* The text column at pos: the left and right edges between which the note's line wraps, and the height of its lines. */
  const columnAt = (view, pos) => {
    const win = view.dom.ownerDocument.defaultView || window;
    let el = null;
    try { const at = view.domAtPos(pos); el = (at.node.nodeType === 1 ? at.node : at.node.parentElement).closest('.cm-line'); } catch (e) { el = null; }
    const box = (el || view.contentDOM).getBoundingClientRect(), cs = win.getComputedStyle(el || view.contentDOM);
    const left = box.left + (parseFloat(cs.paddingLeft) || 0), right = box.right - (parseFloat(cs.paddingRight) || 0);
    const fs = parseFloat(cs.fontSize) || 16;
    return { left, right: Math.max(right, left + 40), lineHeight: parseFloat(cs.lineHeight) || fs * 1.5, fontSize: fs };
  };
  /* Waits until the character at pos stands still (the change, Typewriter Mode and smooth scrolling move the text
     for a few frames), bringing it on screen if it is not. -> its charBox, or null if it cannot be measured. */
  const settled = async (view, win, pos) => {
    let box = null, prev = null, steady = 0, asked = false;
    for (let i = 0; i < 60 && steady < 3 && !destroyed; i++) {
      await nextFrame(win);
      box = charBox(view, pos);
      if (!box && !asked) { asked = true; view.dispatch({ effects: EditorView.scrollIntoView(pos, { y: 'center' }) }); }
      steady = box && prev && Math.abs(box.top - prev.top) < 0.5 && Math.abs(box.x - prev.x) < 0.5 ? steady + 1 : 0;
      prev = box;
    }
    return box;
  };
  /* The note's own typeset equations that an edit has just put in (Live Preview): those that were not there `before`
     and whose source is one of `maths`, in the order they stand. -> [{el, source}] */
  const bare = t => String(t || '').replace(/\s+/g, '');
  const newEquations = (view, before, maths, claimed) => {
    const wanted = maths.map(g => bare(g.source)), out = [];
    for (const el of view.contentDOM.querySelectorAll('mjx-container')) {
      if (before.has(el) || claimed.has(el)) continue;
      const m = el.querySelector('mjx-math[data-latex]') || el.querySelector('[data-latex]');
      const i = m ? wanted.indexOf(bare(m.getAttribute('data-latex'))) : -1;
      if (i < 0) continue;
      wanted[i] = null;
      claimed.add(el);
      el.style.opacity = '0';
      out.push({ el, source: maths[i].source });
    }
    return out;
  };
  /* Draws one of the note's own equations where it stands, as drawGlyph draws each symbol; one too long for that is
     uncovered from left to right under the nib. It is in the pen's ink while it is drawn, then turns to the note's. */
  const drawInPlace = async (L, box, k) => {
    const win = L.win, glyphs = mathGlyphs(box);
    if (!box.isConnected) return;
    let shown = 0;
    const reveal = x => {
      const r = box.getBoundingClientRect();
      shown = Math.max(shown, x - r.left);
      box.style.clipPath = `inset(-0.6em ${Math.max(0, r.width - shown).toFixed(1)}px -0.6em -0.2em)`;
    };
    box.classList.add('lagrange-pen-drawing');
    const start = box.getBoundingClientRect();
    reveal(start.left);
    if (glyphs.length && glyphs.length <= 90) {
      for (const g of glyphs) g.style.opacity = '0';
      box.style.opacity = '';
      const each = Math.min(170, 3600 / glyphs.length) * k;
      for (const g of glyphs) {
        if (destroyed || !box.isConnected) break;
        await drawGlyph(L, g, each, reveal);
      }
      for (const g of glyphs) { g.style.opacity = ''; g.style.clipPath = ''; }
    } else {
      box.style.opacity = '';
      await fly(L, start.left, start.top + start.height * 0.6, 280 * k, 6);
      await tween(win, Math.min(2400, start.width * 9) * k, t => {
        const r = box.getBoundingClientRect(), x = r.left + r.width * t;
        reveal(x);
        place(L, x, r.top + r.height * 0.6 + Math.sin((x - r.left) * 0.55) * 3.2 - 2);
      });
    }
    box.style.clipPath = '';
    box.style.transition = 'color 420ms ease';
    box.classList.remove('lagrange-pen-drawing');
    win.setTimeout(() => { box.style.transition = ''; }, 480);
  };

  const park = (L, view) => {
    L.win.clearTimeout(L.idle);
    const busy = L.busy;
    L.idle = L.win.setTimeout(async () => {
      if (destroyed || !L.pos || L.busy !== busy) return;
      const r = view.dom.getBoundingClientRect();
      const a = { ...L.pos }, x = r.right + 80, y = r.top - 60;
      const mx = (a.x + x) / 2, my = Math.min(a.y, y) - Math.min(60, 20 + Math.hypot(x - a.x, y - a.y) * 0.15);
      await tween(L.win, 700, k => {
        if (L.busy !== busy) return;
        const e = ease(k), u = 1 - e;
        L.lift = Math.sin(k * Math.PI) * 14;
        place(L, u * u * a.x + 2 * u * e * mx + e * e * x, u * u * a.y + 2 * u * e * my + e * e * y);
      });
      if (L.busy !== busy) return;
      L.lift = 0;
      L.pen.style.display = 'none';
      L.pos = null;
    }, 1400);
  };

  return {
    async edit(view, from, to, replacement, run) {
      if (destroyed) throw new Error('The pen was put away.');
      const doc = view.dom.ownerDocument, win = doc.defaultView || window;
      const still = prefersReducedMotion(win);
      const speed = Number(settings && settings.penSpeed) > 0 ? Number(settings.penSpeed) : 1;
      const k = 1 / speed;
      install(view);
      view.dispatch({ effects: EditorView.scrollIntoView(from, { y: 'center' }) });
      // Wait for the text to stop moving (Typewriter Mode and smooth scrolling keep it moving for a few frames).
      let rects = [], prev = null, steady = 0;
      for (let i = 0; i < 90 && steady < 4; i++) {
        await nextFrame(win);
        rects = rangeRects(view, from, Math.max(from, to));
        const top = rects.length ? rects[0].top : null;
        steady = prev !== null && top !== null && Math.abs(top - prev) < 0.5 ? steady + 1 : 0;
        prev = top;
      }
      if (still || !rects.length) {
        if (to > from) {
          view.dispatch({ effects: setGone.of(Decoration.set([goneMark.range(from, to)])) });
          await sleep(220 * k);
        }
        view.dispatch({ changes: { from, to, insert: replacement }, effects: setGone.of(null) });
        return;
      }
      const L = layerFor(doc);
      win.clearTimeout(L.idle);
      L.busy = (L.busy || 0) + 1;
      L.lift = 0;
      const vr = view.dom.getBoundingClientRect();
      if (!L.pos) place(L, Math.min(win.innerWidth - 20, vr.right + 80), Math.max(10, vr.top - 40));
      L.pen.style.display = '';
      const r0 = rects[0];
      const mid = r => r.top + r.height * 0.58;
      const text = String(replacement == null ? '' : replacement);
      const ink = [];                                   // the strokes that strike the old words out
      const claimed = new Set();                        // the note's own equations the pen has taken to draw
      let committed = false, hand = null, following = false;
      const commit = spec => {
        if (committed) return;
        committed = true;
        view.dispatch(Object.assign({ changes: { from, to, insert: text } }, spec));
      };
      try {
        await fly(L, r0.left - 2, mid(r0), 650 * k);
        if (to > from) {
          ink.push(mk(doc, 'circle', { cx: r0.left - 2, cy: mid(r0), r: 1.6, fill: 'var(--lg-rubric)', opacity: 0.8 }, L.marks));
          view.dispatch({ effects: setGone.of(Decoration.set([goneMark.range(from, to)])) });
          for (let i = 0; i < rects.length && !destroyed; i++) {
            const r = rects[i], y0 = mid(r), x0 = r.left - 2, x1 = r.right + 2;
            const p = mk(doc, 'path', {
              d: `M${x0} ${y0} C ${x0 + (x1 - x0) * 0.3} ${y0 - 1.6}, ${x0 + (x1 - x0) * 0.7} ${y0 + 1.6}, ${x1} ${y0 - 0.6}`,
              fill: 'none', stroke: 'var(--lg-rubric)', 'stroke-width': 1.7, 'stroke-linecap': 'round',
            }, L.marks);
            ink.push(p);
            const len = p.getTotalLength();
            p.style.strokeDasharray = String(len);
            p.style.strokeDashoffset = String(len);
            if (i) await fly(L, x0, y0, 240 * k, 6);
            await tween(win, Math.min(len * 3.2, 900) * k, t => {
              p.style.strokeDashoffset = (len * (1 - t)).toFixed(1);
              const q = p.getPointAtLength(len * t);
              place(L, q.x, q.y);
            });
          }
          if (text) await sleep(200 * k);               // the struck words are seen struck, before they go
        }
        const lead = inkOffset(text), start = from + lead, end = from + text.length;
        if (destroyed || lead >= text.length) {
          if (!text && to > from) await sleep(260 * k);
          commit({ effects: setGone.of(null) });
        } else {
          // The new text goes into the note now, unseen, so that everything after it is where it will stay and the
          // pen can write where the text stands. Its equations: MathJax is loaded first, so Live Preview typesets them
          // at once, and the cursor is kept out of one that opens the text (Live Preview shows the source of an
          // equation the cursor touches).
          const live = Boolean(view.dom.closest('.is-live-preview'));
          const maths = mathSegments(text).filter(g => g.type === 'math');
          const mj = maths.length ? await mathReady() : null;
          const before = live && maths.length ? new Set(view.contentDOM.querySelectorAll('mjx-container')) : null;
          const spec = { effects: setGone.of(Decoration.set([unwrittenMark.range(start, end)])) };
          if (before && from > 0 && /^(?:\$|\\\(|\\\[|\\begin\{)/.test(text)) spec.selection = { anchor: from - 1 };
          commit(spec);
          const fadeInk = Math.round(160 * k);
          for (const n of ink) { n.style.transition = `opacity ${fadeInk}ms ease`; n.style.opacity = '0'; }
          win.setTimeout(() => { for (const n of ink.splice(0)) n.remove(); }, fadeInk + 40);
          let targets = before ? newEquations(view, before, maths, claimed) : [];
          let at = await settled(view, win, start);
          if (before) targets = targets.concat(newEquations(view, before, maths, claimed));
          const inNote = targets.map(t => bare(t.source));
          if (before && targets.length < maths.length) {
            console.debug(`Lagrange: ${maths.length - targets.length} of ${maths.length} equation(s) in this edit are not typeset in the note here (off screen, the cursor is in one, or Obsidian does not read their delimiters), so the pen draws them in its script.`);
          }
          // The pen's script: the words (and code), and the equations the note does not typeset itself.
          const lines = rangeRects(view, start, end);
          const col = columnAt(view, start);
          const mayWrite = penLines(settings && settings.penLines, lines.length, run && run.spent, speed);
          const script = (at ? penScript(text, Math.min(520, 150 * mayWrite)) : []).filter(g => {
            if (g.type !== 'math') return true;
            const i = inNote.indexOf(bare(g.source));
            if (i < 0) return true;
            inNote[i] = null;
            return false;
          });
          const pieces = [];
          if (script.length) {
            hand = doc.createElement('div');
            hand.className = 'lagrange-pen-hand';
            hand.appendChild(doc.createElement('span')).className = 'lagrange-pen-base';   // sits on the first line's baseline
            for (const g of script) {
              const span = doc.createElement('span');
              if (g.type === 'code') {
                // typed text, a marker where the next letter lands, and the text still to come (it holds the slip's shape)
                span.className = `lagrange-pen-code${g.block ? ' is-block' : ''}`;
                span.appendChild(doc.createElement('span'));
                span.appendChild(doc.createElement('span')).className = 'lagrange-pen-code-mark';
                span.appendChild(doc.createElement('span')).className = 'lagrange-pen-code-rest';
                span.lastChild.textContent = g.text;
                span.style.visibility = 'hidden';         // the slip is laid down when its turn comes
                hand.appendChild(span);
                pieces.push({ el: span, code: true, text: g.text });
                continue;
              }
              if (g.type !== 'math') {
                span.textContent = g.text;
                hand.appendChild(span);
                pieces.push({ el: span, math: false, prose: true });
                continue;
              }
              // An equation: drawn as MathJax typesets it or, failing that, written as its source (equationPlan).
              const m = mj && mj.renderer && mj.loaded && !mj.error ? renderPenMath(g.source, g.display, obsidian.renderMath) : null;
              const plan = equationPlan(Object.assign({}, mj, {
                typeset: Boolean(m), failed: Boolean(m && m.querySelector('mjx-merror, [data-mjx-error]')), symbols: m ? mathGlyphs(m).length : 0,
              }));
              if (plan.how === 'draw') { span.className = 'lagrange-pen-math'; span.appendChild(m); }
              else {
                console.debug(`Lagrange: an equation was written as text, not drawn: ${plan.why}.`, mathSource(g));
                span.textContent = mathSource(g);
              }
              hand.appendChild(span);
              pieces.push({ el: span, math: plan.how === 'draw', prose: plan.how !== 'draw' });
            }
            // Laid over the text column: the first line starts where the text's first letter is, the others at the
            // column's left edge, on the note's lines.
            let fs = col.fontSize * 1.3;
            const lay = () => {
              hand.style.fontSize = `${fs.toFixed(1)}px`;
              hand.style.lineHeight = `${col.lineHeight.toFixed(2)}px`;
              hand.style.left = `${col.left.toFixed(2)}px`;
              hand.style.width = `${(col.right - col.left).toFixed(2)}px`;
              hand.style.textIndent = `${Math.max(0, at.x - col.left).toFixed(2)}px`;
              hand.style.top = '0px';
              const base = hand.firstChild.getBoundingClientRect().bottom - hand.getBoundingClientRect().top;
              hand.style.top = `${(at.baseline - base).toFixed(2)}px`;
            };
            doc.body.appendChild(hand);
            lay();
            if (pieces.some(q => q.math)) {
              // MathJax adds the styles for the symbols it used; wait for them, and for the fonts, before measuring.
              try { if (typeof obsidian.finishRenderMath === 'function') await Promise.race([obsidian.finishRenderMath(), sleep(1200)]); } catch (e) { /* drawn as it is */ }
              try { if (doc.fonts && doc.fonts.ready) await Promise.race([doc.fonts.ready, sleep(900)]); } catch (e) { /* drawn as it is */ }
              await nextFrame(win);
              at = charBox(view, start) || at;
              lay();
            }
            // No more lines than it may write, and on one line no further than the text itself goes (what follows it
            // on the line is the note's): first a smaller hand, then fewer words, ending in an ellipsis.
            const last = lines[lines.length - 1];
            const fits = () => {
              const hb = hand.getBoundingClientRect();
              if (Math.round(hb.height / col.lineHeight) > mayWrite) return false;
              if (lines.length !== 1 || !last) return true;
              const tail = pieces.length ? pieces[pieces.length - 1].el.getClientRects() : [];
              return !tail.length || tail[tail.length - 1].right <= Math.max(last.right, at.x + 24) + 6;
            };
            for (let i = 0; i < 4 && lines.length === 1 && !fits(); i++) { fs *= 0.94; lay(); }
            for (let i = 0; i < 80 && pieces.length && !fits(); i++) {
              const q = pieces[pieces.length - 1];
              if (!q.prose) {
                if (pieces.length === 1 || q.code) break;      // an equation or code alone is never left out
                q.el.remove(); pieces.pop(); continue;
              }
              const words = q.el.textContent.replace(/\s*…\s*$/, '').trimEnd();
              const cut = words.slice(0, Math.max(0, Math.min(words.length - 1, Math.floor(words.length * 0.9)))).replace(/\s*\S*$/, '');
              if (!cut.trim()) {
                if (pieces.length === 1) { q.el.textContent = words.slice(0, Math.max(1, Math.floor(words.length * 0.8))); if (words.length <= 2) break; continue; }
                q.el.remove(); pieces.pop();
                const p = pieces[pieces.length - 1];
                if (p && p.prose && !/…\s*$/.test(p.el.textContent)) p.el.textContent = p.el.textContent.trimEnd() + ' …';
                continue;
              }
              q.el.textContent = cut + ' …';
            }
            // While it is written the hand stays on the text, wherever the note scrolls or reflows to.
            following = true;
            const follow = () => {
              if (!following || destroyed || !hand.isConnected) return;
              const now = charBox(view, start);
              if (now && (Math.abs(now.x - at.x) > 0.4 || Math.abs(now.baseline - at.baseline) > 0.4)) { at = now; lay(); }
              win.requestAnimationFrame(follow);
            };
            win.requestAnimationFrame(follow);
            // The ink shows where the nib has been: each stretch of a line it has passed, kept as a box in the hand's own
            // measure (so it holds when the hand moves).
            const shown = [];
            const clip = () => { hand.style.clipPath = shown.length ? `path("${shown.map(b => `M${b.l.toFixed(1)} ${b.t.toFixed(1)}H${b.r.toFixed(1)}V${b.b.toFixed(1)}H${b.l.toFixed(1)}Z`).join('')}")` : 'inset(0 100% 0 0)'; };
            // (a line's box is the note's line and a little below it, for the tails of its letters: not the line under it)
            const within = (r, whole) => {
              const hb = hand.getBoundingClientRect(), half = whole ? r.height / 2 + 2 : col.lineHeight / 2, c = (r.top + r.bottom) / 2 - hb.top;
              return { l: r.left - hb.left - 2, t: c - half, r: r.right - hb.left + 2, b: c + half + (whole ? 0 : col.lineHeight * 0.03) };
            };
            clip();
            const widthOf = q => Array.from(q.el.getClientRects()).reduce((a, r) => a + r.width, 0);
            const pace = penPace(pieces.filter(q => q.prose).reduce((a, q) => a + widthOf(q), 0));
            const t0 = win.performance.now();
            for (const piece of pieces) {
              if (destroyed) break;
              if (piece.code) {
                shown.push(within(piece.el.getBoundingClientRect(), true));   // the slip is laid down empty; its letters are typed
                clip();
                piece.el.style.visibility = '';
                await typeCode(L, piece, k);
                continue;
              }
              if (piece.math) {
                const glyphs = mathGlyphs(piece.el);
                const box = within(piece.el.getBoundingClientRect(), true), right = box.r;
                const upTo = x => { box.r = Math.max(box.r, Math.min(right, x - hand.getBoundingClientRect().left)); clip(); };
                box.r = box.l;
                shown.push(box);
                if (glyphs.length && glyphs.length <= 90) {
                  for (const g of glyphs) g.style.opacity = '0';
                  const each = Math.min(170, 3600 / glyphs.length) * k;
                  for (const g of glyphs) {
                    if (destroyed) break;
                    await drawGlyph(L, g, each, upTo);
                  }
                } else {
                  const pr = piece.el.getBoundingClientRect();
                  await fly(L, pr.left, pr.top + pr.height * 0.7, 280 * k, 6);
                  await tween(win, Math.min(2400, pr.width * 9) * k, t => {
                    const r = piece.el.getBoundingClientRect(), x = r.left + r.width * t;
                    upTo(x);
                    place(L, x, r.top + r.height * 0.7 + Math.sin(x * 0.55) * 3.2 - 2);
                  });
                }
                box.r = right;
                clip();
                continue;
              }
              // words: along each line they take, the nib a little above the baseline and never still
              const n = piece.el.getClientRects().length;
              for (let i = 0; i < n && !destroyed; i++) {
                const first = piece.el.getClientRects()[i];
                if (!first || first.width < 0.5) continue;
                const box = within(first), right = box.r, width = first.width;
                box.r = box.l;
                shown.push(box);
                const y0 = first.top + first.height * 0.72;
                if (Math.hypot(first.left - L.pos.x, y0 - L.pos.y) > 4) await fly(L, first.left, y0, (i ? 240 : 280) * k, 6);
                await tween(win, Math.max(60, width * pace) * k, t => {
                  const r = piece.el.getClientRects()[i] || first, x = r.left + r.width * t;
                  box.r = box.l + (right - box.l) * t;
                  clip();
                  place(L, x, r.top + r.height * 0.72 + Math.sin(x * 0.55) * 3.2 - 2);
                });
                box.r = right;
              }
            }
            hand.style.clipPath = 'none';
            if (run) run.spent = (run.spent || 0) + (win.performance.now() - t0);
            await fly(L, Math.min(vr.right - 12, L.pos.x + 30), L.pos.y - 18, 280 * k, 10);
            await sleep(380 * k);
          }
          // The handwriting gives way to the text, which is already where it belongs.
          const fade = Math.round(300 * k);
          view.dom.style.setProperty('--lagrange-pen-reveal', `${fade}ms`);
          view.dom.classList.add('lagrange-pen-revealing');
          if (hand) { hand.style.transition = `opacity ${fade}ms ease`; hand.style.opacity = '0'; }
          if (targets.length && !destroyed) {
            await sleep(fade * 0.6);
            // Then the equations, each where the note has it.
            for (const t of targets.slice(0, SCRIPT_EQUATIONS)) {
              if (destroyed) break;
              await drawInPlace(L, t.el, k);
            }
            if (!destroyed) {
              await fly(L, Math.min(vr.right - 12, L.pos.x + 30), L.pos.y - 18, 280 * k, 10);
              await sleep(380 * k);                       // the finished equation is looked at for a moment
            }
          } else if (!hand) {
            await sleep(120 * k);
          } else {
            await sleep(fade);
          }
        }
      } finally {
        following = false;
        L.type.style.display = 'none';
        L.pen.style.display = '';
        commit({});
        for (const el of claimed) { el.style.opacity = ''; el.style.clipPath = ''; el.classList.remove('lagrange-pen-drawing'); for (const g of mathGlyphs(el)) { g.style.opacity = ''; g.style.clipPath = ''; } }
        const fade = Math.round(300 * k);
        const gone = hand;
        for (const n of ink) { n.style.transition = `opacity ${fade}ms ease`; n.style.opacity = '0'; }
        if (gone) { gone.style.transition = `opacity ${fade}ms ease`; gone.style.opacity = '0'; }
        win.setTimeout(() => { for (const n of ink) n.remove(); if (gone) gone.remove(); }, fade + 40);
        // The text is in full view by now (or the pen was put away): the marks on it come off.
        try { view.dispatch({ effects: setGone.of(null) }); } catch (e) { /* the view is gone */ }
        view.dom.classList.remove('lagrange-pen-revealing');
        view.dom.style.removeProperty('--lagrange-pen-reveal');
        park(L, view);
      }
    },
    destroy() {
      destroyed = true;
      for (const view of views) {
        try { if (view.state.field(goneField, false) !== undefined) view.dispatch({ effects: setGone.of(null) }); } catch (e) { /* view gone */ }
      }
      views.clear();
      for (const [doc, L] of layers) {
        try { L.win.clearTimeout(L.idle); } catch (e) { /* window closed */ }
        L.svg.remove();
        for (const n of doc.querySelectorAll('.lagrange-pen-hand')) n.remove();
      }
      layers.clear();
    },
  };
}
// ==== END LAGRANGE PEN ====


/* ---------------------------------------------------------------------------------------------------------------
 * 6. Edit runs
 *
 * A run applies one request's edits to an editor. With the pen, each edit is written in turn; meanwhile the editor is
 * locked (not editable, read-only) and no change goes into the undo history. At the end the run's changes are taken
 * back and made again in one transaction, which becomes a single undo step. Without the pen, all edits go in one
 * transaction straight away.
 * ------------------------------------------------------------------------------------------------------------- */

const lockCompartment = new Compartment();
const EDIT_RECORDS = 30;   // how many runs of edits Undo and Redo remember

function lockExtension(run) {
  return [
    EditorView.editable.of(false),
    EditorState.readOnly.of(true),
    EditorState.transactionExtender.of(tr => (tr.docChanged ? { annotations: Transaction.addToHistory.of(false) } : null)),
    EditorView.updateListener.of(update => {
      if (run.closed) return;
      for (const tr of update.transactions) if (tr.docChanged) run.composed = run.composed.compose(tr.changes);
    }),
    EditorView.editorAttributes.of({ class: 'lagrange-writing' }),
  ];
}

function setLock(view, content) {
  if (lockCompartment.get(view.state) === undefined) view.dispatch({ effects: StateEffect.appendConfig.of(lockCompartment.of(content)) });
  else view.dispatch({ effects: lockCompartment.reconfigure(content) });
}

/* Applies located edits ({from, to, matched, replace}, in document order, offsets in the current document) to view.
   Returns {applied, skipped, changes, docBefore}: changes is a ChangeSet from docBefore to the document after. */
async function runEdits(view, located, opts) {
  const applied = [];
  const skipped = [];
  const docBefore = view.state.doc;
  if (!opts.pen) {
    const ok = located.filter(e => view.state.sliceDoc(e.from, e.to) === e.matched);
    for (const e of located) if (!ok.includes(e)) skipped.push(Object.assign({}, e, { why: 'the text changed' }));
    if (!ok.length) return { applied, skipped, changes: ChangeSet.empty(docBefore.length), docBefore };
    const changes = ChangeSet.of(ok.map(e => ({ from: e.from, to: e.to, insert: e.replace })), docBefore.length);
    view.dispatch({ changes, userEvent: 'lagrange.edit', scrollIntoView: true });
    return { applied: ok, skipped, changes, docBefore };
  }

  const run = { composed: ChangeSet.empty(docBefore.length), closed: false, cancelled: false, spent: 0 };   // spent: see createPen
  const doc = view.dom.ownerDocument;
  const onKey = ev => { if (ev.key === 'Escape') run.cancelled = true; };
  doc.addEventListener('keydown', onKey, true);
  if (opts.signal) opts.signal.addEventListener('abort', () => { run.cancelled = true; }, { once: true });
  setLock(view, lockExtension(run));
  let failure = null;
  try {
    for (const e of located) {
      if (run.cancelled) { skipped.push(Object.assign({}, e, { why: 'stopped' })); continue; }
      const from = run.composed.mapPos(e.from, 1);
      const to = run.composed.mapPos(e.to, -1);
      if (to < from || view.state.sliceDoc(from, to) !== e.matched) {
        skipped.push(Object.assign({}, e, { why: 'the text changed' }));
        continue;
      }
      try {
        // The cursor goes to the edit first, so the edit is on screen even with typewriter scrolling (Typewriter
        // Mode keeps the cursor's line centred).
        view.dispatch({ selection: { anchor: from }, effects: EditorView.scrollIntoView(from, { y: 'center' }) });
        await opts.pen.edit(view, from, to, e.replace, run);
      } catch (err) {
        failure = err;
        skipped.push(Object.assign({}, e, { why: 'the pen failed' }));
        break;
      }
      applied.push(e);
    }
  } finally {
    doc.removeEventListener('keydown', onKey, true);
    run.closed = true;
    const cs = run.composed;
    if (cs.empty) {
      setLock(view, []);
    } else {
      // Back to the text as it was (outside the history), then all of the run's changes as one undo step.
      view.dispatch({ changes: cs.invert(docBefore), effects: lockCompartment.reconfigure([]), annotations: Transaction.addToHistory.of(false) });
      view.dispatch({ changes: cs, userEvent: 'lagrange.edit' });
    }
  }
  if (failure) {
    const leftover = located.slice(applied.length + skipped.length);
    for (const e of leftover) skipped.push(Object.assign({}, e, { why: 'not attempted' }));
    console.error('Lagrange: the pen failed', failure);
  }
  return { applied, skipped, changes: run.composed, docBefore, failure };
}


/* ---------------------------------------------------------------------------------------------------------------
 * 7. The chat view, the revise modal, the settings tab and the plugin
 * ------------------------------------------------------------------------------------------------------------- */

function renderMarkdown(app, markdown, el, sourcePath, component) {
  if (MarkdownRenderer.render) return MarkdownRenderer.render(app, markdown, el, sourcePath, component);
  return MarkdownRenderer.renderMarkdown(markdown, el, sourcePath, component);
}

let pickerUid = 0;   // radio groups need a name of their own in each picker drawn

class LagrangeChatView extends ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.history = [];           // [{role: 'user'|'assistant', content}], what the model sees
    this.pending = null;         // {controller} while a chat reply is streaming
    this.clipNoted = new Set();  // notes whose clipping the writer has been told about
    this.checkpoints = [];       // one per message sent, for "Rewind to here" (see rewindTo)
  }

  getViewType() { return VIEW_TYPE; }
  getDisplayText() { return 'Lagrange'; }
  getIcon() { return ICON; }

  async onOpen() {
    const root = this.contentEl;
    root.empty();
    root.addClass('lagrange-view');

    const head = root.createDiv({ cls: 'lagrange-head' });
    const titles = head.createDiv({ cls: 'lagrange-titles' });
    titles.createDiv({ cls: 'lagrange-title', text: 'Lagrange' });
    this.subjectEl = titles.createDiv({ cls: 'lagrange-subject' });
    const actions = head.createDiv({ cls: 'lagrange-actions' });
    const proof = actions.createEl('button', { cls: 'lagrange-icon clickable-icon', attr: { 'aria-label': 'Proofread the note' } });
    setIcon(proof, 'spell-check');
    proof.addEventListener('click', () => {
      const v = this.plugin.targetMarkdownView();
      if (v) this.plugin.proofread(v);
      else new Notice('Open a note to proofread first.');
    });
    // Undo and Redo for Lagrange's own edits (a run of edits at a time; see the plugin's undoEdit and redoEdit).
    this.undoEl = actions.createEl('button', { cls: 'lagrange-icon clickable-icon', attr: { 'aria-label': 'Undo Lagrange’s last edits' } });
    setIcon(this.undoEl, 'undo-2');
    this.undoEl.addEventListener('click', () => { const r = undoTarget(this.plugin.edits); if (r) this.plugin.undoEdit(r); });
    this.redoEl = actions.createEl('button', { cls: 'lagrange-icon clickable-icon', attr: { 'aria-label': 'Redo Lagrange’s edits' } });
    setIcon(this.redoEl, 'redo-2');
    this.redoEl.addEventListener('click', () => { const r = redoTarget(this.plugin.edits); if (r) this.plugin.redoEdit(r); });
    const clear = actions.createEl('button', { cls: 'lagrange-icon clickable-icon', attr: { 'aria-label': 'Clear the conversation' } });
    setIcon(clear, 'eraser');
    clear.addEventListener('click', () => this.clear());

    this.logEl = root.createDiv({ cls: 'lagrange-log', attr: { 'aria-live': 'polite' } });
    this.logEl.addEventListener('click', ev => this.onLinkClick(ev));
    this.logEl.addEventListener('scroll', () => { this.stick = this.isNearBottom(); });

    const compose = root.createDiv({ cls: 'lagrange-compose' });
    this.inputEl = compose.createEl('textarea', {
      cls: 'lagrange-input',
      attr: { rows: '2', placeholder: this.plugin.settings.agenticEdits ? 'Ask about this note, or ask for a change…' : 'Ask about this note…', 'aria-label': 'Message to Lagrange' },
    });
    this.inputEl.addEventListener('keydown', ev => {
      if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) {
        ev.preventDefault();
        this.send();
      }
    });
    this.inputEl.addEventListener('input', () => this.fitInput());
    const foot = compose.createDiv({ cls: 'lagrange-foot' });
    const left = foot.createDiv({ cls: 'lagrange-foot-left' });
    // The model and effort in use: a button that opens the picker (openPicker).
    this.modelEl = left.createEl('button', {
      cls: 'lagrange-model',
      attr: { type: 'button', 'aria-haspopup': 'dialog', 'aria-expanded': 'false' },
    });
    this.modelEl.addEventListener('click', () => (this.picker ? this.closePicker() : this.openPicker()));
    left.createSpan({ cls: 'lagrange-hint', text: 'Enter to send, Shift+Enter for a new line' });
    this.composeEl = compose;
    this.picker = null;
    this.sendEl = foot.createEl('button', { cls: 'lagrange-send', text: 'Send' });
    this.sendEl.addEventListener('click', () => (this.pending ? this.stop() : this.send()));

    this.registerEvent(this.app.workspace.on('active-leaf-change', () => this.refreshSubject()));
    this.registerEvent(this.app.workspace.on('file-open', () => this.refreshSubject()));
    this.refreshSubject();
    this.refreshFoot();
    this.refreshHistory();
    this.showEmpty();
  }

  /* The Undo and Redo buttons are live only when there is a run of Lagrange's edits to take back or to make again. */
  refreshHistory() {
    if (!this.undoEl) return;
    this.undoEl.disabled = !undoTarget(this.plugin.edits);
    this.redoEl.disabled = !redoTarget(this.plugin.edits);
  }

  async onClose() {
    this.stop();
    this.closePicker();
  }

  refreshSubject() {
    if (!this.subjectEl) return;
    const v = this.plugin.targetMarkdownView();
    this.subjectEl.empty();
    if (v && v.file) {
      this.subjectEl.appendText('on ');
      this.subjectEl.createEl('em', { text: v.file.basename });
    } else {
      this.subjectEl.setText('no note open');
    }
  }

  refreshFoot() {
    if (!this.modelEl) return;
    const s = this.plugin.settings;
    this.modelEl.empty();
    this.modelEl.createSpan({ cls: 'lagrange-model-name', text: footLabel(s) });
    this.modelEl.createSpan({ cls: 'lagrange-model-caret', text: '▾', attr: { 'aria-hidden': 'true' } });
    this.modelEl.setAttribute('aria-label', `Model: ${footLabel(s)}. Change the model or the effort`);
    this.modelEl.setAttribute('title', 'Change the model or the effort');
  }

  /* The picker: a small sheet over the footer with the current provider's models (and a field to type another), and
     the reasoning effort. Radio buttons, so the arrow keys move within a group and Tab between groups; Esc, a click
     elsewhere or the button again closes it. Every choice is saved at once. */
  openPicker() {
    if (this.picker || !this.composeEl) return;
    const doc = this.composeEl.ownerDocument;
    const el = this.composeEl.createDiv({ cls: 'lagrange-picker', attr: { role: 'dialog', 'aria-label': 'Model and effort' } });
    const onDown = ev => { if (!el.contains(ev.target) && !this.modelEl.contains(ev.target)) this.closePicker(); };
    const onKey = ev => {
      if (ev.key !== 'Escape') return;
      ev.preventDefault();
      ev.stopPropagation();
      this.closePicker(true);
    };
    doc.addEventListener('mousedown', onDown, true);
    el.addEventListener('keydown', onKey);
    this.picker = { el, close: () => { doc.removeEventListener('mousedown', onDown, true); el.remove(); } };
    this.modelEl.setAttribute('aria-expanded', 'true');
    this.modelEl.addClass('is-open');
    this.drawPicker();
    const first = el.querySelector('input[type="radio"]:checked:not(:disabled), input:not(:disabled), button');
    if (first) first.focus();
  }

  closePicker(refocus) {
    if (!this.picker) return;
    this.picker.close();
    this.picker = null;
    this.modelEl.setAttribute('aria-expanded', 'false');
    this.modelEl.removeClass('is-open');
    if (refocus) this.modelEl.focus();
  }

  drawPicker(focus) {
    if (!this.picker) return;
    const el = this.picker.el, s = this.plugin.settings;
    const choices = modelChoices(s);
    const uid = `lagrange-pick-${++pickerUid}`;
    const save = async keep => { await this.plugin.saveSettings(); this.drawPicker(keep); };
    el.empty();

    const models = el.createEl('fieldset', { cls: 'lagrange-pick-group' });
    const legend = models.createEl('legend');
    legend.createSpan({ text: 'Model' });
    legend.createSpan({ cls: 'lagrange-pick-provider', text: choices.provider });
    for (const o of choices.options) {
      const label = models.createEl('label', { cls: 'lagrange-pick' });
      const input = label.createEl('input', { attr: { type: 'radio', name: `${uid}-model`, value: o.value } });
      input.checked = o.value === choices.current;
      input.addEventListener('change', () => { if (input.checked) { setModel(s, o.value); save(`model:${o.value}`); } });
      label.createSpan({ text: o.label });
    }
    if (choices.free) {
      const row = models.createDiv({ cls: 'lagrange-pick-other' });
      const input = row.createEl('input', {
        cls: 'lagrange-pick-input',
        attr: { type: 'text', placeholder: choices.options.length ? `Another model: ${choices.placeholder}` : choices.placeholder,
          'aria-label': 'Another model', spellcheck: 'false', autocomplete: 'off' },
      });
      const use = () => {
        const v = input.value.trim();
        if (!v || v === choices.current) return;
        setModel(s, v);
        save(`model:${v}`);
      };
      input.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); use(); } });
      input.addEventListener('change', use);
    } else if (!choices.options.length) {
      models.createDiv({ cls: 'lagrange-pick-note', text: 'The demo has no model: its replies are canned.' });
    }

    const can = effortSupported(s);
    const efforts = el.createEl('fieldset', { cls: 'lagrange-pick-group lagrange-pick-efforts' });
    efforts.createEl('legend', { text: 'Effort' });
    if (!can) efforts.disabled = true;
    const row = efforts.createDiv({ cls: 'lagrange-pick-row' });
    for (const [value, name] of [['', 'Default']].concat(EFFORTS.map(e => [e, e[0].toUpperCase() + e.slice(1)]))) {
      const label = row.createEl('label', { cls: 'lagrange-pick' });
      const input = label.createEl('input', { attr: { type: 'radio', name: `${uid}-effort`, value } });
      input.checked = can ? value === s.effort : value === '';
      input.addEventListener('change', () => { if (input.checked) { s.effort = value; save(`effort:${value}`); } });
      label.createSpan({ text: name });
    }
    efforts.createDiv({
      cls: 'lagrange-pick-note',
      text: can ? 'How hard the model thinks before it answers. Default leaves it to the provider.'
        : (s.provider === 'demo' ? 'The demo does no thinking.' : 'This model takes no effort setting.'),
    });

    const foot = el.createDiv({ cls: 'lagrange-pick-foot' });
    const link = foot.createEl('button', { cls: 'lagrange-pick-settings', text: 'Provider and keys…', attr: { type: 'button' } });
    link.addEventListener('click', () => { this.closePicker(); this.plugin.openSettings(); });

    if (focus) {
      const [group, value] = [focus.slice(0, focus.indexOf(':')), focus.slice(focus.indexOf(':') + 1)];
      const again = Array.from(el.querySelectorAll(`input[name="${uid}-${group}"]`)).find(i => i.value === value);
      if (again) again.focus();
    }
  }

  fitInput() {
    const el = this.inputEl;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  }

  showEmpty() {
    if (this.logEl.childElementCount) return;
    const e = this.logEl.createDiv({ cls: 'lagrange-empty' });
    e.createDiv({ cls: 'lagrange-fleuron', text: '❦', attr: { 'aria-hidden': 'true' } });
    const s = this.plugin.settings;
    e.createEl('p', {
      text: s.agenticEdits
        ? 'Ask about the note you are writing, or ask for a change: Lagrange reads the open note with each message and edits it with its pen.'
        : 'Ask about the note you are writing. Lagrange reads the open note with each question.',
    });
    const p = e.createEl('p', { cls: 'lagrange-quiet' });
    if (s.agenticEdits) {
      p.appendText('One undo takes back all the edits of a request. ');
      p.createEl('em', { text: 'Revise selection' });
      p.appendText(' and ');
      p.createEl('em', { text: 'Proofread note' });
      p.appendText(' are in the command palette too.');
    } else {
      p.appendText('To have it edit, select a passage and run ');
      p.createEl('em', { text: 'Revise selection' });
      p.appendText(', or run ');
      p.createEl('em', { text: 'Proofread note' });
      p.appendText(', from the command palette.');
    }
    if (s.provider === 'demo') {
      e.createEl('p', { cls: 'lagrange-quiet', text: 'Demo mode: replies and edits are canned, and nothing leaves Obsidian.' });
    } else if ((s.provider === 'claude-code' || s.provider === 'codex') && obsidian.Platform && obsidian.Platform.isDesktopApp === false) {
      const m = e.createEl('p', { cls: 'lagrange-quiet' });
      m.appendText('A subscription works only in Obsidian on a computer. On this device, choose an API key provider (or the Demo): ');
      const a = m.createEl('a', { text: 'open settings', attr: { href: '#' } });
      a.addEventListener('click', ev => { ev.preventDefault(); this.plugin.openSettings(); });
      m.appendText('.');
    }
  }

  clearEmpty() {
    const e = this.logEl.querySelector('.lagrange-empty');
    if (e) e.remove();
  }

  isNearBottom() {
    const el = this.logEl;
    return el.scrollHeight - el.scrollTop - el.clientHeight < 48;
  }

  scrollDown(force) {
    if (force || this.stick) this.logEl.scrollTop = this.logEl.scrollHeight;
  }

  clear() {
    this.stop();
    this.history = [];
    this.checkpoints = [];
    this.clipNoted.clear();
    this.logEl.empty();
    this.showEmpty();
  }

  stop() {
    if (this.pending) this.pending.controller.abort();
  }

  setPending(p) {
    this.pending = p;
    this.sendEl.setText(p ? 'Stop' : 'Send');
    this.sendEl.toggleClass('is-stop', Boolean(p));
  }

  onLinkClick(ev) {
    const a = ev.target.closest && ev.target.closest('a.internal-link');
    if (!a) return;
    ev.preventDefault();
    const href = a.getAttribute('data-href') || a.getAttribute('href');
    const v = this.plugin.targetMarkdownView();
    if (href) this.app.workspace.openLinkText(href, (v && v.file && v.file.path) || '', ev.ctrlKey || ev.metaKey);
  }

  /* The writer's message in the log, with its "Rewind to here" button. */
  addUser(text, checkpoint) {
    this.clearEmpty();
    const el = this.logEl.createDiv({ cls: 'lagrange-turn lagrange-turn--user' });
    el.createDiv({ cls: 'lagrange-turn-text', text });
    if (checkpoint) {
      checkpoint.el = el;
      const b = el.createEl('button', { cls: 'lagrange-rewind clickable-icon' });
      setIcon(b, 'history');
      checkpoint.button = b;
      this.labelRewind(checkpoint);
      b.addEventListener('click', () => { this.rewind(checkpoint); });
    }
    this.scrollDown(true);
    return el;
  }

  labelRewind(cp) {
    if (!cp.button) return;
    const label = cp.expired
      ? 'Rewind the conversation to here and edit this message. The note as it was then is no longer kept (only ' +
        `the last ${CHECKPOINTS_KEPT} points are), so it would be left as it is`
      : 'Rewind to here: the conversation and the note go back to this point, and you can edit this message';
    cp.button.setAttribute('aria-label', label);
    cp.button.toggleClass('is-expired', Boolean(cp.expired));
  }

  /* "Rewind to here": drops this message and everything after it from the conversation (and from what the model is
     sent), puts the note back as it was when the message was sent, and puts the message back in the box to be
     edited. If the note holds changes that are not Lagrange's since then, the writer chooses whether to keep them. */
  async rewind(cp) {
    const k = this.checkpoints.indexOf(cp);
    if (k < 0) return;
    if (this.pending || this.plugin.editing) { new Notice('Lagrange is still at work: stop it, or wait, then rewind.'); return; }
    let restore = false, kept = false;
    if (cp.path && cp.before != null) {
      const current = await this.plugin.noteText(cp.path);
      if (current !== null && current !== cp.before) {
        if (userChangedSince(this.checkpoints, k, current)) {
          const choice = await new RewindModal(this.app).ask();
          if (!choice) return;
          restore = choice === 'restore';
          kept = !restore;
        } else {
          restore = true;
        }
      }
    }
    const back = rewindTo(this.history, this.checkpoints, k);
    this.history = back.history;
    this.checkpoints = back.checkpoints;
    for (let n = cp.el; n;) { const next = n.nextSibling; n.remove(); n = next; }
    if (restore) {
      try {
        await this.plugin.restoreNote(cp.path, cp.before, cp.clock);
      } catch (e) {
        new Notice(`The conversation was rewound, but the note could not be put back: ${e.message}`);
      }
    }
    this.showEmpty();
    this.inputEl.value = cp.text;
    this.fitInput();
    this.inputEl.focus();
    if (cp.expired) new Notice(`Rewound the conversation. The note as it was then is no longer kept (only the last ${CHECKPOINTS_KEPT} points are), so it was left as it is.`, 8000);
    else if (kept) new Notice('Rewound the conversation; the note was left as it is.');
    else if (restore) new Notice('Rewound: the conversation and the note are as they were at that message. Undo in the editor brings the note’s later text back.', 8000);
  }

  addAside(text, cls) {
    this.clearEmpty();
    const el = this.logEl.createDiv({ cls: `lagrange-aside ${cls || ''}`.trim(), text });
    this.scrollDown();
    return el;
  }

  /* A reply in the log: a loader until the first words, then Markdown, re-rendered as text streams in. */
  addReply(sourcePath) {
    this.clearEmpty();
    const el = this.logEl.createDiv({ cls: 'lagrange-turn lagrange-turn--reply' });
    const body = el.createDiv({ cls: 'lagrange-turn-body markdown-rendered' });
    let loader = mountLoader(body.createDiv({ cls: 'lagrange-loader-slot' }), this.plugin.settings.loaderTheme);
    let md = '', shown = null, timer = null, comp = null, status = null;
    const render = () => {
      timer = null;
      if (md === shown) return;
      shown = md;
      if (loader) { loader.stop(); loader = null; }
      const next = new Component();
      this.addChild(next);
      const box = createDiv();
      renderMarkdown(this.app, md, box, sourcePath || '', next);
      body.empty();
      body.appendChild(box);
      if (comp) this.removeChild(comp);
      comp = next;
      this.scrollDown();
    };
    return {
      el,
      update: text => {
        md = text;
        if (!timer) timer = window.setTimeout(render, 90);
      },
      // keep: the turn stays in the log although it has no prose (its edits are about to be listed in it)
      finish: (text, keep) => {
        if (timer) { window.clearTimeout(timer); timer = null; }
        if (status) { status.remove(); status = null; }
        md = text;
        if (md) render();
        if (loader) { loader.stop(); loader = null; }
        if (!md) { body.empty(); if (!keep) el.addClass('is-empty'); }
      },
      // one line under the reply while it streams ("Taking up the pen…"); finish() removes it
      status: text => {
        if (!status) status = el.createDiv({ cls: 'lagrange-turn-note is-quiet lagrange-turn-status' });
        if (status.textContent !== text) { status.setText(text); this.scrollDown(); }
      },
      note: (text, cls) => {
        el.createDiv({ cls: `lagrange-turn-note ${cls || ''}`.trim(), text });
        this.scrollDown();
      },
    };
  }

  addError(err, el) {
    const box = (el || this.logEl).createDiv({ cls: 'lagrange-error' });
    box.createSpan({ text: err.message || String(err) });
    if (err.kind === 'setup' || err.status === 401) {
      box.appendText(' ');
      const a = box.createEl('a', { text: 'Open settings', attr: { href: '#' } });
      a.addEventListener('click', ev => { ev.preventDefault(); this.plugin.openSettings(); });
    }
    this.scrollDown();
    return box;
  }

  async send() {
    if (this.pending) return;
    const text = this.inputEl.value.trim();
    if (!text) return;
    this.inputEl.value = '';
    this.fitInput();
    this.stick = true;

    const target = this.plugin.targetMarkdownView();
    const note = this.plugin.noteFrom(target);
    const limit = NOTE_LIMIT[this.plugin.settings.provider] || NOTE_LIMIT.anthropic;
    const clip = note ? clipText(note.text, limit, note.cursor) : null;

    // The checkpoint for "Rewind to here": where the conversation stands, and the note as it is now.
    const checkpoint = {
      text, historyLength: this.history.length, path: note ? note.path : null, before: note ? note.text : null, after: null,
      expired: false, clock: this.plugin.editClock,
    };
    this.checkpoints.push(checkpoint);
    this.addUser(text, checkpoint);
    if (clip && clip.clipped && !this.clipNoted.has(note.path)) {
      this.clipNoted.add(note.path);
      this.addAside(`“${note.title}” is long (${clip.total.toLocaleString()} characters), so Lagrange reads the ` +
        `${(clip.end - clip.start).toLocaleString()} characters around your cursor.`);
    }
    this.history.push({ role: 'user', content: text });
    const reply = this.addReply(note && note.path);
    const controller = new AbortController();
    this.setPending({ controller });
    const settings = this.plugin.settings;
    // With "Edit with the pen" on, the reply may end with edits to the note (parseAgentReply): the chat shows only its
    // prose, and the edits go to the pen once the reply is complete.
    const agentic = Boolean(settings.agenticEdits);
    const prose = full => {
      if (!agentic) return full;
      const part = splitAgentReply(full);
      if (part.blocks.length) reply.status('Taking up the pen…');
      return part.text;
    };
    let partial = '', raw = '';
    try {
      const res = await complete(settings, {
        purpose: 'chat',
        system: chatSystemPrompt(note, clip, agentic),
        messages: this.history.slice(),
        cache: true,
        demo: () => demoChatReply(text, note, agentic),
      }, {
        signal: controller.signal,
        onText: (d, full) => { raw = full; partial = prose(full); reply.update(partial); },
        onRetry: (status, ms) => reply.note(`Busy (${status}); trying again in ${Math.round(ms / 1000)} s…`, 'is-quiet'),
      }, this.plugin.session);
      const parsed = agentic ? parseAgentReply(res.text) : { text: res.text, ops: [], dropped: 0, error: null, open: false };
      const editing = parsed.ops.length > 0 && res.stopReason !== 'refusal';
      reply.finish(parsed.text, editing || Boolean(parsed.error));
      if (res.text && res.stopReason !== 'refusal') this.history.push({ role: 'assistant', content: res.text });
      else this.history.pop();
      if (editing) {
        await this.plugin.applyChatEdits(target, note, parsed, reply, controller.signal);
      } else if (parsed.error) {
        reply.note(`Lagrange meant to edit the note, but its edits could not be read. ${parsed.error}` +
          `${res.stopReason === 'max_tokens' ? ' (The reply reached its length limit.)' : ''} Nothing was changed; ask again.`, 'is-warn');
      }
      if (res.stopReason === 'refusal') {
        const cat = res.stopDetails && res.stopDetails.category;
        reply.note(`Claude declined to continue${cat ? ` (${cat})` : ''}. Try rephrasing the question.`, 'is-warn');
      } else if (res.stopReason === 'max_tokens') {
        reply.note('The reply reached its length limit.', 'is-quiet');
      }
      if (res.fallbackTo) reply.note(`Answered by ${res.fallbackTo} after a refusal.`, 'is-quiet');
    } catch (err) {
      if (isAbort(err)) {
        // Stopped mid-reply: what was said stays; edits that had not finished arriving are not made.
        reply.finish(partial);
        reply.note(raw !== partial && splitAgentReply(raw).blocks.length ? 'Stopped before any edit was made.' : 'Stopped.', 'is-quiet');
        if (partial) this.history.push({ role: 'assistant', content: partial });
        else this.history.pop();
      } else {
        reply.finish(partial);
        this.history.pop();
        if (!partial) reply.el.remove();
        this.addError(err);
        if (!this.inputEl.value) { this.inputEl.value = text; this.fitInput(); }
      }
    } finally {
      this.setPending(null);
      // What the turn left in the note, so a later rewind can tell Lagrange's changes from the writer's; then the
      // oldest checkpoints give up their copies of the note.
      if (checkpoint.path && this.checkpoints.includes(checkpoint)) {
        try {
          const now = await this.plugin.noteText(checkpoint.path);
          checkpoint.after = now === null || now === checkpoint.before ? null : now;
        } catch (e) { /* the note is gone: nothing to remember */ }
      }
      for (const cp of pruneCheckpoints(this.checkpoints, CHECKPOINTS_KEPT, CHECKPOINT_CHARS)) this.labelRewind(cp);
    }
  }

  /* A task (proofread, revise) in the log: a heading, a loader while the model works, then the edits. */
  beginTask(title, subtitle, controller) {
    this.clearEmpty();
    this.stick = true;
    const el = this.logEl.createDiv({ cls: 'lagrange-turn lagrange-turn--task' });
    const head = el.createDiv({ cls: 'lagrange-task-head' });
    head.createSpan({ cls: 'lagrange-task-title', text: title });
    if (subtitle) head.createSpan({ cls: 'lagrange-task-subtitle', text: subtitle });
    let stopEl = null;
    if (controller) {
      stopEl = head.createEl('button', { cls: 'lagrange-task-stop', text: 'Stop' });
      stopEl.addEventListener('click', () => controller.abort());
    }
    const status = el.createDiv({ cls: 'lagrange-task-status' });
    let loader = mountLoader(el.createDiv({ cls: 'lagrange-loader-slot' }), this.plugin.settings.loaderTheme);
    const stopLoader = () => { if (loader) { loader.stop(); loader = null; } };
    const end = () => { stopLoader(); if (stopEl) { stopEl.remove(); stopEl = null; } };
    this.scrollDown(true);
    return {
      el,
      status: text => { status.setText(text); this.scrollDown(); },
      stopLoader,
      fail: err => { end(); status.empty(); this.addError(err, el); },
      done: text => { end(); status.setText(text); this.scrollDown(); },
      report: (result, onUndo) => { end(); status.empty(); this.renderReport(el, result, onUndo); },
    };
  }

  renderReport(el, result, onUndo) {
    const { applied, skipped } = result;
    const n = applied.length, m = skipped.length;
    const summary = n
      ? `${n} edit${n === 1 ? '' : 's'} made${m ? `, ${m} skipped` : ''}.`
      : (m ? `No edits made; ${m} skipped.` : 'Nothing to correct.');
    el.createDiv({ cls: 'lagrange-task-summary', text: summary });
    const item = (list, e, why) => {
      const li = list.createEl('li');
      const line = li.createDiv({ cls: 'lagrange-edit-line' });
      if (e.insert) line.createSpan({ cls: 'lagrange-arrow', text: '+ ' });       // an insertion: nothing is struck
      else {
        line.createEl('del', { cls: 'lagrange-del', text: excerpt(e.matched || e.find, 160) });
        line.createSpan({ cls: 'lagrange-arrow', text: ' → ' });
      }
      if (e.replace) line.createEl('ins', { cls: 'lagrange-ins', text: excerpt(e.insert ? e.replace.trim() : e.replace, 160) });
      else line.createEl('span', { cls: 'lagrange-ins is-deletion', text: 'deleted' });
      const reason = why ? `${e.reason ? e.reason + '; ' : ''}skipped: ${why}${e.insert && e.find ? ` (“${excerpt(e.find, 60)}”)` : ''}` : e.reason;
      if (reason) li.createDiv({ cls: 'lagrange-reason', text: reason });
    };
    if (n) {
      const list = el.createEl('ol', { cls: 'lagrange-edits' });
      for (const e of applied) item(list, e);
    }
    if (m) {
      el.createDiv({ cls: 'lagrange-skipped-head', text: 'Skipped' });
      const list = el.createEl('ul', { cls: 'lagrange-edits is-skipped' });
      for (const e of skipped) item(list, e, e.why);
    }
    if (n && onUndo) {
      // onUndo is the run's record (see the plugin's recordEdit): the button undoes it, then offers to redo it.
      const record = onUndo;
      const b = el.createEl('button', { cls: 'lagrange-undo' });
      const show = () => {
        b.setText(!record.undone ? 'Undo Lagrange’s edits' : record.redo ? 'Redo Lagrange’s edits' : 'Edits undone');
        b.disabled = Boolean(record.undone && !record.redo);
      };
      record.listeners.push(show);
      show();
      b.addEventListener('click', () => { if (record.undone) this.plugin.redoEdit(record); else this.plugin.undoEdit(record); });
    }
    this.scrollDown();
  }
}

/* Asks, before a rewind, what to do with a note that has changed since: resolves 'restore', 'keep' or null. */
class RewindModal extends Modal {
  ask() {
    return new Promise(resolve => { this.resolve = resolve; this.open(); });
  }

  onOpen() {
    this.modalEl.addClass('lagrange-modal');
    this.titleEl.setText('Rewind to here');
    this.contentEl.createEl('p', {
      text: 'The note has changes that are not Lagrange’s since this message. Put the note back as it was then (your ' +
        'later changes go, though Undo in the editor brings them back), or rewind the conversation only and keep the ' +
        'note as it is?',
    });
    const row = this.contentEl.createDiv({ cls: 'lagrange-modal-buttons' });
    const pick = (text, value, cls) => {
      const b = row.createEl('button', { text, cls: cls || '' });
      b.addEventListener('click', () => { this.choice = value; this.close(); });
      return b;
    };
    pick('Cancel', null);
    pick('Put the note back', 'restore');
    const keep = pick('Keep the note as it is', 'keep', 'mod-cta');
    window.setTimeout(() => keep.focus(), 0);
  }

  onClose() {
    this.contentEl.empty();
    if (this.resolve) { this.resolve(this.choice || null); this.resolve = null; }
  }
}

class ReviseModal extends Modal {
  constructor(app, passage, onSubmit) {
    super(app);
    this.passage = passage;
    this.onSubmit = onSubmit;
  }

  onOpen() {
    this.modalEl.addClass('lagrange-modal');
    this.titleEl.setText('Revise selection');
    const { contentEl } = this;
    contentEl.createEl('blockquote', { cls: 'lagrange-modal-passage', text: excerpt(this.passage.trim(), 240) });
    const input = contentEl.createEl('textarea', {
      cls: 'lagrange-modal-input',
      attr: { rows: '2', placeholder: 'How should it change? For example: tighter, more formal, a better rhythm', 'aria-label': 'Instruction' },
    });
    const row = contentEl.createDiv({ cls: 'lagrange-modal-buttons' });
    const cancel = row.createEl('button', { text: 'Cancel' });
    const go = row.createEl('button', { cls: 'mod-cta', text: 'Revise' });
    const submit = () => {
      const v = input.value.trim();
      if (!v) { input.focus(); return; }
      this.close();
      this.onSubmit(v);
    };
    input.addEventListener('keydown', ev => {
      if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) { ev.preventDefault(); submit(); }
    });
    go.addEventListener('click', submit);
    cancel.addEventListener('click', () => this.close());
    window.setTimeout(() => input.focus(), 0);
  }

  onClose() {
    this.contentEl.empty();
  }
}

/* "Lagrange: Draw a drop cap": the letter, what it should look like, and the set it goes into. */
class DropcapDrawModal extends Modal {
  constructor(plugin, view, known) {
    super(plugin.app);
    this.plugin = plugin;
    this.view = view;
    this.known = known;     // {letter, sets: [{name, letters: {T: 'png' | 'svg'}}]}: the writer's sets Lagrange could add to
  }

  onOpen() {
    this.modalEl.addClass('lagrange-modal');
    this.titleEl.setText('Draw a drop cap');
    const { contentEl } = this;
    const s = this.plugin.settings;
    contentEl.createEl('p', { cls: 'lagrange-modal-note', text: dropcapRouteNote(s) });
    const row = contentEl.createDiv({ cls: 'lagrange-dropcap-row' });
    const letter = row.createEl('input', { type: 'text', cls: 'lagrange-dropcap-letter', attr: { maxlength: '1', 'aria-label': 'Letter', placeholder: 'A' } });
    letter.value = this.known.letter || '';
    const set = row.createEl('input', { type: 'text', cls: 'lagrange-dropcap-set', attr: { 'aria-label': 'Set of drop caps', placeholder: 'Set', list: 'lagrange-dropcap-sets' } });
    set.value = (this.known.sets[0] && this.known.sets[0].name) || 'Lagrange';
    const names = contentEl.createEl('datalist', { attr: { id: 'lagrange-dropcap-sets' } });
    for (const k of this.known.sets) names.createEl('option', { attr: { value: k.name } });
    const input = contentEl.createEl('textarea', {
      cls: 'lagrange-modal-input',
      attr: { rows: '2', placeholder: 'What should it look like? For example: a woodcut initial with vine leaves; an Art Nouveau letter with irises', 'aria-label': 'Description' },
    });
    const monoRow = contentEl.createEl('label', { cls: 'lagrange-dropcap-check' });
    const mono = monoRow.createEl('input', { type: 'checkbox' });
    mono.checked = true;
    monoRow.appendText(' One colour: ink only, printed in the page’s accent colour in the light and the dark theme');
    const changeRow = contentEl.createEl('label', { cls: 'lagrange-dropcap-check' });
    const change = changeRow.createEl('input', { type: 'checkbox' });
    changeRow.appendText(' Change the one this set has for this letter (the description says how), rather than draw afresh');
    const present = () => {
      const k = this.known.sets.find(x => x.name.toLowerCase() === set.value.trim().toLowerCase());
      return k ? k.letters[dropcapLetter(letter.value)] : null;
    };
    const refresh = () => { const has = Boolean(present()); changeRow.style.display = has ? '' : 'none'; if (!has) change.checked = false; };
    letter.addEventListener('input', refresh);
    set.addEventListener('input', refresh);
    refresh();
    const said = contentEl.createEl('p', { cls: 'lagrange-modal-problem' });
    const buttons = contentEl.createDiv({ cls: 'lagrange-modal-buttons' });
    const cancel = buttons.createEl('button', { text: 'Cancel' });
    const go = buttons.createEl('button', { cls: 'mod-cta', text: 'Draw' });
    const submit = () => {
      const l = dropcapLetter(letter.value);
      if (!l) { said.setText('Give one letter, A to Z.'); letter.focus(); return; }
      if (!set.value.trim()) { said.setText('Name the set it goes into.'); set.focus(); return; }
      if (change.checked && !input.value.trim()) { said.setText('Say how it should change.'); input.focus(); return; }
      this.close();
      void this.plugin.drawDropcap(this.view, { letter: l, set: set.value.trim(), style: change.checked ? '' : input.value.trim(), mono: mono.checked, change: change.checked ? input.value.trim() : '' });
    };
    input.addEventListener('keydown', ev => {
      if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) { ev.preventDefault(); submit(); }
    });
    go.addEventListener('click', submit);
    cancel.addEventListener('click', () => this.close());
    window.setTimeout(() => (letter.value ? input : letter).focus(), 0);
  }

  onClose() {
    this.contentEl.empty();
  }
}

class LagrangeSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    const save = async redraw => { await this.plugin.saveSettings(); if (redraw) this.display(); };
    containerEl.empty();
    containerEl.addClass('lagrange-settings');

    containerEl.createEl('p', {
      cls: 'setting-item-description',
      text: 'Lagrange sends the open note and your messages to the provider chosen here, and only when you ask it ' +
        'something or run one of its commands. It makes no other network requests and collects nothing.',
    });

    new Setting(containerEl)
      .setName('Provider')
      .setDesc('Who writes the replies and edits.')
      .addDropdown(d => d
        .addOption('claude-code', 'Claude: my subscription (via Claude Code)')
        .addOption('anthropic', 'Claude: API key')
        .addOption('codex', 'ChatGPT: my subscription (via Codex)')
        .addOption('openai-api', 'OpenAI: API key')
        .addOption('openai', 'OpenAI-compatible server (Ollama, LM Studio…)')
        .addOption('demo', 'Demo (offline)')
        .setValue(s.provider)
        .onChange(async v => { s.provider = v; await save(true); }));

    if (s.provider === 'anthropic') {
      new Setting(containerEl).setName('Anthropic').setHeading();
      new Setting(containerEl)
        .setName('API key')
        .setDesc(createFragment(f => {
          f.appendText('Create one at console.anthropic.com. Like other Obsidian AI plugins, Lagrange keeps it in plain ' +
            'text in this vault’s ');
          f.createEl('code', { text: '.obsidian/plugins/lagrange/data.json' });
          f.appendText(' and sends it only to api.anthropic.com; keep that file out of anything you share.');
        }))
        .addText(t => {
          t.inputEl.type = 'password';
          t.inputEl.autocomplete = 'off';
          t.inputEl.spellcheck = false;
          t.setPlaceholder('sk-ant-…').setValue(s.anthropicApiKey).onChange(async v => { s.anthropicApiKey = v.trim(); await save(); });
        });
      new Setting(containerEl)
        .setName('Model')
        .setDesc('Sonnet is quick and capable; Opus is the most careful; Haiku is the fastest and cheapest.')
        .addDropdown(d => {
          for (const m of ANTHROPIC_MODELS) d.addOption(m.id, m.name);
          d.addOption('custom', 'Another model…');
          d.setValue(s.anthropicModel).onChange(async v => { s.anthropicModel = v; await save(true); });
        });
      if (s.anthropicModel === 'custom') {
        new Setting(containerEl)
          .setName('Model ID')
          .setDesc('The exact model ID, as listed in Anthropic’s documentation.')
          .addText(t => t.setPlaceholder('claude-…').setValue(s.anthropicCustomModel)
            .onChange(async v => { s.anthropicCustomModel = v.trim(); await save(); }));
      }
      new Setting(containerEl)
        .setName('Refusal fallback')
        .setDesc('If Claude’s safety screening declines a request, let Anthropic retry it on another Claude model in the ' +
          'same call (a beta feature, for Sonnet 5.5 and Opus 5.5). Turned off automatically if your account lacks it.')
        .addToggle(t => t.setValue(s.refusalFallback).onChange(async v => { s.refusalFallback = v; await save(); }));
    } else if (s.provider === 'claude-code' || s.provider === 'codex') {
      const claude = s.provider === 'claude-code';
      new Setting(containerEl).setName(claude ? 'Claude subscription' : 'ChatGPT subscription').setHeading();
      containerEl.createEl('p', {
        cls: 'setting-item-description',
        text: claude
          ? 'Uses your Claude Pro or Max plan through Claude Code, Anthropic’s command-line tool, signed in to your ' +
            'account: no API key, and requests count against your plan’s usage. Install Claude Code, run “claude” once ' +
            'in a terminal and sign in. Lagrange runs it with every tool, setting file and saved session turned off. ' +
            'Works in Obsidian on a computer only.'
          : 'Uses your ChatGPT Plus or Pro plan through Codex, OpenAI’s command-line tool, signed in to your account: no ' +
            'API key, and requests count against your plan’s usage. Install Codex, run “codex login” and choose “Sign ' +
            'in with ChatGPT”. Lagrange runs it read-only, in a temporary folder, without saving sessions. Works in ' +
            'Obsidian on a computer only.',
      });
      const pathKey = claude ? 'claudeCodePath' : 'codexPath', modelKey = claude ? 'claudeCodeModel' : 'codexModel';
      let status;
      new Setting(containerEl)
        .setName(claude ? 'Claude Code' : 'Codex')
        .setDesc('Leave empty to look in the usual places; or give the full path to the program.')
        .addText(t => t.setPlaceholder(claude ? '~/.local/bin/claude' : '/usr/local/bin/codex').setValue(s[pathKey])
          .onChange(async v => { s[pathKey] = v.trim(); await save(); }))
        .addButton(b => b.setButtonText('Check').onClick(async () => {
          status.setText('Checking…');
          status.setText(await checkCli(claude ? 'claude' : 'codex', s[pathKey]));
        }));
      status = containerEl.createEl('p', { cls: 'setting-item-description lagrange-cli-status' });
      new Setting(containerEl)
        .setName('Model')
        .setDesc(claude ? 'sonnet, opus or haiku (or a full model ID). Empty: Claude Code’s default.'
          : 'A model your plan includes, as Codex names it. Empty: Codex’s default.')
        .addText(t => t.setPlaceholder(claude ? 'sonnet' : 'default').setValue(s[modelKey])
          .onChange(async v => { s[modelKey] = v.trim(); await save(); }));
      if (obsidian.Platform && obsidian.Platform.isDesktopApp === false) {
        containerEl.createEl('p', {
          cls: 'setting-item-description mod-warning',
          text: 'This device can’t run it: a subscription works only in Obsidian on a computer. Choose an API key provider (or the Demo) here.',
        });
      }
    } else if (s.provider === 'openai-api') {
      new Setting(containerEl).setName('OpenAI').setHeading();
      new Setting(containerEl)
        .setName('API key')
        .setDesc('Create one at platform.openai.com. Stored in plain text in this vault’s .obsidian/plugins/lagrange/data.json ' +
          'and sent only to api.openai.com.')
        .addText(t => {
          t.inputEl.type = 'password';
          t.inputEl.autocomplete = 'off';
          t.inputEl.spellcheck = false;
          t.setPlaceholder('sk-…').setValue(s.openaiPlatformKey).onChange(async v => { s.openaiPlatformKey = v.trim(); await save(); });
        });
      new Setting(containerEl)
        .setName('Model')
        .setDesc('The model ID, as listed at platform.openai.com/docs/models.')
        .addText(t => t.setPlaceholder('model ID').setValue(s.openaiPlatformModel)
          .onChange(async v => { s.openaiPlatformModel = v.trim(); await save(); }));
      new Setting(containerEl)
        .setName('Image model')
        .setDesc('The model that paints for “Draw a drop cap”, through the Images API (OpenAI charges for each image). Experimental: not yet tried against the live API.')
        .addText(t => t.setPlaceholder(DEFAULT_SETTINGS.openaiImageModel).setValue(s.openaiImageModel)
          .onChange(async v => { s.openaiImageModel = v.trim() || DEFAULT_SETTINGS.openaiImageModel; await save(); }));
    } else if (s.provider === 'openai') {
      new Setting(containerEl).setName('OpenAI-compatible server').setHeading();
      new Setting(containerEl)
        .setName('Base URL')
        .setDesc('The server’s OpenAI-compatible address, ending in /v1. Ollama: http://localhost:11434/v1; LM Studio: ' +
          'http://localhost:1234/v1. The server must accept requests from Obsidian (CORS): Ollama does by default.')
        .addText(t => t.setPlaceholder('http://localhost:11434/v1').setValue(s.openaiBaseUrl)
          .onChange(async v => { s.openaiBaseUrl = v.trim(); await save(); }));
      new Setting(containerEl)
        .setName('Model')
        .setDesc('The model name the server knows, for example llama3.1 or qwen2.5:14b.')
        .addText(t => t.setPlaceholder('llama3.1').setValue(s.openaiModel)
          .onChange(async v => { s.openaiModel = v.trim(); await save(); }));
      new Setting(containerEl)
        .setName('API key')
        .setDesc('Only if the server asks for one. Stored in plain text in this vault’s .obsidian/plugins/lagrange/data.json.')
        .addText(t => {
          t.inputEl.type = 'password';
          t.inputEl.autocomplete = 'off';
          t.setPlaceholder('optional').setValue(s.openaiApiKey).onChange(async v => { s.openaiApiKey = v.trim(); await save(); });
        });
    } else {
      new Setting(containerEl).setName('Demo').setHeading();
      containerEl.createEl('p', {
        cls: 'setting-item-description',
        text: 'Canned replies and edits, made without a model and without the network: try the chat, the pen and ' +
          'undo without an API key.',
      });
    }

    if (s.provider !== 'demo') {
      const can = effortSupported(s);
      new Setting(containerEl)
        .setName('Effort')
        .setDesc(can ? 'How hard the model thinks before it answers. Also at the foot of the chat, with the model.'
          : 'This model takes no effort setting.')
        .addDropdown(d => {
          d.addOption('', 'The provider’s default');
          for (const e of EFFORTS) d.addOption(e, e[0].toUpperCase() + e.slice(1));
          d.setValue(can ? s.effort : '').onChange(async v => { s.effort = v; await save(); });
        })
        .setDisabled(!can);
    }

    new Setting(containerEl).setName('Editing').setHeading();
    new Setting(containerEl)
      .setName('Edit with the pen from the chat')
      .setDesc('When you ask in the chat for a change to the open note, Lagrange makes it with its pen (one undo takes ' +
        'it back). Off: the chat only talks, and edits come from the Revise selection and Proofread note commands.')
      .addToggle(t => t.setValue(s.agenticEdits).onChange(async v => { s.agenticEdits = v; await save(); }));

    new Setting(containerEl).setName('Appearance').setHeading();
    new Setting(containerEl)
      .setName('Loading animation')
      .setDesc('What the chat shows while Lagrange thinks.')
      .addDropdown(d => d.addOption('random', 'A different plate each time').addOption('clockwork', 'Clockwork').addOption('alchemy', 'Alchemy').addOption('orbit', 'The five Lagrange points')
        .setValue(s.loaderTheme).onChange(async v => { s.loaderTheme = v; await save(); }));
    new Setting(containerEl)
      .setName('Show the pen')
      .setDesc('Write each edit with a pen: strike the old text, write the new, then set it in the note. Off: edits ' +
        'are applied at once. Either way, one undo takes back all the edits of a request.')
      .addToggle(t => t.setValue(s.showPen).onChange(async v => { s.showPen = v; await save(true); }));
    new Setting(containerEl)
      .setName('Pen speed')
      .setDesc('From unhurried (0.5) to brisk (3).')
      .addSlider(sl => sl.setLimits(0.5, 3, 0.25).setValue(s.penSpeed).setDynamicTooltip()
        .onChange(async v => { s.penSpeed = v; await save(); }))
      .setDisabled(!s.showPen);
    new Setting(containerEl)
      .setName('Lines the pen writes')
      .setDesc('A long edit is written out for this many lines of the page, then the rest is set down at once; a shorter ' +
        'edit is written in full. In a run of many edits, later ones get a single line once the writing has taken about ten seconds.')
      .addSlider(sl => sl.setLimits(1, 8, 1).setValue(s.penLines).setDynamicTooltip()
        .onChange(async v => { s.penLines = v; await save(); }))
      .setDisabled(!s.showPen);
    new Setting(containerEl)
      .setName('Ink trail')
      .setDesc('A thin line of ink follows the pen as it moves and fades at once. Never shown when your system asks for reduced motion.')
      .addToggle(t => t.setValue(s.penTrail).onChange(async v => { s.penTrail = v; await save(); }))
      .setDisabled(!s.showPen);
  }
}

class LagrangePlugin extends Plugin {
  async onload() {
    // One settings object for the plugin's lifetime: the pen keeps a reference to it.
    this.settings = sanitizeSettings(await this.loadData());
    this.session = { noFallback: false, noEffort: {} };
    this.editing = false;
    this.edits = [];       // Lagrange's runs of edits, oldest first (see recordEdit); at most EDIT_RECORDS
    this.editClock = 0;    // counts the runs, so a rewind knows which came after a checkpoint
    this.pen = createPen(this.app, this.settings);

    this.registerEditorExtension([
      lockCompartment.of([]),
      EditorView.updateListener.of(update => this.trackEdits(update)),
    ]);
    this.registerView(VIEW_TYPE, leaf => new LagrangeChatView(leaf, this));
    this.addRibbonIcon(ICON, 'Open Lagrange', () => { this.activateView(); });

    this.addCommand({ id: 'open', name: 'Open', callback: () => { this.activateView(); } });
    this.addCommand({
      id: 'revise-selection',
      name: 'Revise selection',
      editorCheckCallback: (checking, editor, ctx) => {
        if (!(ctx instanceof MarkdownView) || !editor.somethingSelected()) return false;
        if (!checking) this.reviseSelection(ctx, editor);
        return true;
      },
    });
    this.addCommand({
      id: 'proofread-note',
      name: 'Proofread note',
      checkCallback: checking => {
        const view = this.app.workspace.getActiveViewOfType(MarkdownView);
        if (!view || !view.file) return false;
        if (!checking) this.proofread(view);
        return true;
      },
    });
    this.addCommand({
      id: 'draw-dropcap',
      name: 'Draw a drop cap (or change one)',
      checkCallback: checking => {
        const view = this.app.workspace.getActiveViewOfType(MarkdownView);
        if (!view || !view.file) return false;
        if (!checking) void this.askDropcap(view);
        return true;
      },
    });
    this.addSettingTab(new LagrangeSettingTab(this.app, this));

    this.lastMarkdownLeaf = null;
    this.registerEvent(this.app.workspace.on('active-leaf-change', leaf => {
      if (leaf && leaf.view instanceof MarkdownView) this.lastMarkdownLeaf = leaf;
    }));
  }

  onunload() {
    if (this.pen) this.pen.destroy();
  }

  async saveSettings() {
    await this.saveData(this.settings);
    for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
      if (leaf.view instanceof LagrangeChatView) leaf.view.refreshFoot();
    }
  }

  openSettings() {
    try {
      this.app.setting.open();
      this.app.setting.openTabById(this.manifest.id);
    } catch (e) {
      new Notice('Open Settings → Lagrange.');
    }
  }

  /* Opens the chat in the right sidebar (or finds it) and shows it; focus moves to it only when focus is true, so a
     task started from the editor leaves the cursor where it is. */
  async activateView(focus = true) {
    const ws = this.app.workspace;
    let leaf = ws.getLeavesOfType(VIEW_TYPE)[0];
    if (!leaf) {
      leaf = ws.getRightLeaf(false);
      if (!leaf) return null;
      await leaf.setViewState({ type: VIEW_TYPE, active: focus });
    }
    await ws.revealLeaf(leaf);
    const view = leaf.view instanceof LagrangeChatView ? leaf.view : null;
    if (focus) {
      ws.setActiveLeaf(leaf, { focus: true });
      if (view && view.inputEl) view.inputEl.focus();
    }
    return view;
  }

  /* The note Lagrange talks about: the active Markdown view, or, while the chat itself has focus, the last one. */
  targetMarkdownView() {
    const ws = this.app.workspace;
    const active = ws.getActiveViewOfType(MarkdownView);
    if (active && active.file) return active;
    const last = this.lastMarkdownLeaf;
    if (last && last.view instanceof MarkdownView && last.view.file && last.view.containerEl.isConnected) return last.view;
    const recent = ws.getMostRecentLeaf && ws.getMostRecentLeaf();
    if (recent && recent.view instanceof MarkdownView && recent.view.file) return recent.view;
    const any = ws.getLeavesOfType('markdown').map(l => l.view).find(v => v instanceof MarkdownView && v.file);
    return any || null;
  }

  noteFrom(view) {
    if (!view || !view.file) return null;
    let cursor;
    try {
      if (view.getMode() === 'source') cursor = view.editor.posToOffset(view.editor.getCursor());
    } catch (e) { /* no cursor */ }
    return { title: view.file.basename, path: view.file.path, text: view.getViewData(), cursor };
  }

  /* Lagrange's runs of edits, for Undo and Redo (the two buttons at the head of the chat, and the button under each
     run in the log). A record holds what is needed to take a run back and to make it again whatever has happened in
     the note since: {view, editor, path, clock, docBefore, docAfter, inverse, since, viaHistory, undone, redo,
     sinceUndo, redoStale, byHistory, undoneAt, listeners}. `since` is everything that has changed in the note after
     the run (kept up by trackEdits), so the run's inverse can be carried through later typing; once undone, `redo`
     is the change that makes the run again and `sinceUndo` what has changed since the undo. */
  recordEdit(cm, editor, path, result) {
    // The note has moved on: runs taken back before this one can no longer be made again.
    for (const r of this.edits) if (r.view === cm && r.undone && r.redo) { r.redo = null; this.announce(r); }
    const record = {
      view: cm, editor, path, clock: ++this.editClock, docBefore: result.docBefore, docAfter: cm.state.doc,
      inverse: result.changes.invert(result.docBefore), since: ChangeSet.empty(cm.state.doc.length),
      viaHistory: false, undone: false, redo: null, sinceUndo: null, redoStale: false, byHistory: false, undoneAt: 0,
      expecting: null, listeners: [],
    };
    this.edits.push(record);
    while (this.edits.length > EDIT_RECORDS) this.edits.shift();
    this.announce(record);
    return record;
  }

  /* Tells the buttons that a record has changed. */
  announce(record) {
    for (const f of record.listeners) { try { f(); } catch (e) { /* a button that is gone */ } }
    const chat = this.chatView();
    if (chat) chat.refreshHistory();
  }

  /* Watches the editors where Lagrange has made edits. A change this plugin has just asked for (an undo or a redo of
     a run) completes that record; any other change is added to what has happened since. The editor's own undo and
     redo, used by the writer, make "carried through later typing" unreliable, which is remembered. */
  trackEdits(update) {
    if (!update.docChanged || !this.edits.length) return;
    const history = !this.ownHistory && update.transactions.some(tr => tr.docChanged && (tr.isUserEvent('undo') || tr.isUserEvent('redo')));
    for (const r of this.edits) {
      if (update.view !== r.view) continue;
      if (r.expecting === 'undo') {
        r.expecting = null;
        r.undone = true;
        r.undoneAt = ++this.editClock;
        r.redo = update.changes.invert(update.startState.doc);
        r.sinceUndo = ChangeSet.empty(update.state.doc.length);
        r.redoStale = false;
      } else if (r.expecting === 'redo') {
        r.expecting = null;
        r.undone = false;
        r.redo = null;
        r.docAfter = update.state.doc;
        r.inverse = update.changes.invert(update.startState.doc);
        r.since = ChangeSet.empty(update.state.doc.length);
        r.viaHistory = false;
      } else if (r.undone) {
        if (r.sinceUndo) r.sinceUndo = r.sinceUndo.compose(update.changes);
        if (history) r.redoStale = true;
      } else {
        r.since = r.since.compose(update.changes);
        if (history) r.viaHistory = true;
      }
    }
  }

  /* Undo one run of Lagrange's edits: the editor's own undo if nothing has happened since (so the editor's history
     stays in step); the inverse of the edits if the text is back as Lagrange left it; the inverse carried through
     later typing otherwise, which keeps what the writer typed and says so. After the writer has used the editor's
     undo or redo that last way isn't reliable, so it says to use Undo in the editor instead. */
  undoEdit(record) {
    const r = record;
    const stale = () => { new Notice('The note has changed since; use Undo in the editor instead.'); return false; };
    if (!r || r.undone || !this.edits.includes(r)) return stale();
    if (!r.view.dom.isConnected) { new Notice('That note is no longer open.'); return false; }
    const doc = r.view.state.doc;
    if (doc.eq(r.docBefore)) {
      new Notice('Those edits are already undone.');
      r.undone = true;
      r.undoneAt = ++this.editClock;
      r.redo = null;
      this.announce(r);
      return true;
    }
    let kept = false;
    r.expecting = 'undo';
    r.byHistory = false;
    this.ownHistory = true;
    try {
      if (r.since.empty && r.editor) { r.byHistory = true; r.editor.undo(); }
      else if (doc.eq(r.docAfter)) r.view.dispatch({ changes: r.inverse, userEvent: 'lagrange.undo' });
      else if (!r.viaHistory) { kept = true; r.view.dispatch({ changes: r.inverse.map(r.since), userEvent: 'lagrange.undo' }); }
    } finally {
      this.ownHistory = false;
    }
    if (r.expecting) { r.expecting = null; return stale(); }   // nothing changed: it could not be undone that way
    if (kept) new Notice('Lagrange’s edits were taken back; what you have typed since was kept.');
    this.announce(r);
    return true;
  }

  /* Redo a run that was undone, by the same three ways. */
  redoEdit(record) {
    const r = record;
    const stale = () => { new Notice('The note has changed since; those edits can’t be made again. Ask Lagrange once more.'); return false; };
    if (!r || !r.undone || !r.redo || !this.edits.includes(r)) return stale();
    if (!r.view.dom.isConnected) { new Notice('That note is no longer open.'); return false; }
    let kept = false;
    r.expecting = 'redo';
    this.ownHistory = true;
    try {
      if (r.sinceUndo.empty && r.byHistory && r.editor) r.editor.redo();
      else if (r.sinceUndo.empty) r.view.dispatch({ changes: r.redo, userEvent: 'lagrange.redo' });
      else if (!r.redoStale) { kept = true; r.view.dispatch({ changes: r.redo.map(r.sinceUndo), userEvent: 'lagrange.redo' }); }
    } finally {
      this.ownHistory = false;
    }
    if (r.expecting) { r.expecting = null; r.redo = null; this.announce(r); return stale(); }
    if (kept) new Notice('Lagrange’s edits were made again; what you have typed since was kept.');
    this.announce(r);
    return true;
  }

  /* The Markdown view showing a note, if one is open. */
  viewOf(path) {
    for (const leaf of this.app.workspace.getLeavesOfType('markdown')) {
      if (leaf.view instanceof MarkdownView && leaf.view.file && leaf.view.file.path === path) return leaf.view;
    }
    return null;
  }

  /* A note's text now: from its open editor (which may be ahead of the file), else from the file; null if it is gone. */
  async noteText(path) {
    const view = this.viewOf(path);
    if (view) return view.getViewData();
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!file || typeof file.extension !== 'string') return null;
    return this.app.vault.cachedRead(file);
  }

  /* Puts a note back to `text` (a rewind): one change in its editor, which the editor's Undo takes back, or the file
     itself if the note isn't open for editing. Runs of edits made after `clock` no longer mean anything and go. */
  async restoreNote(path, text, clock) {
    const view = this.viewOf(path);
    const cm = view && view.getMode() === 'source' && view.editor && view.editor.cm;
    if (cm) {
      const change = spliceChange(cm.state.doc.toString(), text);
      if (change) cm.dispatch({ changes: change, userEvent: 'lagrange.rewind' });
    } else {
      const file = this.app.vault.getAbstractFileByPath(path);
      if (!file) throw new Error('the note is no longer in the vault');
      await this.app.vault.modify(file, text);
    }
    const gone = this.edits.filter(r => r.path === path && r.clock > clock);
    this.edits = this.edits.filter(r => !gone.includes(r));
    for (const r of gone) { r.undone = true; r.redo = null; this.announce(r); }
    const chat = this.chatView();
    if (chat) chat.refreshHistory();
  }

  async ensureEditing(view) {
    if (view.getMode() === 'source') return;
    const state = view.leaf.getViewState();
    await view.leaf.setViewState(Object.assign({}, state, { state: Object.assign({}, state.state, { mode: 'source', source: false }) }));
    await nextFrame();
    await nextFrame();
  }

  /* Applies edits that were located in the editor's current text; reports in the chat (if open) and in a notice. */
  async applyEdits(view, located, skippedBefore, task, signal) {
    const cm = view.editor && view.editor.cm;
    let result;
    if (!cm) {
      // No CodeMirror 6 view (should not happen in current Obsidian): apply everything at once through the Editor API.
      const ed = view.editor;
      ed.transaction({ changes: located.map(e => ({ from: ed.offsetToPos(e.from), to: ed.offsetToPos(e.to), text: e.replace })) });
      result = { applied: located, skipped: [] };
    } else {
      const writing = this.settings.showPen ? new Notice('Lagrange is writing… (Esc to stop)', 0) : null;
      try {
        result = await runEdits(cm, located, { pen: this.settings.showPen ? this.pen : null, signal });
      } finally {
        if (writing) writing.hide();
      }
      if (result.failure) {
        this.pen.destroy();
        this.pen = createPen(this.app, this.settings);
      }
      if (this.app.workspace.getActiveViewOfType(MarkdownView) === view) cm.focus();
    }
    const skipped = skippedBefore.concat(result.skipped);
    let record = null;
    if (cm && result.applied.length && result.changes && !result.changes.empty) {
      record = this.recordEdit(cm, view.editor, view.file ? view.file.path : null, result);
    }
    const onUndo = record ? () => this.undoEdit(record) : null;
    if (task) task.report({ applied: result.applied, skipped }, record);
    const n = result.applied.length;
    if (n) {
      const frag = createFragment(f => {
        f.createSpan({ text: `Lagrange made ${n} edit${n === 1 ? '' : 's'}${skipped.length ? ` (${skipped.length} skipped)` : ''}. ` });
        if (onUndo) {
          const b = f.createEl('button', { cls: 'lagrange-notice-undo', text: 'Undo Lagrange’s edits' });
          b.addEventListener('click', ev => { ev.stopPropagation(); onUndo(); notice.hide(); });
        }
      });
      const notice = new Notice(frag, 10000);
    } else if (!task) {
      new Notice(skipped.length ? `Lagrange made no edits (${skipped.length} skipped).` : 'Lagrange found nothing to change.');
    }
    return result;
  }

  /* Makes the edits a chat reply asked for (parsed: parseAgentReply's result) in the note the message was about, by
     the same road as the commands: located in the editor's current text, written by the pen, one undo step, listed
     under the reply. */
  async applyChatEdits(view, note, parsed, reply, signal) {
    const task = {
      el: reply.el,
      stopLoader: () => {},
      status: text => reply.status(text),
      report: (result, onUndo) => { if (this.chatView()) this.chatView().renderReport(reply.el, result, onUndo); },
      done: text => reply.note(text, 'is-quiet'),
      fail: err => { const v = this.chatView(); if (v) v.addError(err, reply.el); },
    };
    if (!view || !view.file || !note || view.file.path !== note.path || !view.containerEl.isConnected) {
      reply.note('The note is no longer open, so Lagrange’s edits were not made.', 'is-warn');
      return;
    }
    if (this.editing) { reply.note('Lagrange is already editing, so these edits were not made.', 'is-warn'); return; }
    this.editing = true;
    try {
      await this.ensureEditing(view);
      const cm = view.editor && view.editor.cm;
      const docText = cm ? cm.state.doc.toString() : view.editor.getValue();
      const { located, skipped } = locateOps(docText, parsed.ops);
      if (parsed.error) reply.note(`Some of the edits could not be read. ${parsed.error}`, 'is-warn');
      if (parsed.dropped) reply.note(`${parsed.dropped} item${parsed.dropped === 1 ? '' : 's'} in the reply ${parsed.dropped === 1 ? 'was' : 'were'} not an edit and ${parsed.dropped === 1 ? 'was' : 'were'} left out.`, 'is-quiet');
      await this.applyEdits(view, located, skipped, task, signal);
    } catch (err) {
      this.reportFailure(err, task);
    } finally {
      this.editing = false;
    }
  }

  chatView() {
    const leaf = this.app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    return leaf && leaf.view instanceof LagrangeChatView ? leaf.view : null;
  }

  async proofread(view) {
    if (this.editing) { new Notice('Lagrange is already editing.'); return; }
    const note = this.noteFrom(view);
    if (!note) return;
    if (!note.text.trim()) { new Notice('This note is empty.'); return; }
    this.editing = true;
    const chat = await this.activateView(false);
    const controller = new AbortController();
    const task = chat ? chat.beginTask('Proofread', note.title, controller) : null;
    try {
      const limit = NOTE_LIMIT[this.settings.provider] || NOTE_LIMIT.anthropic;
      const clip = clipText(note.text, limit, note.cursor);
      if (task && clip.clipped) task.status(`The note is long: proofreading the ${(clip.end - clip.start).toLocaleString()} characters around the cursor.`);
      const res = await complete(this.settings, {
        purpose: 'proofread',
        system: PROOFREAD_SYSTEM,
        messages: [{ role: 'user', content: proofreadUserMessage(note, clip) }],
        demo: () => 'Here are the corrections I would make:\n\n```json\n' +
          JSON.stringify(demoProofreadEdits(note.text), null, 2) + '\n```\n',
      }, { signal: controller.signal }, this.session);
      if (res.stopReason === 'refusal') throw new LagrangeError('Claude declined to proofread this note.');
      const parsed = parseEdits(res.text);
      if (parsed.error) {
        throw new LagrangeError(`${parsed.error}${res.stopReason === 'max_tokens' ? ' (It reached its length limit.)' : ''} ` +
          'Try again, or choose another model.', { reply: res.text });
      }
      if (!parsed.edits.length) {
        if (task) task.report({ applied: [], skipped: [] });
        else new Notice('Lagrange found nothing to correct.');
        return;
      }
      await this.ensureEditing(view);
      const cm = view.editor && view.editor.cm;
      const docText = cm ? cm.state.doc.toString() : view.editor.getValue();
      const { located, skipped } = locateEdits(docText, parsed.edits);
      if (task) task.stopLoader();
      await this.applyEdits(view, located, skipped, task, controller.signal);
    } catch (err) {
      this.reportFailure(err, task);
    } finally {
      this.editing = false;
    }
  }

  reviseSelection(view, editor) {
    if (this.editing) { new Notice('Lagrange is already editing.'); return; }
    const a = editor.getCursor('from'), b = editor.getCursor('to');
    const from = editor.posToOffset(a), to = editor.posToOffset(b);
    const passage = editor.getRange(a, b);
    if (!passage.trim()) { new Notice('Select a passage to revise first.'); return; }
    new ReviseModal(this.app, passage, instruction => { this.revise(view, from, to, passage, instruction); }).open();
  }

  async revise(view, from, to, passage, instruction) {
    if (this.editing) { new Notice('Lagrange is already editing.'); return; }
    const note = this.noteFrom(view);
    if (!note) return;
    this.editing = true;
    const chat = await this.activateView(false);
    const controller = new AbortController();
    const task = chat ? chat.beginTask('Revise', `“${excerpt(instruction, 80)}”`, controller) : null;
    try {
      const limit = NOTE_LIMIT[this.settings.provider] || NOTE_LIMIT.anthropic;
      const clip = clipText(note.text, limit, from);
      const res = await complete(this.settings, {
        purpose: 'revise',
        system: REVISE_SYSTEM,
        messages: [{ role: 'user', content: reviseUserMessage(note, clip, passage, instruction) }],
        demo: () => demoRevise(passage, instruction),
      }, { signal: controller.signal }, this.session);
      if (res.stopReason === 'refusal') throw new LagrangeError('Claude declined to revise this passage.');
      const replacement = cleanRevision(res.text, passage);
      if (replacement === null) throw new LagrangeError('Lagrange returned an empty revision; nothing was changed.');
      if (replacement === passage) {
        if (task) task.done('No change: the passage already reads that way.');
        else new Notice('No change: the passage already reads that way.');
        return;
      }
      const cm = view.editor && view.editor.cm;
      const docText = cm ? cm.state.doc.toString() : view.editor.getValue();
      let at = [from, to];
      if (docText.slice(from, to) !== passage) {
        const hits = findAll(docText, passage);
        if (hits.length !== 1) throw new LagrangeError('The passage changed while Lagrange was working; nothing was changed.');
        at = hits[0];
      }
      const edit = { find: passage, replace: replacement, reason: instruction, from: at[0], to: at[1], matched: passage };
      if (task) task.stopLoader();
      await this.applyEdits(view, [edit], [], task, controller.signal);
    } catch (err) {
      this.reportFailure(err, task);
    } finally {
      this.editing = false;
    }
  }

  /* The Scriptorium plugin, which keeps the sets of drop caps and draws them; null if it is off. */
  scriptorium() {
    const p = this.app.plugins && this.app.plugins.plugins && this.app.plugins.plugins.scriptorium;
    return p && typeof p.addDrawnDropcap === 'function' ? p : null;
  }

  /* "Draw a drop cap": asks what to draw (DropcapDrawModal). */
  async askDropcap(view) {
    const scriptorium = this.scriptorium();
    if (!scriptorium) { new Notice('Drawing a drop cap needs the Scriptorium plugin (Settings → Community plugins), which keeps the drop caps.', 8000); return; }
    const adapter = this.app.vault.adapter, folder = 'Scriptorium/Drop caps';
    const known = { letter: '', sets: [] };
    // the letter the note's first chapter opens with
    const text = view.editor ? view.editor.getValue() : '';
    const body = text.replace(/^---\n[\s\S]*?\n---\n/, '');
    const first = body.split(/\n\s*\n/).map(p => p.trim()).find(p => p && !/^(#|>|!\[|```|\||[-*+] |\d+\. |---)/.test(p));
    known.letter = dropcapLetter(first || '');
    try {
      for (const dir of (await adapter.list(folder)).folders.sort()) {
        const letters = {};
        for (const f of (await adapter.list(dir)).files) {
          const m = f.slice(f.lastIndexOf('/') + 1).match(/^([A-Z])\.(png|svg)$/);
          if (m) letters[m[1]] = m[2];
        }
        known.sets.push({ name: dir.slice(dir.lastIndexOf('/') + 1), letters });
      }
    } catch (e) { /* no sets yet */ }
    known.sets.sort((a, b) => (b.name === 'Lagrange') - (a.name === 'Lagrange'));
    new DropcapDrawModal(this, view, known).open();
  }

  /* Has the provider draw (or change) the drop cap, hands it to Scriptorium, and sets it as the note's drop cap:
     Scriptorium inks it in. want: {letter, set, style, mono, change}. */
  async drawDropcap(view, want) {
    const scriptorium = this.scriptorium();
    if (!scriptorium || !view || !view.file) return;
    if (this.drawing) { new Notice('Lagrange is already drawing.'); return; }
    this.drawing = true;
    const chat = await this.activateView(false);
    const controller = new AbortController();
    const task = chat ? chat.beginTask(want.change ? 'Change a drop cap' : 'Draw a drop cap', `${want.letter}, in “${want.set}”`, controller) : null;
    try {
      const adapter = this.app.vault.adapter;
      let base = null;
      if (want.change) {
        for (const kind of ['png', 'svg']) {
          const path = `Scriptorium/Drop caps/${want.set}/${want.letter}.${kind}`;
          if (await adapter.exists(path)) { base = { bytes: new Uint8Array(await adapter.readBinary(path)), kind }; break; }
        }
        if (!base) throw new LagrangeError(`The set “${want.set}” has no ${want.letter} to change.`, { kind: 'setup' });
      }
      if (task) task.status(dropcapRoute(this.settings) === 'svg' ? 'Drawing…' : 'Painting… (a minute or so)');
      const drawn = await drawDropcap(this.settings, Object.assign({}, want, { base }), { signal: controller.signal }, this.session);
      let saved;
      try { saved = await scriptorium.addDrawnDropcap({ set: want.set, letter: want.letter, bytes: drawn.bytes, kind: drawn.kind, mono: want.mono }); }
      catch (e) { throw new LagrangeError(`The drawing could not be kept: ${e.message}.`, { reply: drawn.kind === 'svg' ? new TextDecoder().decode(drawn.bytes) : undefined }); }
      await scriptorium.setNoteDropcap(view.file, `set:${saved.set}`);
      // show it: Reading view is where drop caps are drawn
      try {
        const state = view.leaf.getViewState();
        if (state.state && state.state.mode !== 'preview') { state.state.mode = 'preview'; await view.leaf.setViewState(state); }
      } catch (e) { /* stays in the editor */ }
      window.setTimeout(() => { try { scriptorium.previewDropcap(view, `set:${saved.set}`); } catch (e) { /* the view has gone */ } }, 350);
      if (task) task.done(`${want.change ? 'Changed' : 'Drawn'}: ${saved.file}. It is this note’s drop cap now (the “dropcap” property), wherever a chapter opens with ${want.letter}.`);
      else new Notice(`Lagrange drew the drop cap: ${saved.file}`);
    } catch (err) {
      this.reportFailure(err, task);
    } finally {
      this.drawing = false;
    }
  }

  reportFailure(err, task) {
    if (isAbort(err)) {
      if (task) task.done('Stopped.');
      return;
    }
    if (!(err instanceof LagrangeError)) console.error('Lagrange', err);
    if (task) {
      task.fail(err);
      if (err.reply) {
        const d = task.el.createEl('details', { cls: 'lagrange-raw' });
        d.createEl('summary', { text: 'The reply' });
        d.createEl('pre', { text: excerpt(err.reply, 4000) });
      }
    } else {
      new Notice(`Lagrange: ${err.message || err}`);
    }
  }
}

module.exports = LagrangePlugin;
// The replaceable pieces and the pure helpers, for plugins-tests/ and for the animation work.
LagrangePlugin.mountLoader = mountLoader;
LagrangePlugin.createPen = createPen;
LagrangePlugin.rangeRects = rangeRects;
LagrangePlugin.internals = {
  DEFAULT_SETTINGS, ANTHROPIC_MODELS, ANTHROPIC_VERSION, FALLBACK_BETA, sanitizeSettings, anthropicModelId,
  LOADER_THEMES, LOADER_CAPTIONS, EFFORTS, CLAUDE_CODE_MODELS, effortSupported, effortFor, modelChoices, setModel, footLabel, modelLabel,
  rewindTo, userChangedSince, pruneCheckpoints, spliceChange, undoTarget, redoTarget, CHECKPOINTS_KEPT, CHECKPOINT_CHARS,
  splitAgentReply, parseAgentReply, locateOps, demoChatEdits, mathSegments, mathSource, looksLikeMath, hasMath, hasCode, typeCadence, penScript, renderPenMath, trailBands,
  equationPlan, repairJsonLatex, inkOffset, penLines, penPace, PEN_RUN_MS,
  createSSEParser, jsonValuesIn, parseEdits, findAll, looseFindAll, locateEdits, clipText, cleanRevision,
  parseErrorBody, describeError, noteStats, excerpt, demoProofreadEdits, demoRevise, demoChatReply,
  applyAnthropicEvent, applyOpenAIEvent, streamAnthropic, streamOpenAI, streamDemo, complete, fetchWithRetry,
  chatSystemPrompt, proofreadUserMessage, reviseUserMessage, runEdits, LagrangeError,
  transcriptPrompt, applyClaudeCodeLine, applyCodexLine, cliErrorMessage, findCli, runCli, runCliTakesEnv: true, streamClaudeCode, streamCodex, checkCli,
  dropcapRoute, dropcapRouteNote, dropcapLetter, dropcapImagePrompt, dropcapSvgMessage, DROPCAP_SVG_SYSTEM, extractSvg, demoDropcapSvg,
  bytesFromBase64, base64FromBytes, isPng, drawOpenAIImage, drawCodexImage, drawSvg, drawDropcap,
};
