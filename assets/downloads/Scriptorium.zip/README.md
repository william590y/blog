# Scriptorium — Obsidian configuration

A fancy and sophisticated obsidian configuration for the typographically inclined

## Open the demonstration

1. Install Obsidian from https://obsidian.md/download.
2. Extract this ZIP to a folder. Keep the hidden `.obsidian` folder inside it.
3. For the intended typography, install EB Garamond and Cormorant Garamond from Google Fonts, then restart Obsidian. Georgia is the fallback.
4. In Obsidian, choose **Open folder as vault** and select the extracted folder.
5. Open **Lorem Ipsum** and switch to **Reading view** to see the drop caps, subtitle rule, quotations, and ornamental scene breaks.

The Typewriter theme and manuscript CSS snippet are enabled in the configuration. Longform, Manuscriptum, and Typewriter Mode are bundled community plugins; review them before choosing to enable community plugins in Obsidian.

## Writing conventions

- The filename supplies the title.
- `###### Subtitle` creates a centered italic subtitle.
- `## Chapter heading` creates a centered small-cap chapter heading.
- `### Section heading` creates a smaller section heading.
- `> Quotation` creates an italic quotation.
- `---` creates an ornamental scene break.

For an existing vault, back up its `.obsidian` folder before replacing it with this one. This replaces vault settings and plugin configuration.

This bundle includes the user's configuration with the Typewriter theme, manuscript snippet, and the Longform, Manuscriptum, and Typewriter Mode plugins. Those third-party components remain the work of their respective authors. The saved workspace has been reset to the included sample note.
