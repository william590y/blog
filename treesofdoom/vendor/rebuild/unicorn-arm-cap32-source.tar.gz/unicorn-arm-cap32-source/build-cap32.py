#!/usr/bin/env python3
"""Build the already patched source tree without Git metadata.

Default: cap32 backend. NTTOD_SOFTFLOAT=1: optional native EABI helper hooks.
"""
import os
import shutil
from pathlib import Path

os.chdir(Path(__file__).resolve().parent)
for command in ('emcc', 'emcmake', 'emmake', 'cmake', 'make', 'pkg-config'):
    if not shutil.which(command):
        raise SystemExit(f'Required build command is unavailable: {command}')
import build
build.os.cpu_count = lambda: 4
build.generateConstants()
build.compileUnicorn(['arm'])
